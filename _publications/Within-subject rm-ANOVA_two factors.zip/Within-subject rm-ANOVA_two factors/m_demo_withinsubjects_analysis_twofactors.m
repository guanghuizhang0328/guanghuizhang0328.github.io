clear
clc
close all 
%%
tic
%% winthin-subject analysis: A*B: 4*3




X = xlsread('withinsubjects_twofactors.xls');
factorNames = {'A','B'};


subNum = size(X,1);
stiOne = 4;
stiTwo = 3;
stiNum = stiOne*stiTwo;
BTFacs =[];
WInFacs = [];
count = 0;
for is = 1:stiOne
    IdexStart = subNum*(is-1)*stiTwo+1;
    IdexEnd =  is*subNum*stiTwo;
    WInFacs(IdexStart:IdexEnd,1) = is;
    for iss  = 1:stiTwo
        count  = count +1;
    IdexStart = subNum*(count-1)+1;
    IdexEnd =  subNum*count;
    WInFacs(IdexStart:IdexEnd,2) = iss;

    end
end

S = [];
for iss = 1:stiNum
    IdexStart = subNum*(iss-1)+1;
    IdexEnd =  iss*subNum;
    S(IdexStart:IdexEnd,1) =1:subNum ;
end

D = reshape(X,1 ,[]);
stat = f_withinanova_rm2(D,WInFacs,S,factorNames);


%%
toc