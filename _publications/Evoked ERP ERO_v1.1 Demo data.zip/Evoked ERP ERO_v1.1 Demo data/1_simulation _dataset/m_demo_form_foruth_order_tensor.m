clear
clc
close all
%%
tic

Currentpath = char(strcat(pwd,filesep,'Individual dataset',filesep));
subNum = 11;
count = 0;
 %% the first group
for Numofsub = 1:subNum
 count = count +1;
%%stimulus 0ne

D(:,:,1,count) = 0.8.*importdata([Currentpath,num2str(count),'.mat']);
%%stimulus Two
D(:,:,2,count) = importdata([Currentpath,num2str(count),'.mat']);
     
%%stimulus Three
D(:,:,3,count) = 1.2.*importdata([Currentpath,num2str(count),'.mat']);
        
end

% %% the second group
% Currentpath = char(strcat(pwd,filesep,'functions',filesep,'demo data',filesep,'second group',filesep));
% subNum1 = 11;
%  %% the first group
% for Numofsub = 1:subNum1
%     count = count +1;
% %%stimulus 0ne
% D(:,:,1,count) = 0.8*importdata([Currentpath,num2str(Numofsub),'.mat']);
%  
% %%stimulus Two
% D(:,:,2,count) = importdata([Currentpath,num2str(Numofsub),'.mat']);
%      
% %%stimulus Three
% D(:,:,3,count) = importdata([Currentpath,num2str(Numofsub),'.mat']);
%         
% end

save('Demo_data','D','-v7.3');
%%
toc