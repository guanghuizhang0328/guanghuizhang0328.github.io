clear
clc
close all 
%%
tic

X = xlsread('withinsubjects_onefactors.xls');

subNum = size(X,1);
stiNum = size(X,2);
BTFacs =[];
WInFacs = [];
for is = 1:size(X,2)
IdexStart = subNum*(is-1)+1;
IdexEnd =  is*subNum;
WInFacs(IdexStart:IdexEnd,1) = is;
end
%%
S = [];
for iss = 1:stiNum
IdexStart = subNum*(iss-1)+1;
IdexEnd =  iss*subNum;
S(IdexStart:IdexEnd,1) =1:subNum ;
end
factorNames = {'A'};

correction_string.BTFacs = BTFacs;
correction_string.WInFacs=WInFacs;
correction_string.S = S;
[p, table] = f_withinanova_rm1(X,correction_string);


%%
toc