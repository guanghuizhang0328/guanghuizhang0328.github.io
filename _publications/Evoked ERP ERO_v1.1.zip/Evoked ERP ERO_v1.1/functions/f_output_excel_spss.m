function f_output_excel_spss(EEG_ERO);


if isempty(EEG_ERO.data)
    errordlg2('Cannot further analysis an empty dataset');
    return;
end

if EEG_ERO.sta_index ==0
    errordlg2('The signal is not processed for statistical analysis, please check it');
    return;
end

D = double(EEG_ERO.data);
Group_Idx = EEG_ERO.GroupIdex;
Sti_Name = EEG_ERO.Sti_Name;
NumGroups = max(Group_Idx(:));
if length(EEG_ERO.Sti_Name) ~= size(D,1)*max(Group_Idx(:))
    errordlg2('The stimuli paramerts are incorrect, please check it');
    return;
end

if length(Group_Idx) ~= size(D,2)
    errordlg2('The number of subjects is incorrect, please check it');
    return;
end

ChansOfInterestName = EEG_ERO.Interest_ChanName;
chanlocs = EEG_ERO.chanlocs;

if  length(ChansOfInterestName) > 1
    filechanName = ChansOfInterestName{1};
    for Numofchannel = 1:length(ChansOfInterestName) - 1
        filechanName = char(strcat(filechanName,'-',ChansOfInterestName{Numofchannel+1}));
    end
else
    filechanName = char(ChansOfInterestName);
end
%%input the place for saving

[fn pn, filterindex] = uiputfile({'*.xlsx';'*.xls'},'Save as');


%%
excelEnd_1   = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q',...
    'R','S','T','U','V','W','X','Y','Z'};
count = 0;
for iss = 1:5
    for is  = 1:length(excelEnd_1)
        count = count +1;
        excelEnd_2{count} = [excelEnd_1{iss},excelEnd_1{is}];
    end
end
excelEnd = [excelEnd_1,excelEnd_2];
data = permute(D,[2 1]);

if NumGroups == 1
    x = data;
    rangeName = Sti_Name;
else
    x = [Group_Idx,data];
    Sti_Name = EEG_ERO.Sti_Name_within;
    rangeName = ['Group', Sti_Name];
end

if EEG_ERO.wavelet_index ==1
    filterFlag =1;
elseif EEG_ERO.fft_index ==1
    
    filterFlag =2;
else
    filterFlag=3;
end

filterString = {'Wavelet filter','FFT filter','Conventional'};

filterName = filterString{filterFlag};

if EEG_ERO.fft_index ==1
    
    if EEG_ERO.fft_LowFre ~=0 & EEG_ERO.fft_HighFre~= 0
        
        filterName = char(strcat(filterName,filesep,32,'Bandpass filter',filesep,num2str(EEG_ERO.fft_LowFre),'-',num2str(EEG_ERO.fft_HighFre),'-Hz'));
        
    elseif ~isempty(EEG_ERO.fft_LowFre) & EEG_ERO.fft_HighFre==0
        filterName = char(strcat(filterName,filesep,32,'Highpass filter',filesep,num2str(EEG_ERO.fft_LowFre),'-Hz'));
    else
        
        filterName = char(strcat(filterName,filesep,32,'Lowpass filter',filesep,num2str(EEG_ERO.fft_HighFre),'-Hz'));
        
    end
end


[rowNum,columnNum] = size(x);

measurementName = {'peak','mean'};

if EEG_ERO.PCA_index == 1
    K = EEG_ERO.PCA_K;
    if  length(K) > 1
        filecomName = char(num2str(K(1)));
        for Numofchannel = 1:length(K) - 1
            filecomName = char(strcat(filecomName,'-',num2str(K(Numofchannel+1))));
        end
    else
        filecomName = char(num2str(K(1)));
    end
    
    if isempty(EEG_ERO.TF_index)
        route = char(strcat(pn,'Output',filesep,'Excel',filesep,filterName,filesep,'Time-domain',filesep,'PCA_R_',num2str(EEG_ERO.PCA_R),'_K_',filecomName,filesep,num2str(EEG_ERO.ERPStart),'-',num2str(EEG_ERO.ERPEnd),'ms',filesep,...
            measurementName{EEG_ERO.measurement_index},filesep,filechanName,filesep));
        
    elseif EEG_ERO.TF_index == 1 & EEG_ERO.TF_ROI_index ==1
        route = char(strcat(pn,'Output',filesep,'Excel',filesep,filterName,filesep,'Time-frequency analysis',filesep,'PCA_R_',num2str(EEG_ERO.PCA_R),'_K_',filecomName,filesep,num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz',filesep,...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),filesep,'Rectangle Method',filesep,num2str(EEG_ERO.TF_ROI_TimeStart),'-',num2str(EEG_ERO.TF_ROI_TimeEnd),'ms-',...
            num2str(EEG_ERO.TF_ROI_FreStart),'-',num2str(EEG_ERO.TF_ROI_FreEnd),'-Hz',filesep,filechanName,filesep));
    elseif EEG_ERO.TF_index == 1 & EEG_ERO.TF_canny_index ==1
        
        route = char(strcat(pn,'Output',filesep,'Excel',filesep,filterName,filesep,'Time-frequency analysis',filesep,'PCA_R_',num2str(EEG_ERO.PCA_R),'_K_',filecomName,filesep,num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz',filesep,...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),filesep,'Edge detection',filesep,filechanName,filesep));
        
    end
    
else
    if EEG_ERO.TF_index == 1 & EEG_ERO.TF_ROI_index ==1
        route = char(strcat(pn,'Output',filesep,'Excel',filesep,filterName,filesep,'Time-frequency analysis',filesep,num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz',filesep,...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),filesep,'Rectangle Method',filesep,num2str(EEG_ERO.TF_ROI_TimeStart),'-',num2str(EEG_ERO.TF_ROI_TimeEnd),'ms-',...
            num2str(EEG_ERO.TF_ROI_FreStart),'-',num2str(EEG_ERO.TF_ROI_FreEnd),'-Hz',filesep,filechanName,filesep));
    elseif EEG_ERO.TF_index == 1 & EEG_ERO.TF_canny_index ==1
        
        route = char(strcat(pn,'Output',filesep,'Excel',filesep,filterName,filesep,'Time-frequency analysis',filesep,num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz',filesep,...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),filesep,'Edge detection',filesep,filechanName,filesep));
    else
        
       route = char(strcat(pn,'Output',filesep,'Excel',filesep,filterName,filesep,'Conventional Time-domain analysis',filesep,num2str(EEG_ERO.ERPStart),'-',num2str(EEG_ERO.ERPEnd),'ms',filesep,...
             measurementName{EEG_ERO.measurement_index},filesep,filechanName,filesep));  
    end
    
end

mkdir(route);

excelName = fn;
heandrang = strcat('A1:',excelEnd{columnNum},int2str(1));
datarang = strcat('A2:',excelEnd{columnNum},int2str(rowNum+1));
xlswrite([route excelName],rangeName,heandrang);
xlswrite([route excelName],x,datarang);%% if cann't output data ,please replace excelName{1,1} by excelName

filterName = [];

filterName = filterString{filterFlag};
if EEG_ERO.fft_index ==1
    
    if EEG_ERO.fft_LowFre ~=0 & EEG_ERO.fft_HighFre~= 0
        
        filterName = char(strcat(filterName,'-Bandpass-',num2str(EEG_ERO.fft_LowFre),'-',num2str(EEG_ERO.fft_HighFre),'Hz'));
        
    elseif ~isempty(EEG_ERO.fft_LowFre) & EEG_ERO.fft_HighFre==0
        filterName = char(strcat(filterName,'-Highpass-',num2str(EEG_ERO.fft_LowFre),'Hz'));
    else
        
        filterName = char(strcat(filterName,'-Lowpass-',num2str(EEG_ERO.fft_HighFre),'Hz'));
        
    end
end


if EEG_ERO.PCA_index == 1
    if isempty(EEG_ERO.TF_index)
        route = char(strcat(filterName,'-Time-domain-PCA_R_',num2str(EEG_ERO.PCA_R),'_K_',filecomName,'-',num2str(EEG_ERO.ERPStart),'-',num2str(EEG_ERO.ERPEnd),'ms-',...
            measurementName{EEG_ERO.measurement_index},'-',filechanName));
        
    elseif EEG_ERO.TF_index == 1 & EEG_ERO.TF_ROI_index ==1
        route = char(strcat(filterName,'-Time-frequency analysis-PCA_R_',num2str(EEG_ERO.PCA_R),'_K_',filecomName,'-',num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz-',...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),'-Rectangle Method-',num2str(EEG_ERO.TF_ROI_TimeStart),'-',num2str(EEG_ERO.TF_ROI_TimeEnd),'ms-',...
            num2str(EEG_ERO.TF_ROI_FreStart),'-',num2str(EEG_ERO.TF_ROI_FreEnd),'-Hz-',filechanName));
    elseif EEG_ERO.TF_index == 1 & EEG_ERO.TF_canny_index ==1
        
        route = char(strcat(filterName,'-Time-frequency analysis-PCA_R_',num2str(EEG_ERO.PCA_R),'_K_',filecomName,'-',num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz-',...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),'-Edge detection-',filechanName));
        
    end
    
else
    
    if EEG_ERO.TF_index == 1 & EEG_ERO.TF_ROI_index ==1
        route = char(strcat(filterName,'-Time-frequency analysis-',num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz-',...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),'-Rectangle Method-',num2str(EEG_ERO.TF_ROI_TimeStart),'-',num2str(EEG_ERO.TF_ROI_TimeEnd),'ms-',...
            num2str(EEG_ERO.TF_ROI_FreStart),'-',num2str(EEG_ERO.TF_ROI_FreEnd),'-Hz-',filechanName));
    elseif EEG_ERO.TF_index == 1 & EEG_ERO.TF_canny_index ==1
        
        route = char(strcat(filterName,'-Time-frequency analysis-',num2str(EEG_ERO.TF_LowFre),'-',num2str(EEG_ERO.TF_HighFre),'Hz-',...
            'fb-',num2str(EEG_ERO.TF_fb),'-fc-',num2str(EEG_ERO.TF_fc),'-Edge detection-',filechanName));
    
    else

       route = char(strcat(filterName,'-Conventional Time-domain analysis-',num2str(EEG_ERO.ERPStart),'-',num2str(EEG_ERO.ERPEnd),'ms-',...
             measurementName{EEG_ERO.measurement_index},'-',filechanName));     
    end
end




disp(strcat(['The data has been exported for',32,route]));


return;