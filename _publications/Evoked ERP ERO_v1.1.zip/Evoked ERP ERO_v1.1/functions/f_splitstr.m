function subName = f_splitstr(X)

L = length(X);
S =[];
count = 0;
for is = 1:L
    code = strcmp(X(1,is),',');
    if code == 1
        count = count +1;
        S(count) = is;
        if count == 1
            subName{count} = X(1,1:is-1);
        else
            subName{count} = X(1, (S(count-1)+1): (S(count)-1));
        end
    end
end

subName{count+1} = X(1, (S(count)+1): end);


