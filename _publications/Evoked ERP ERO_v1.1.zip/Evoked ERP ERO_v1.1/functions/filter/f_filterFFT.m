function y=f_filterFFT(x,fs,freqLowCut,freqHighCut)
M = 10*fs;
freqBin = fs/M;%% frequency represented by one frequency bin
%% FFT-filter
%% M-point DFT
%%%%% signal is length - N
X = fft(x,M);
Z = zeros(size(X));
if (freqLowCut==0) & (freqHighCut~=0) == 1 %% low pass filter
    binHighCut = ceil(freqHighCut/freqBin)+1; %% the frequency bin corresponds to the high frequency
    binHighCut2 = (M/2+1)+(M/2+1-binHighCut); %% the frequency bin corresponds to the high frequency
    Z(1:binHighCut,:) = X(1:binHighCut,:);
    Z(binHighCut2:end,:) = X(binHighCut2:end,:);
    
elseif  (freqLowCut~=0) & (freqHighCut==0) == 1 %% high pass filter
    binLowCut = ceil(freqLowCut/freqBin)+1;%% the frequency bin corresponds to the low frequency
    binLowCut2 = (M/2+1)+(M/2+1-binLowCut);%% the frequency bin corresponds to the low frequency
    Z(binLowCut:binLowCut2,:) = X(binLowCut:binLowCut2,:);
else %% band pass filter
    binLowCut = ceil(freqLowCut/freqBin)+1;%% the frequency bin corresponds to the low frequency
    binHighCut = ceil(freqHighCut/freqBin)+1; %% the frequency bin corresponds to the high frequency
    binLowCut2 = (M/2+1)+(M/2+1-binLowCut);%% the frequency bin corresponds to the low frequency
    binHighCut2 = (M/2+1)+(M/2+1-binHighCut); %% the frequency bin corresponds to the high frequency
    Z(binLowCut:binHighCut,:) = X(binLowCut:binHighCut,:);
    Z(binHighCut2:binLowCut2,:) = X(binHighCut2:binLowCut2,:);
end

%%
z = ifft(Z,M);
y = z(1:size(x,1),:);
