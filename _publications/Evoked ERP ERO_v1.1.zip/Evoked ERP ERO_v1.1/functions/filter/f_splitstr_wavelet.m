%% find the interest number
function subName = f_splitstr_wavelet(X)

L = length(X);
count = 0;
for is = 1:L
    code = (strcmp(X(1,is),',') | strcmp(X(1,is),' ') | strcmp(X(1,is),'.'));
    if code  == 1
        count = count +1;
        N_Null(count) =  is;
    end
end

%%% determin baseine ranges
if length(N_Null) == 1
if N_Null ~=1
    
    subName(1) = str2num(X(1, 1:N_Null-1));
    subName(2) = str2num(X(1, N_Null+1:end));
end
    
else 
count1 = 0;
if N_Null(1) ~= 1
    subName(1) = str2num(X(1, 1:N_Null(1)-1));
    count1 =1;
    for iss = 1:length(N_Null)-1
        if N_Null(iss+1)- N_Null(iss) > 1
            count1  = count1 +1;
            subName(count1) = str2num(X(1, N_Null(iss)+1: N_Null(iss+1)-1));
        end
    end
else
    for iss = 1:length(N_Null)-1
        if N_Null(iss+1)- N_Null(iss) > 1
            count1  = count1 +1;
            subName(count1) = str2num(X(1, N_Null(iss)+1: N_Null(iss+1)-1));
        end
    end
end
%% find the final number N_Null(1)
if  N_Null(iss+1) < L
    subName(count1+1) = str2num(X(1, N_Null(iss+1)+1:end));
end
end





