function f_plot_Waveletfilter_FreRespose(x_fr,fs,lv,wname,kp)

%%% the patameters for frequency/phase  response

Len= length(x_fr);
Dura = length(x_fr);
FFTLen=fs*10;
freqRs=fs/FFTLen;

freLow=fs/FFTLen;
freHigh = 30;

binLow=freLow/freqRs;
binHigh=freHigh/freqRs;


timeIndex=(1:(2*Len-1))*1000/fs;
fIndex= freLow:freqRs:freHigh;

sig=[zeros(Len-1,1);1; zeros(Len-1,1)];
tIndex = linspace(-Dura,Dura,length(sig));
%%% Wavelet Filter Frequency Response
WLDsig=f_filterWavelet(sig,lv,wname,kp);
WLDsigFFT=fft(WLDsig,FFTLen);
spec=abs(WLDsigFFT(binLow:binHigh,:));
WaveletfreqResp=20*log10(spec/max(spec));
Waveletphase = 2*pi*phase(WLDsigFFT(binLow:binHigh));


figure('NumberTitle', 'off', 'Name', 'Filtering data using wavelet filter');
% set(gcf,'outerposition',get(0,'screensize'));
subplot(2,1,1);
set(gca,'fontsize',20);
plot(fIndex,WaveletfreqResp,'k--','linewidth',2);
hold on;
xlim([freLow,freHigh]);
ylim([min(WaveletfreqResp(:))*1.1 max(WaveletfreqResp(:))+10]);
tN = ['Magnitude of frequency responses for Wavelet Filter'];
title(tN,'fontsize',16);
% xlabel('Frequency/Hz','fontsize',16);
ylabel('Attenuation/dB','fontsize',16);
subplot(2,1,2);
set(gca,'fontsize',20);
plot(fIndex,Waveletphase,'k--','linewidth',2);
hold on;
xlim([freLow,freHigh]);
tN = ['Phase of frequency responses for Wavelet Filter'];
title(tN,'fontsize',16);
xlabel('Frequency/Hz','fontsize',16);
ylabel('Angle/degree','fontsize',16);


