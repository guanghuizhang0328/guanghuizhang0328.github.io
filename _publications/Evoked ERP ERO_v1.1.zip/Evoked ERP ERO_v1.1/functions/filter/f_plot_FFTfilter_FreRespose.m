function pop_plot_FFTfilter_FreRespose(x_fr,fs, freqLowCut,freqHighCut)

%%% the patameters for frequency/phase  response

Len= length(x_fr);
Dura = length(x_fr);
FFTLen=fs*10;
freqRs=fs/FFTLen;
if freqLowCut == 0
    freLow= fs/FFTLen;
    freHigh = freqHighCut +1;
elseif freqHighCut ==0
    
    freLow= fs/FFTLen;
    freHigh = ceil(fs/2);
    
    
else
    freLow= fs/FFTLen;
    freHigh = freqHighCut +1;
    
end

binLow=freLow/freqRs;
binHigh=freHigh/freqRs;


timeIndex=(1:(2*Len-1))*1000/fs;
fIndex= freLow:freqRs:freHigh;

sig=[zeros(Len-1,1);1; zeros(Len-1,1)];
tIndex = linspace(-Dura,Dura,length(sig));


%%% FFT FREQUENCY RESPONSE

DFsig=f_filterFFT(sig,fs,freqLowCut,freqHighCut);
DFsigFFT = fft(DFsig,FFTLen);




if (freqLowCut==0) & (freqHighCut~=0) == 1 %% low pass filter
    spec=abs(DFsigFFT(1:binHigh,:));
    DFfreqResp =20*log10(spec/max(spec));
    DFphase = 2*pi* phase(DFsigFFT(1:binHigh));%% phas
    
elseif  (freqLowCut~=0) & (freqHighCut==0) == 1 %% high pass filter
    spec=abs(DFsigFFT(binLow:(FFTLen/2),:));
    DFfreqResp =20*log10(spec/max(spec));
    DFphase = 2*pi* phase(DFsigFFT(binLow:(FFTLen/2)));%% phas
    
elseif (freqLowCut~=0) & (freqHighCut~=0) == 1 %% band pass filter
    spec=abs(DFsigFFT(binLow:binHigh,:));
    DFfreqResp =20*log10(spec/max(spec));
    DFphase = 2*pi* phase(DFsigFFT(binLow:binHigh));%% phas
end

figure('NumberTitle', 'off', 'Name', 'Filtering data using FFT filter');
% set(gcf,'outerposition',get(0,'screensize'));
subplot(2,1,1);
set(gca,'fontsize',20);
plot(fIndex,DFfreqResp,'k--','linewidth',2);
hold on;
xlim([freLow,freHigh]);
ylim([min(DFfreqResp(:))*1.1 max(DFfreqResp(:))+10]);
tN = ['Magnitude of frequency responses for FFT Filter'];
title(tN,'fontsize',16);
% xlabel('Frequency/Hz','fontsize',16);
ylabel('Attenuation/dB','fontsize',16);
subplot(2,1,2);
set(gca,'fontsize',20);
plot(fIndex,DFphase,'k--','linewidth',2);
hold on;
xlim([freLow,freHigh]);
tN = ['Phase of frequency responses for FFT Filter'];
title(tN,'fontsize',16);
xlabel('Frequency/Hz','fontsize',16);
ylabel('Angle/degree','fontsize',16);