function [ALLEEG_EROOUT,EEG_EROOUT] = f_WaveletBandfilter(ALLEEG_EROINPUT,EEG_ERO)

wname = ['rbio6.8'];


if isempty(EEG_ERO.data)
    errordlg2('f_WaveletBandfilter() error: cannot filter an empty dataset'); return;
end;

if ~isempty(EEG_ERO.fft_index)
    errordlg2('The signal has been filtered via FFT filter');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if ~isempty(EEG_ERO.wavelet_index)
    errordlg2('The signal has been filtered via wavelet filter');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if EEG_ERO.PCA_index ==1
    errordlg2('The signal has been proessed via t-PCA');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if EEG_ERO.TF_index ==1
    errordlg2('The signal has been proessed via time-frequency analysis');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if EEG_ERO.sta_index ==1
    errordlg2('Thi is the data for statistical analysis');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;



fs  =  EEG_ERO.srate;
% which set to save
% -----------------
if fs <= 1024 & fs > 512
    lv = {'10'};
    kp = {'6,7,8,9,10'};
elseif fs <= 512 & fs > 256
    lv = {'9'};
    kp = {'5,6,7,8,9'};
elseif 128 < fs & fs <= 256
    lv = {'8'};
    kp = {'4,5,6,7,8'};
elseif 64 < fs & fs <= 128
    lv = {'7'};
    kp = {'3,4,5,6,7'};
end

uilist = {{ 'style' 'text' 'string' 'Decomposition Level [LV] ' } ...
    { 'style' 'edit' 'string' lv } ...
    { 'style' 'text' 'string' 'Keep Coefficents in Scale [KP]' } ...
    { 'style' 'edit' 'string'  kp  } ...
    { 'style' 'text' 'string' 'Remove Baseline:LatencyRange([min max] in ms) ' } ...
    { 'style' 'edit' 'string'  '-200'}...
    { 'style' 'text' 'string' '      --' } ...
    { 'style' 'edit' 'string'  '0'}...
    { 'style' 'checkbox' 'string' 'Plot the Wavelet Filter Frequency Response' 'value' 0} ...
    };
geometry = { [3 2.1] [3 2.1]  [3 0.7 0.7 0.7] 1};

result = inputgui( 'geometry', geometry, 'uilist', uilist, 'title', 'Filter the data -- f_WaveletBandfilter()', ...
    'helpcom', 'pophelp(''f_WaveletBandfilter'')');

if isempty(result)
    
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end

if result{1,1}{1,1}== '0'
    errordlg2('Please Input Decomposition Level [LV]');
    return;
end;

lv    = eval(result{1,1}{1,1});
kp =  regexp( result{2} ,'\s+','split');
if length(kp)== 1
    %% add path
    Currentpath = [pwd,filesep,'functions',filesep,'filter',filesep];
    addpath(genpath(Currentpath));
    x = result{2};
    kp  =  f_splitstr_wavelet(x{1,1} ) ;
end
%%%%%%% baseline ranges%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
BaselineString(1) = eval(result{3});
BaselineString(2) = eval(result{4});
kp_transform = [];
for ii = 1:length(kp)
    kp_transform(ii) = lv+2-kp(ii);
end
%%
plotfreqz = result{5};
% -------------------------
BasePstart = ceil((BaselineString(1)-EEG_ERO.epochStart)/(1000/fs))+1;
BasePend = ceil((BaselineString(2)-EEG_ERO.epochStart)/(1000/fs))+1;
DATA = EEG_ERO.data;
temp =[];
temp = squeeze( DATA(1,:,1,1))' ;
if  plotfreqz == 1
    f_plot_Waveletfilter_FreRespose(temp,EEG_ERO.srate,lv,wname,kp_transform);
end
clear temp;
Hw_news =['Filtering ERP data via wavelet filter...'];
Hw = waitbar(0,Hw_news);

for chanNum = 1:size(EEG_ERO.data,1)
    for stiNum = 1:size(EEG_ERO.data,3)
        for subNum = 1:size(EEG_ERO.data,4)
            waitbar(subNum/(size(EEG_ERO.data,1)*size(EEG_ERO.data,3)*size(EEG_ERO.data,4)),Hw);
            temp = [];
            temp = squeeze( DATA(chanNum,:,stiNum,subNum))' ;
            temp3=  f_filterWavelet(temp,lv,wname,kp_transform);
            temp3 = temp3 - mean(temp3(BasePstart:BasePend));
            d(chanNum,:,stiNum,subNum) = temp3;
            clear temp3;
        end
    end
end
close(Hw);

EEG_ERO.data = d;
clear d;
EEG_ERO.wavelet_lv = lv;
EEG_ERO.wavelet_kp =  kp;
EEG_ERO.wavelet_index = 1;
EEG_EROOUT = EEG_ERO;
ALLEEG_EROOUT = f_eeg_store(ALLEEG_EROINPUT,EEG_EROOUT);
disp('The signal has been filtered via wavelet filter.');
return