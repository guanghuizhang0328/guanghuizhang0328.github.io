function [ALLEEG_EROOUT,EEG_EROOUT] = f_FFTfilterbase(ALLEEG_EROINPUT,EEG_ERO)


if isempty(EEG_ERO.data)
    errordlg2('f_WaveletBandfilter() error: cannot filter an empty dataset');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if ~isempty(EEG_ERO.fft_index)
    errordlg2('The signal has been filtered via FFT filter');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if ~isempty(EEG_ERO.wavelet_index)
    errordlg2('The signal has been filtered via wavelet filter');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if EEG_ERO.PCA_index ==1
    errordlg2('The signal has been proessed via t-PCA');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if EEG_ERO.TF_index ==1
    errordlg2('The signal has been proessed via time-frequency analysis');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

if EEG_ERO.sta_index ==1
    errordlg2('Thi is the data for statistical analysis');
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end;

% which set to save
% -----------------

uilist = { ...
    { 'style' 'text' 'string' 'Lower edge of the interested frequency (Hz)' } ...
    { 'style' 'edit' 'string' '0' } ...
    { 'style' 'text' 'string' 'Higher edge of the interested frequency (Hz)' } ...
    { 'style' 'edit' 'string' '0' } ...
    { 'style' 'text' 'string' 'Remove Baseline:([min max] in ms) ' } ...
    { 'style' 'edit' 'string'  '-200'}...
    { 'style' 'text' 'string' '      --' } ...
    { 'style' 'edit' 'string'  '0'}...
    { 'style' 'checkbox' 'string' 'Plot the filter frequency response' 'value' 0}};
geometry = { [3 2.1] [3 2.1]  [3 0.7 0.7 0.7] 1};

result = inputgui( 'geometry', geometry, 'uilist', uilist, 'title', 'Filter the data -- f_FFTfilterbase()', ...
    'helpcom', 'pophelp(''f_FFTfilter'')');




if isempty(result)
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end

if isempty(result{1}), result{1} = '0'; end;
if isempty(result{2}), result{2} = '0'; end;

locutoff   	 = eval(result{1});
hicutoff 	 = eval(result{2});

%%%%%%% baseline ranges%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
BaselineString(1) = eval( result{3} );
BaselineString(2) = eval( result{4} );
plotfreqz = result{5};

if locutoff == 0 & hicutoff == 0
    errordlg2('Please input the necessary parameters for the interested frequency ')
    ALLEEG_EROOUT=ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end
% processing multiple datasets
% -------------------------
DATA = [];
DATA = EEG_ERO.data;
fs  =  EEG_ERO.srate;
BasePstart = ceil((BaselineString(1)-EEG_ERO.epochStart)/(1000/fs))+1;
BasePend = ceil((BaselineString(2)-EEG_ERO.epochStart)/(1000/fs))+1;


temp = squeeze( DATA(1,:,1,1))' ;
if  plotfreqz == 1
    f_plot_FFTfilter_FreRespose(temp,EEG_ERO.srate,locutoff, hicutoff)
end
clear temp;

Hw_news =['Filtering ERP data..'];
Hw = waitbar(0,Hw_news);

for chanNum = 1:size(EEG_ERO.data,1)
    for stiNum = 1:size(EEG_ERO.data,3)
          waitbar(stiNum/(size(EEG_ERO.data,1)*size(EEG_ERO.data,3)),Hw);
        for subNum = 1:size(EEG_ERO.data,4)
          
            temp = squeeze( DATA(chanNum,:,stiNum,subNum))' ;
            temp3=  f_filterFFT(temp,EEG_ERO.srate,locutoff,hicutoff);
            temp3 = temp3 - mean(temp3(BasePstart:BasePend));
            D(chanNum,:,stiNum,subNum) = temp3;
            clear temp3;
        end
    end
end
close(Hw);

EEG_ERO.data = D;
clear D;
EEG_ERO.fft_index = 1;
EEG_ERO.fft_LowFre = locutoff;
EEG_ERO.fft_HighFre = hicutoff;
EEG_EROOUT = EEG_ERO;
ALLEEG_EROOUT = f_eeg_store(ALLEEG_EROINPUT,EEG_EROOUT);

if EEG_ERO.fft_LowFre ~=0 & EEG_ERO.fft_HighFre~= 0
        
        filterName1 = char(strcat('FFT-Bandpass filter:',num2str(EEG_ERO.fft_LowFre),'-',num2str(EEG_ERO.fft_HighFre),32,'Hz'));
        
    elseif ~isempty(EEG_ERO.fft_LowFre) & EEG_ERO.fft_HighFre==0
        filterName1 = char(strcat('FFT-Highpass filter:',num2str(EEG_ERO.fft_LowFre),32,'Hz'));
    else
        
        filterName1 = char(strcat('FFT-Lowpass filter-',num2str(EEG_ERO.fft_HighFre),32,'Hz'));
        
    end


disp(strcat('The signal has been filtered using ',32, filterName1));
%% multi subject
%%
return
