function [ALLEEG_EROOUT]= f_check_data(ALLEEG_EROIN);

if isempty(ALLEEG_EROIN) | length(ALLEEG_EROIN)< 2
    
    
else
    data_Num = length(ALLEEG_EROIN);
    
    for i = 1:data_Num
        for j = 2:data_Num
            
            if i~= j
                count = 0;
                fieldNames1 = fieldnames(ALLEEG_EROIN{i});
                fieldNames2 = fieldnames(ALLEEG_EROIN{j});
                typeNum = length(fieldNames1);
                
                for Numoftype = 1:typeNum
                    
                    code1 = strcmp(fieldNames1{Numoftype},'TF_canny_save_parameters');
                    code2 = strcmp(fieldNames1{Numoftype},'TF_canny_save_parameters');
                    code3 = strcmp(fieldNames1{Numoftype},'data');
                    if code1 ~=1 | code2~= 1 | code3 ~= 1
                        
                        y_label = find(strcmp(fieldNames2,fieldNames1{Numoftype}));
                        
                        
                        

                        
                        
                    end
                    
                    
                end
                
                
                
                
            end
        end
        
        
        
        
    end
    return;