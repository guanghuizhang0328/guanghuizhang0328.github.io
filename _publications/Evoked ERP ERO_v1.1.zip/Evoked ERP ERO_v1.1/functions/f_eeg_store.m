function ALLEEG_EROOUT = f_eeg_store(ALLEEG_EROINPUT,EEG_EROIN)

if isempty(ALLEEG_EROINPUT)
    fileName = char(strcat('Dataset: 1'));
    geometry    = { [3.5] [1 2]};
    uilist = { ...
        { 'Style', 'text', 'string', ' What do you to do with the new dataset?', 'horizontalalignment', 'right','fontweight', 'bold'}, ...
        ...
        { 'Style', 'text', 'string', 'Name it', 'horizontalalignment', 'right','fontweight', 'bold', ...
        },   { 'Style', 'edit', 'string', fileName }};
    [ results newcomments ] = inputgui( geometry, uilist,'functionhelp(''f_eeg_store'');', 'Name the new dataset -- f_eeg_store()');
    
    if isempty(results)
        ALLEEG_EROOUT = ALLEEG_EROINPUT;
        return;
    else
        EEG_EROIN.filename = results{1};
        ALLEEG_EROOUT(1) = EEG_EROIN;
        return;
    end
    
else
    
    fileName = char(strcat('Dataset:',32,num2str(length(ALLEEG_EROINPUT)+1)));
    geometry    = { [3.5] [1 2]};
    uilist = { ...
        { 'Style', 'text', 'string', ' What do you to do with the new dataset?', 'horizontalalignment', 'right','fontweight', 'bold'}, ...
        ...
        { 'Style', 'text', 'string', 'Name it', 'horizontalalignment', 'right','fontweight', 'bold', ...
        },   { 'Style', 'edit', 'string', fileName }};
    [ results newcomments ] = inputgui( geometry, uilist,'functionhelp(''f_eeg_store'');', 'Name the new dataset -- f_eeg_store()');

    EEG_EROIN.filename = results{1};
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    ALLEEG_EROOUT(length(ALLEEG_EROINPUT)+1) = EEG_EROIN;
end
return