function f_savemat(EEG_ERO)
[filename, pathname, filterindex] = uiputfile({'*.mat','MAT-files (*.mat)'},'Save as');
fn= char(strcat(pathname, filename));

if filterindex == 0
    errordlg2('Please give a name for the saved signal');
    return;
    
else
    save(fn,'EEG_ERO', '-v7.3');
end

return;