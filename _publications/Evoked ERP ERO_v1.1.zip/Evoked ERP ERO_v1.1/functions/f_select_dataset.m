function [ALLEEG_EROOUT,EEG_EROOUT] = f_select_dataset(ALLEEG_EROIN,EEG_EROIN);

if isempty(ALLEEG_EROIN)
   errordlg2('No datasets can be selected');  
   ALLEEG_EROOUT = ALLEEG_EROIN;
    EEG_EROOUT = EEG_EROIN;
    return;  
end


filedataName =[];
if length(ALLEEG_EROIN) == 1
    errordlg2('No other datasets can be selected');
    ALLEEG_EROOUT = ALLEEG_EROIN;
    EEG_EROOUT = EEG_EROIN;
    return;
else
    %  filedataName{1} = char(strcat('Dataset: 1'));
    for Numofsti = 1:length(ALLEEG_EROIN)
        filedataName{Numofsti} = char(strcat(ALLEEG_EROIN(Numofsti).filename));
    end
end

geometry    = {[3 1.5]};
uilist = {...
    { 'Style', 'text', 'string', 'Dataset num. (click on the selected option)', 'horizontalalignment', 'right', 'fontweight', 'bold' }, ...
    { 'Style', 'popupmenu', 'string', filedataName, ...
    'horizontalalignment', 'right', 'tag',  'sphfile' }};
[ result1 newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_selecte_dataset'');', 'Import dataset info -- f_selecte_dataset()');

if isempty(result1)
    ALLEEG_EROOUT= ALLEEG_EROIN;
    EEG_EROOUT = EEG_EROIN;
    return;
end




EEG_ERO = ALLEEG_EROIN(result1{1});
if isempty(EEG_ERO.fft_LowFre)
    EEG_ERO.fft_LowFre = 0;
end
if isempty(EEG_ERO.fft_HighFre)
    EEG_ERO.fft_HighFre = 0;
end
if isempty(EEG_ERO.wavelet_lv)
    EEG_ERO.wavelet_lv = 0;
end
if isempty(EEG_ERO.wavelet_kp)
    EEG_ERO.wavelet_kp_label = 0;
else
      Kp = EEG_ERO.wavelet_kp; 
   if length(Kp) == 1
       EEG_ERO.wavelet_kp_label = char(strcat(num2str(Kp)));
   else
       EEG_ERO.wavelet_kp_label{1} = char(strcat(num2str(Kp(1))));
    for Numofsti = 1:length(EEG_ERO.wavelet_kp)-1
        EEG_ERO.wavelet_kp_label = char(strcat(EEG_ERO.wavelet_kp_label,',',num2str(Kp(Numofsti+1))));
    end
   end
end

if isempty(EEG_ERO.PCA_R)
    EEG_ERO.PCA_R = 0;
end
if isempty(EEG_ERO.PCA_K)
    EEG_ERO.PCA_K_label = 0;
else

   K = EEG_ERO.PCA_K; 
   if length(K) == 1
       EEG_ERO.PCA_K_label = char(strcat(num2str(K)));
   else
       EEG_ERO.PCA_K_label{1} = char(strcat(num2str(K(1))));
    for Numofsti = 1:length(EEG_ERO.PCA_K)-1
        EEG_ERO.PCA_K_label = char(strcat(EEG_ERO.PCA_K_label,',',num2str(K(Numofsti+1))));
    end
   end

end
if isempty(EEG_ERO.ERPStart)
    EEG_ERO.ERPStart =0;
    EEG_ERO.ERPEnd =0;
end

%% tfr
if isempty(EEG_ERO.TF_LowFre)
    EEG_ERO.TF_LowFre = 0;
    EEG_ERO.TF_HighFre = 0;
    EEG_ERO.TF_fb = 0;
    EEG_ERO.TF_fc = 0;
end
if isempty(EEG_ERO.TF_ROI_TimeStart)
    EEG_ERO.TF_ROI_TimeStart = 0;
    EEG_ERO.TF_ROI_TimeEnd = 0;
    EEG_ERO.TF_ROI_FreStart = 0;
    EEG_ERO.TF_ROI_FreEnd = 0;
end

if isempty(EEG_ERO.TF_canny_index)
    EEG_ERO.TF_canny_index = 0;
end

if isempty(EEG_ERO.Interest_ChanName)
    EEG_ERO.Interest_ChanName_label = 0;
else
    
  chanName = EEG_ERO.Interest_ChanName; 
   if length(chanName) == 1
       EEG_ERO.Interest_ChanName_label = char(strcat(chanName));
   else
       EEG_ERO.Interest_ChanName_label = char(strcat(chanName{1}));
    for Numofsti = 1:length(chanName)-1
        EEG_ERO.Interest_ChanName_label = char(strcat(EEG_ERO.Interest_ChanName_label,',',num2str(chanName{Numofsti+1})));
    end
   end
   
end


geometry    = {[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],...
    [1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],...
    [1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5],[2 2],[1.5 0.5 1.5 0.5],[1.5 0.5 1.5 0.5]};
uilist = { { 'Style', 'text', 'string', ' Lower edge of the frequency (FFT filter)', 'horizontalalignment', 'right','fontweight', 'bold'},...
    { 'Style', 'text', 'string', EEG_ERO.fft_LowFre }, ...
    { 'Style', 'text', 'string', 'High edge of the frequency (FFT filter)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.fft_HighFre},...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Decomposition Level (Wavelet filter)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.wavelet_lv  },...
    { 'Style', 'text', 'string', 'Keep Coefficents in Scale (Wavelet filter)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.wavelet_kp_label},...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Number of remained components (t-PCA)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.PCA_R},...
    { 'Style', 'text', 'string', 'Secleted and projected components (t-PCA)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.PCA_K_label},...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Start time of an ERP (time domain analysis)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.ERPStart},...
    { 'Style', 'text', 'string', 'End time of an ERP (time domain analysis)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.ERPEnd},...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Start of the frequency range (run Morlet CWT)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.TF_LowFre},...
    { 'Style', 'text', 'string', 'End of the frequency range (run Morlet CWT)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.TF_HighFre},...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Bandwidth frequency (run Morlet CWT)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.TF_fb},...
    { 'Style', 'text', 'string', 'Center frequency (run Morlet CWT)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.TF_fc},...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Start time of the ERO (the rectangle method)', 'horizontalalignment', 'right','fontweight', 'bold'},...
    { 'Style', 'text', 'string', EEG_ERO.TF_ROI_TimeStart}, ...
    { 'Style', 'text', 'string', 'End time of the ERO (the rectangle method)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.TF_ROI_TimeEnd  },...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Start frequency of the ERO (the rectangle method)', 'horizontalalignment', 'right','fontweight', 'bold'},...
    { 'Style', 'text', 'string',EEG_ERO.TF_ROI_FreStart }, ...
    { 'Style', 'text', 'string', 'End frequency of the ERO (the rectangle method)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string', EEG_ERO.TF_ROI_FreEnd},...
    {},{},{},{},...
    { 'Style', 'text', 'string', 'Selected electrode(s) of interest', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'text', 'string',  EEG_ERO.Interest_ChanName_label},...
    {},{},{},{},...
    { 'style' 'text' 'string' 'The region was obtained by the Canny detector','fontweight', 'bold' }...
    { 'string' '' 'style' 'text'  'string'  EEG_ERO.TF_canny_index },...
    { 'style' 'text' 'string' 'Select the dataset for further analysis','fontweight', 'bold' }...
    { 'string' '' 'style' 'checkbox'  'value' 1 }};

[ results newcomments ] = inputgui( geometry, uilist,'functionhelp(''f_selecte_dataset'');',['The information for the selected dataset # ', ALLEEG_EROIN(result1{1}).filename]);

if isempty( results)
    
 ALLEEG_EROOUT= ALLEEG_EROIN;
 EEG_EROOUT = EEG_EROIN;  
 return;
end
 if results{end} == 1
    ALLEEG_EROOUT = ALLEEG_EROIN;
    EEG_EROOUT = ALLEEG_EROIN(result1{1});  
 else
 ALLEEG_EROOUT= ALLEEG_EROIN;
 EEG_EROOUT = EEG_EROIN;  
 return;
 end
 
disp(strcat('The dataset #',32,ALLEEG_EROIN(result1{1}).filename,32,' has been selected for further analysis'))
return;