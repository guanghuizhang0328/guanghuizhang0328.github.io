function [ALLEEG_EROOUT,EEG_EROOUT] = f_mcwt(ALLEEG_EROINPUT,EEG_EROINPUT);


if isempty(EEG_EROINPUT.data)
    errordlg2('Please import dataset');
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_EROINPUT;
    return;
end

if EEG_EROINPUT.TF_index ==1
    errordlg2('The data has been processed by time-frequency analysis');
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_EROINPUT;
    return;
end

if EEG_EROINPUT.sta_index == 1
    errordlg2('The time windows for  ERPs or the regions for EROs have been selected');
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_EROINPUT;
    return;
end

if ~isempty(EEG_EROINPUT.fft_index)
    filterFlag =2;
    
elseif ~isempty(EEG_EROINPUT.wavelet_index)
    filterFlag =1;
else
    filterFlag =3;
end
filterString = {'Wavelet filter','FFT filter','Conventional method'};
filterName = filterString{filterFlag};

if EEG_EROINPUT.fft_index ==1
    
    if EEG_EROINPUT.fft_LowFre ~=0 & EEG_EROINPUT.fft_HighFre~= 0
        
        filterName = char(strcat('Bandpass',32,filterName,32,num2str(EEG_EROINPUT.fft_LowFre),'-',num2str(EEG_EROINPUT.fft_HighFre),'Hz'));
        
    elseif ~isempty(EEG_EROINPUT.fft_LowFre) & EEG_EROINPUT.fft_HighFre==0
        filterName = char(strcat('Highpass ',32,filterName,32,num2str(EEG_EROINPUT.fft_LowFre),'Hz'));
    else
        
        filterName = char(strcat('Lowpass ',32,filterName,32,num2str(EEG_EROINPUT.fft_HighFre),'Hz'));
    end
end




uilist = { { 'style' 'text' 'string' 'Start of the interested frequency range' } ...
    { 'style' 'edit' 'string' '1' } ...
    { 'style' 'text' 'string' 'End of the interested frequency range' } ...
    { 'style' 'edit' 'string' '30' } ...
    { 'style' 'text' 'string' 'Bandwidth Frequency' } ...
    { 'style' 'edit' 'string' '1' } ...
    { 'style' 'text' 'string' 'Center Frequency' } ...
    { 'style' 'edit' 'string' '1' } ...
     { 'style' 'text' 'string' 'Frequency bins' } ...
    { 'style' 'edit' 'string' '100' } ...
    { 'style' 'text' 'string' 'Remove Baseline([min max] in ms) ' } ...
    { 'style' 'edit' 'string'  '-200'}...
    { 'style' 'text' 'string' '      --' } ...
    { 'style' 'edit' 'string'  '0'}};
geometry = { [3 2.1] [3 2.1] [3 2.1] [3 2.1] [3 2.1] [3 0.7 0.7 0.7]};

result = inputgui( 'geometry', geometry, 'uilist', uilist, 'title', 'TFA-run for Morlet CWT (f_mcwt)', ...
    'helpcom', 'pophelp(''f_mcwt'')');


if isempty(result)
 ALLEEG_EROOUT = ALLEEG_EROINPUT;
 EEG_EROOUT = EEG_EROINPUT;
 return;     
end

fl  	 = eval( result{1} );
fh 	 = eval( result{2} );
fb  	 = eval( result{3} );
Fc 	 = eval( result{4} );
FreNum = eval( result{5} );
%%%%%%% baseline ranges%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
BaselineString(1) = eval( result{6} );
BaselineString(2) = eval( result{7} );


DATA = [];
DATA = EEG_EROINPUT.data;
fs  =  EEG_EROINPUT.srate;
timeStart = EEG_EROINPUT.epochStart;
baselinePstart = ceil((BaselineString(1)-timeStart)/(1000/fs))+1;
baselinePend = ceil((BaselineString(2)-timeStart)/(1000/fs))+1;
%%
fIndex = logspace(log10(fl),log10(fh),FreNum);
scale = fs*Fc./fIndex;

wname =  ['cmor',num2str(fb),'-',num2str(Fc)];

% calculating the TFRs using morlet CWT
Hw_news =['Run morlet CWT..'];
Hw = waitbar(0,Hw_news);
for Numofsub = 1:size(DATA,4)
    waitbar(Numofsub/(size(EEG_EROINPUT.data,4)),Hw);
    for Numofsti = 1:size(DATA,3)
        for Numofchan = 1:size(DATA,1)
            
            data = squeeze(DATA(Numofchan,:,Numofsti,Numofsub));
            COEFS = cwt(data,scale,wname);
            TFR = abs(COEFS).^2;
            D_tf(:,:,Numofchan,Numofsti,Numofsub) = TFR-repmat(mean(TFR(:,baselinePstart:baselinePend),2),1,size(TFR,2));
            clear data;
        end
        
    end
end
close(Hw);
%%
EEG_EROINPUT.TF_index = 1;
EEG_EROINPUT.TF_LowFre = fl;

EEG_EROINPUT.TF_HighFre = fh;

EEG_EROINPUT.TF_fb = fb;

EEG_EROINPUT.TF_fc = Fc;

EEG_EROINPUT.TF_fIndex = fIndex;
EEG_EROINPUT.data = D_tf;
EEG_EROOUT = EEG_EROINPUT;
ALLEEG_EROOUT = f_eeg_store(ALLEEG_EROINPUT,EEG_EROOUT);
disp([filterName,':',32,'The TFRs of the signal have been calculated by morlet CWT']);
return;
