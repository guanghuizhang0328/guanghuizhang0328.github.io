function [ALLEEG_EROOUT,EEG_EROOUT] = f_plot_tfr(ALLEEG_EROINPUT,EEG_ERO);

if isempty(EEG_ERO.data)
    errordlg2('Cannot further analysis an empty dataset');
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end

if isempty(EEG_ERO.TF_index)
    errordlg2('Please run morlet CWT');
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end

if EEG_ERO.sta_index==1
    errordlg2('The regions for EROs have been selected');
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end


%% parameters
Sti_Name = EEG_ERO.Sti_Name;
GroupIdex =  EEG_ERO.GroupIdex;
NumGroup = max(GroupIdex(:));
timeStart = EEG_ERO.epochStart;
timeEnd = EEG_ERO.epochEnd;
chanlocs =  EEG_ERO.chanlocs;
fIndex = EEG_ERO.TF_fIndex;
fs = EEG_ERO.srate;
fl = EEG_ERO.TF_LowFre;
fh = EEG_ERO.TF_HighFre;
D  = double(EEG_ERO.data);
fs = EEG_ERO.srate;
[FreNum,samPoints,chanNum,stiNum,subNum] = size(D);
timeIndex = linspace(timeStart,timeEnd,samPoints);
%%
if ~isempty(EEG_ERO.fft_index)
    filterFlag =2;
elseif ~isempty(EEG_ERO.wavelet_index)
    filterFlag =1;
else
    filterFlag =3;
end
filterString = {'Wavelet filter','FFT filter','Conventional method'};
filterName = filterString{filterFlag};

if EEG_ERO.fft_index ==1
    
    if EEG_ERO.fft_LowFre ~=0 & EEG_ERO.fft_HighFre~= 0
        
        filterName = char(strcat('Bandpass',32,filterName,32,num2str(EEG_ERO.fft_LowFre),'-',num2str(EEG_ERO.fft_HighFre),'Hz'));
        
    elseif ~isempty(EEG_ERO.fft_LowFre) & EEG_ERO.fft_HighFre==0
        filterName = char(strcat('Highpass ',32,filterName,32,num2str(EEG_ERO.fft_LowFre),'Hz'));
    else
        
        filterName = char(strcat('Lowpass ',32,filterName,32,num2str(EEG_ERO.fft_HighFre),'Hz'));
    end
end


%%

promptstr    = { strvcat('Select interested electrode(s) ([]=all)')};
cbchanlocs = ['if isempty(EEG_ERO.chanlocs) ' ...
    '   errordlg2(''No chanlocs field'');' ...
    'else' ...
    '   tmpevent = EEG_ERO.chanlocs;' ...
    '   if isnumeric(EEG_ERO.chanlocs(1).labels),' ...
    '        [tmps,tmpstr] = pop_chansel(unique([ tmpevent.labels ]));' ...
    '   else,' ...
    '        [tmps,tmpstr] = pop_chansel(unique({ tmpevent.labels }));' ...
    '   end;' ...
    '   if ~isempty(tmps)' ...
    '       set(findobj(''parent'', gcbf, ''tag'', ''events''), ''string'', tmpstr);' ...
    '   end;' ...
    'end;' ...
    'clear tmps tmpevent tmpv tmpstr tmpfieldnames;' ];

geometry = { [2 1 0.5] [2 1.5]};
uilist = { { 'style' 'text'       'string' 'Select Interest Electrode(s) ([]=all))' } ...
    { 'style' 'edit'       'string' '' 'tag' 'events' } ...
    { 'style' 'pushbutton' 'string' '...' 'callback' cbchanlocs }...
    { 'style' 'text' 'string' 'Set the labels of the frequency range' } ...
    { 'style' 'edit' 'string' '1 2 3 5 8 15 20 30 ' }};
result = inputgui( geometry, uilist, 'pophelp(''pop_chansel'')', 'Select interested electrode(s)');

if isempty(result)
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end

y_labels = str2num(result{2});
if strcmp(result{1}, '')
    ChansOfInterestNumbers  = [1:length(chanlocs)];
else
    interestchanName =  regexp(result{1},'\s+','split');
    
    %% check input interest electrodes name(s) right or not
    count = 0;
    ChansOfInterestNumbers = [];
    for chanSelected = 1:length(interestchanName)
        for chan = 1:chanNum
            code = strcmp(chanlocs(chan).labels,interestchanName{chanSelected});
            if code == 1
                count =  count +1;
                ChansOfInterestNumbers(count) = chan;
            end
        end
    end
    if length(interestchanName) > length(ChansOfInterestNumbers)
        ChansOfInterestNumbers(length(ChansOfInterestNumbers)+1:length(interestchanName))=0;
    end
    min_Num = min(ChansOfInterestNumbers(:));
    if min_Num == 0
        errordlg2('Please Input Correct Electrode(s) Name')
    end
    
end;
%%
if  length(interestchanName) > 1
    filechanName = char(interestchanName{1});
    for Numofchannel = 1:length(interestchanName) - 1
        filechanName = char(strcat(filechanName,'-',interestchanName{Numofchannel+1}));
    end
else
    filechanName = char(interestchanName);
end

if ~isempty(EEG_ERO.PCA_index) 
    K = EEG_ERO.PCA_K;
    R = EEG_ERO.PCA_R;
    if  length(K) > 1
        filecomName = char(num2str(K(1)));
        for Numofchannel = 1:length(K) - 1
            filecomName = char(strcat(filecomName,32,num2str(K(Numofchannel+1))));
        end
    else
        filecomName = char(num2str(K(1)));
    end
   filterName = char(strcat(filterName,'_PCA_R_',num2str(R),'_K_', filecomName));
end

D_av =[];
for groupNum = 1:NumGroup
    idx1 =[];
    idx1 = find(GroupIdex == groupNum);
    D_av(:,:,:,:,groupNum) = squeeze(mean(D(:,:,:,:,idx1),5));
end

D_TF_AV = squeeze(mean(D_av(:,:,ChansOfInterestNumbers,:,:),3));
y_MIN = min(D_TF_AV(:));
y_MAX = max(D_TF_AV(:));

if stiNum*NumGroup == 4
    
    rowNum = 2;
    columnNum = 2;
elseif stiNum*NumGroup < 4
    rowNum = 1;
    columnNum = stiNum*NumGroup;
    
elseif (4< stiNum*NumGroup) & (stiNum*NumGroup <= 6)
    rowNum = 2;
    columnNum = 3;
elseif (6 < stiNum*NumGroup) & ( stiNum*NumGroup <= 9)
    rowNum = 3;
    columnNum = 3;
elseif (9 < stiNum*NumGroup) & ( stiNum*NumGroup <= 12)
    rowNum = 3;
    columnNum = 4;
elseif (12 < stiNum*NumGroup) & (stiNum*NumGroup <= 16)
    rowNum = 4;
    columnNum = 4;
elseif (16 < stiNum*NumGroup) & (stiNum*NumGroup <= 20)
    rowNum = 4;
    columnNum = 5;
end

compTitle = char(strcat(filterName,':',32,'The grand averaged TFRs at electrodes # ',32,filechanName));
figure('color','w','NumberTitle', 'off', 'Name',compTitle);
count = 0;
for groupNum = 1:NumGroup
    for sti = 1:stiNum
        count = count +1 ;
        subplot(rowNum,columnNum,count,'align');
        set(gca,'fontsize',16,'FontWeight','bold');
        pcolor(timeIndex,fIndex,squeeze(D_TF_AV(:,:,sti,groupNum)));
        shading('interp');
        hold on;
        set(gca,'yscale','log');
        set(gca,'ytick',y_labels);
        xlim([timeStart timeEnd]);
        ylim([fl fh]);
        caxis([y_MIN y_MAX]);
        title(Sti_Name{count});
        if count ==1
            xlabel('Time/ms','fontsize',14);
            ylabel('Frequency/Hz','fontsize',14);
        end
        hold on;
        colormap('jet');
        %%
        if count == NumGroup*stiNum
            last_subplot = subplot(rowNum,columnNum,count,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',10);
            set(last_subplot,'pos',last_subplot_position);
        end
    end
end

%%
uilist = {{ 'style' 'text' 'string' 'Using the selected the electrode(s) and the rectangle ','fontweight', 'bold' }...
    {},...
    { 'style' 'text' 'string' 'method to determine the ROI for statistical analysis  ?','fontweight', 'bold' }...
    { 'string' '' 'style' 'checkbox'  'value' 1 }};
geometry = {[1 0.2] [1 0.2]};
result = inputgui( 'geometry', geometry, 'uilist', uilist, 'title', '');

if isempty(result)
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    return;
end

code1 =  result{1} ;
%%
if code1 == 0
    ALLEEG_EROOUT = ALLEEG_EROINPUT;
    EEG_EROOUT = EEG_ERO;
    disp([filterName,':',32,'The TFR distributions have been ploted at the electrodes of interest #',32,filechanName]);
    return;
else
    
    geometry    = { [3 1] [3 1] [3 1] [3 1]};
    uilist = { ...
        { 'Style', 'text', 'string', 'Start time of the time-window (ms)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '' }, ...
        ...
        { 'Style', 'text', 'string', 'End time of the time-window (ms)', 'horizontalalignment', 'right','fontweight', 'bold', ...
        },   { 'Style', 'edit', 'string', '' },...
        { 'Style', 'text', 'string', 'Start of the frequency-range (Hz)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '' }, ...
        ...
        { 'Style', 'text', 'string', 'End of the frequency-range (Hz)', 'horizontalalignment', 'right','fontweight', 'bold', ...
        },   { 'Style', 'edit', 'string', '' }};
    
    [ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_plot_tfr'');', 'Set parameters for the recrangle method.');
    
    if isempty(results)
        ALLEEG_EROOUT = ALLEEG_EROINPUT;
        EEG_EROOUT = EEG_ERO;
        return;
    end
    
    if isempty(results{1}) | isempty(results{2}) | isempty(results{3}) | isempty(results{4})
        errordlg2('Please input four parameters');
        ALLEEG_EROOUT = ALLEEG_EROINPUT;
        EEG_EROOUT = EEG_ERO;
        return;
    end
    
    if (eval(results{1}) >= eval(results{2})) | (eval(results{3})>=eval(results{4}))
        errordlg2('The start time/frequency should be smaller than the end one');
        ALLEEG_EROOUT = ALLEEG_EROINPUT;
        EEG_EROOUT = EEG_ERO;
        return;
    end
    
    
    ERPStart =  eval(results{1});
    ERPEnd =  eval(results{2});
    intFstart =  eval(results{3});
    intFend   =  eval(results{4});
    
    ERPSampointStart = ceil((ERPStart - timeStart)/(1000/fs)) + 1 ;
    ERPSampointEnd = ceil((ERPEnd - timeStart)/(1000/fs)) + 1 ;
    
    
    [~,intFPstart] = min(abs(fIndex(:)-intFstart));
    [~,intFPend] = min(abs(fIndex(:)-intFend));
    
    
    TOPO_t = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:,:,:),2));
    TOPO = squeeze(mean(TOPO_t(intFPstart:intFPend,:,:,:),1));
    
    for groupNum = 1:NumGroup
        idx1 = find(GroupIdex == groupNum);
        topo_GA(:,:,groupNum) = squeeze(mean(TOPO(:,:,idx1),3));
        for sti = 1:stiNum
            temp = corrcoef(squeeze(TOPO(:,sti,idx1)));
            topo_similarity{:,:,sti,groupNum} = temp;
        end
    end
    
    if stiNum*NumGroup == 4
        
        rowNum = 2;
        columnNum = 2;
    elseif stiNum*NumGroup < 4
        rowNum = 1;
        columnNum = stiNum*NumGroup;
        
    elseif (4< stiNum*NumGroup) & (stiNum*NumGroup <= 6)
        rowNum = 2;
        columnNum = 3;
    elseif (6 < stiNum*NumGroup) & ( stiNum*NumGroup <= 9)
        rowNum = 3;
        columnNum = 3;
    elseif (9 < stiNum*NumGroup) & ( stiNum*NumGroup <= 12)
        rowNum = 3;
        columnNum = 4;
    elseif (12 < stiNum*NumGroup) & (stiNum*NumGroup <= 16)
        rowNum = 4;
        columnNum = 4;
    elseif (16 < stiNum*NumGroup) & (stiNum*NumGroup <= 20)
        rowNum = 4;
        columnNum = 5;
        
    end
    
    topo_min = min(topo_GA(:));
    topo_max = max(topo_GA(:));
    
    topo_Max = max(abs(topo_GA(:)));
    
    
    
%     if ~isempty(EEG_ERO.PCA_index)
%     compTitle = char(strcat(filterName,':',32,'The grand averaged topos. (',num2str(ERPStart),'-',num2str(ERPEnd),'ms-',num2str(intFstart),'-',num2str(intFend), '-Hz) for the projected comp. #',filecomName));
%     else  
%      compTitle = char(strcat(filterName,':',32,'The grand averaged topos. (',num2str(ERPStart),'-',num2str(ERPEnd),'ms-',num2str(intFstart),'-',num2str(intFend),'-Hz)'));  
%     end
%     
%     figure('color','w','NumberTitle', 'off', 'Name',compTitle);
%     count = 0;
%     for groupNum = 1:NumGroup
%         for sti = 1:stiNum
%             count = count +1;
%             %% plot topography
%             subplot(rowNum,columnNum,count,'align');
%             topoplot(squeeze(topo_GA(:,sti,groupNum)),chanlocs,'maplimits',[-topo_Max,topo_Max]);
%             hold on;
%             if count == NumGroup*stiNum
%                 last_subplot = subplot(rowNum,columnNum,count,'align');
%                 last_subplot_position = get(last_subplot,'position');
%                 colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',10);
%                 set(last_subplot,'pos',last_subplot_position);
%             end
%             hold on;
%             title(char(strcat(Sti_Name{count})));
%             
%         end
%     end
    
    
%     if ~isempty(EEG_ERO.PCA_index)
%     compTitle = char(strcat(filterName,':',32,'The similarity of topographies across all subs. (',num2str(ERPStart),'-',num2str(ERPEnd),'ms-',num2str(intFstart),'-',num2str(intFend), '-Hz) for the projected comp. #',filecomName));
%     else  
%      compTitle = char(strcat(filterName,':',32,'The similarity of topographies across all subs. (',num2str(ERPStart),'-',num2str(ERPEnd),'ms-',num2str(intFstart),'-',num2str(intFend),'-Hz)'));  
%     end
%     
%     
%     figure('color','w','NumberTitle', 'off', 'Name',compTitle);
%     count = 0;
%     for groupNum = 1:NumGroup
%         for sti = 1:stiNum
%             count = count +1;
%             %% plot similarity of topographies across all subjects for each condition
%             subplot(rowNum,columnNum,count,'align');
%             imagesc(squeeze(topo_similarity{:,:,sti,groupNum}));
%             hold on;
%             set(gca,'clim',[-1 1]);
%             if count == NumGroup*stiNum
%                 last_subplot = subplot(rowNum,columnNum,count,'align');
%                 last_subplot_position = get(last_subplot,'position');
%                 colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',10);
%                 set(last_subplot,'pos',last_subplot_position);
%             end
%             hold on;
%             colormap('jet');
%             title(char(strcat(Sti_Name{count})));
%             if count == 1
%                 xlabel('Subject #');
%                 ylabel('Subject #');
%             end
%         end
%     end
%     
    
    
    
    EEG_ERO.sta_index = 1;
    EEG_ERO.TF_ROI_index = 1;
    EEG_ERO.TF_ROI_TimeStart = ERPStart;
    EEG_ERO.TF_ROI_TimeEnd = ERPEnd;
    EEG_ERO.TF_ROI_FreStart =  intFstart;
    EEG_ERO.TF_ROI_FreEnd = intFend;
    EEG_ERO.Interest_ChanName = interestchanName;
    EEG_ERO.data = squeeze(mean(TOPO(ChansOfInterestNumbers,:,:),1));
    EEG_EROOUT = EEG_ERO;
    ALLEEG_EROOUT = f_eeg_store(ALLEEG_EROINPUT,EEG_EROOUT);
    disp([filterName,':',32,'The regions of the interested EROs  have been selected at the electrodes of interest #',32,filechanName,32,'via the rectangle method']);
end
return;
