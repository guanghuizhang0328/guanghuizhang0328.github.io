function EEG_ERO = f_eeg_ero_emptyset(EEG_EROINPUT);

EEG_ERO.srate =[];
EEG_ERO.epochStart =[];
EEG_ERO.epochEnd =[];
EEG_ERO.data =[];
EEG_ERO.Sti_Name =[];
EEG_ERO.Sti_Name_within =[];
EEG_ERO.chanlocs =[];
EEG_ERO.GroupIdex =[];
EEG_ERO.betwSub_level = [];
EEG_ERO.withSub_level_one = [];
EEG_ERO.withSub_level_two = [];
EEG_ERO.withSub_level_three = [];
EEG_ERO.Interest_ChanName = [];
EEG_ERO.ERPStart =[];
EEG_ERO.ERPEnd =[];
EEG_ERO.measurement_index = 0;

%%
EEG_ERO.fft_index = [];
EEG_ERO.fft_LowFre = [];
EEG_ERO.fft_HighFre = [];
%%
EEG_ERO.wavelet_index = [];
EEG_ERO.wavelet_lv = [];
EEG_ERO.wavelet_kp = [];
EEG_ERO.measurement_index = 0;
%%
EEG_ERO.PCA_index = [];
EEG_ERO.PCA_R = [];
EEG_ERO.PCA_K = [];

EEG_ERO.PCA_T = [];
EEG_ERO.PCA_Y = [];
EEG_ERO.PCA_peak_T = [];
EEG_ERO.PCA_lambda = [];

%%
EEG_ERO.TF_index = [];
EEG_ERO.TF_LowFre = [];
EEG_ERO.TF_HighFre = [];
EEG_ERO.TF_fb = [];
EEG_ERO.TF_fc = [];
EEG_ERO.TF_fIndex = [];
EEG_ERO.TF_ROI_index = [];
EEG_ERO.TF_ROI_TimeStart = [];
EEG_ERO.TF_ROI_TimeEnd = [];
EEG_ERO.TF_ROI_FreStart = [];
EEG_ERO.TF_ROI_FreEnd = [];


EEG_ERO.TF_canny_index = [];
EEG_ERO.TF_canny_t1 = [];
EEG_ERO.TF_canny_t2 = [];
EEG_ERO.TF_canny_deviation = [];
EEG_ERO.TF_canny_sti_label = [];
EEG_ERO.TF_canny_sti_Path = [];
EEG_ERO.TF_canny_boundaryNum = [];
EEG_ERO.TF_canny_save_parameters.sti = [];
EEG_ERO.TF_canny_save_parameters.I = [];
EEG_ERO.TF_canny_save_parameters.boundary_pixel = [];
EEG_ERO.TF_canny_I = [];
EEG_ERO.TF_canny_boundary_pixel = [];
EEG_ERO.TF_canny_Interest_ChanNum = [];
%%
EEG_ERO.sta_index = 0;
EEG_ERO.filename = {};

return;
