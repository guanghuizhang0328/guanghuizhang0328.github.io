function varargout = f_edgedetection_canny(varargin)
% F_EDGEDETECTION_CANNY MATLAB code for f_edgedetection_canny.fig
%      F_EDGEDETECTION_CANNY, by itself, creates a new F_EDGEDETECTION_CANNY or raises the existing
%      singleton*.
%
%      H = F_EDGEDETECTION_CANNY returns the handle to a new F_EDGEDETECTION_CANNY or the handle to
%      the existing singleton*.
%
%      F_EDGEDETECTION_CANNY('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in F_EDGEDETECTION_CANNY.M with the given input arguments.
%
%      F_EDGEDETECTION_CANNY('Property','Value',...) creates a new F_EDGEDETECTION_CANNY or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before f_edgedetection_canny_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to f_edgedetection_canny_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help f_edgedetection_canny

% Last Modified by GUIDE v2.5 06-Apr-2020 20:17:42

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @f_edgedetection_canny_OpeningFcn, ...
    'gui_OutputFcn',  @f_edgedetection_canny_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before f_edgedetection_canny is made visible.
function f_edgedetection_canny_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to f_edgedetection_canny (see VARARGIN)

% Choose default command line output for f_edgedetection_canny
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);



% UIWAIT makes f_edgedetection_canny wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = f_edgedetection_canny_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROIN = evalin('base', 'ALLEEG_ERO');
assignin('base','EEG_ERO',EEG_EROIN);
assignin('base','ALLEEG_ERO',ALLEEG_EROIN);

% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'Morlet CWT',filesep,'canny detector',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
EEG_EROOUT = f_selecte_picture_canny(EEG_EROIN);
assignin('base', 'EEG_ERO',EEG_EROOUT);

%%%%%%%%
function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double



% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double
%



% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double



% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double




% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);
if isempty(handles.axes1)
    return;
end
newFig = figure;
set(newFig,'Visible','off');
newAxes = copyobj(handles.axes1,newFig);
% set(newAxes,'Units','default','Position','default');

[filename,pathname,filterindex]= uiputfile({'*.bmp';'*.tif';'*.png';'*.jpg';},'save picture');
if filterindex==0
    return;
else
    fpath= fullfile(pathname,filename);
    %     f = getframe(newFig);
    %     f = frame2im(f);
    % imwrite(f,fpath);
    
    pix=getframe(handles.axes1);
    imwrite(pix.cdata,fpath);
end
return;


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
EEG_ERO = evalin('base', 'EEG_ERO');

EEG_ERO.TF_canny_t1 = str2num(get(handles.edit2,'string'));
EEG_ERO.TF_canny_t2 = str2num(get(handles.edit3,'string'));
EEG_ERO.TF_canny_deviation = str2num(get(handles.edit4,'string'));
EEG_ERO.TF_canny_boundaryNum = str2num(get(handles.edit5,'string'));
if isempty(EEG_ERO.data)
    errordlg2('Cannot further analysis an empty dataset');
    return;
end

if isempty(EEG_ERO.sta_index)
    errordlg2('The time windows for  ERPs or the regions for EROs have been selected');
    return;
end
if isempty(EEG_ERO.TF_index)
    errordlg2('Please run morlet CWT');
    return;
end

PCA_index = EEG_ERO.PCA_index;


if isempty(EEG_ERO.TF_canny_deviation) & isempty(EEG_ERO.TF_canny_t1) & isempty(EEG_ERO.TF_canny_t2)
    
    boundary_Num = EEG_ERO.TF_canny_boundaryNum;
    cla reset ;
    X =imread(EEG_ERO.TF_canny_sti_Path{1});
    a = X;
    b=a;
    level= 5;
    [m,n,d]=size(a);
    
    if  isempty(PCA_index)
        
        %% red ones
        for i=1:m
            for j=1:n
                if((a(i,j,1)-a(i,j,2)>level)&&(a(i,j,1)-a(i,j,3)>level))
                    
                    b(i,j,1)= 0;
                    
                    b(i,j,2)=0;
                    
                    b(i,j,3)=0;
                else
                    b(i,j,1)=255;
                    
                    b(i,j,2)=255;
                    
                    b(i,j,3)=255;
                end
                
            end
            
        end
        
        I =  rgb2gray(b);
        BW1 = edge(I,'canny');
        [B,L] = bwboundaries(BW1,'holes');
        
        %%blue ones
%         for i=1:m
%             for j=1:n
%                 if((a(i,j,3)-a(i,j,1)>level)&&(a(i,j,3)-a(i,j,2)>level))
%                     C(i,j,1)= 0;
%                     
%                     C(i,j,2)=0;
%                     
%                     C(i,j,3)=0;
%                 else
%                     C(i,j,1)=255;
%                     
%                     C(i,j,2)=255;
%                     
%                     C(i,j,3)=255;
%                 end
%                 
%             end
%             
%         end
%         
%         I2 =  rgb2gray(C);
%         BW2 = edge(I2,'canny');
%         [B2,L2] = bwboundaries(BW2,'holes');
%         
%         B = [B1;B2];
%         L = [L1;L2];
%         clear B1;
%         clear B2;
%         clear L1;
%         clear L2;
        if isempty(B)
           errordlg2(['No edges were detected when using default parameters!!!']); 
        return;
        end
    else
        
        for i=1:m
            for j=1:n
                if((a(i,j,1)-a(i,j,2)>level)&&(a(i,j,1)-a(i,j,3)>level))
                    b(i,j,1)= 0;
                    b(i,j,2)=0;
                    b(i,j,3)=0;
                else
                    b(i,j,1)=255;
                    b(i,j,2)=255;
                    b(i,j,3)=255;
                end
            end
            
        end
        %%
        I =  rgb2gray(b);
        BW = edge(I,'canny');
        [B,L] = bwboundaries(BW,'holes');
        if isempty(B)
           errordlg2(['No edges were detected when using default parameters!!!']); 
           return;
        end
        
    end
    
    imshow(X);
    xlim([0 size(I,2)]);
    ylim([0 size(I,1)]);
    hold on;
    axes(handles.axes1);
    colors=['b' 'g' 'r' 'c' 'm' 'y'];
    if isempty(boundary_Num)
        boundary_Num = 0;
    end
    
    if boundary_Num == 0
        for k = 1:length(B)
            boundary = B{k};
            cidx = mod(k,length(colors))+1;
            plot(boundary(:,2),boundary(:,1),'k','linewidth',2);
            rndRow = ceil(length(boundary)/(mod(rand*k,7)+1));
            col = boundary(rndRow,2); row = boundary(rndRow,1);
            h = text(col+1, row-1, num2str(L(row,col)));
            set(h,'Color',colors(cidx),'FontSize',14,'FontWeight','bold');
        
        end
    else
        boundary = B{boundary_Num};
        plot(boundary(:,2),boundary(:,1),'k','linewidth',2);
    end
    
    
    %%%%%%
else
    
    count_Num = 0;
    if isempty(EEG_ERO.TF_canny_deviation)
        errordlg2(strcat('Please set the value for Std. deviation'));
        count_Num = count_Num +1;
    end
    
    if EEG_ERO.TF_index ~=1
        errordlg2('Please run morlet CWT');
        count_Num = count_Num +1;
    end
    
    if isempty(EEG_ERO.TF_canny_t1) & ~isempty(EEG_ERO.TF_canny_t2)
        errordlg2('Please set the value for T1');
        count_Num = count_Num +1;
    end
    
    if EEG_ERO.TF_canny_t2 >1 | EEG_ERO.TF_canny_t1 >1
        errordlg2('Threshold value must be smaller than 1');
        count_Num = count_Num +1;
    end
    
    
    
    if EEG_ERO.TF_canny_t2 > EEG_ERO.TF_canny_t1
        errordlg2('Low threshold value must be smaller than the high one');
        count_Num = count_Num +1;
    end
    
    if length(EEG_ERO.TF_canny_boundaryNum)>1
        errordlg2('Please select one boundary number');
        count_Num = count_Num +1;
    end
    
    if isempty(EEG_ERO.TF_canny_sti_Path)
        errordlg2('Can not find the related picture');
        count_Num = count_Num +1;
    end
    
    if count_Num == 0
        
        if isempty(EEG_ERO.TF_canny_t2)
            Thresh = EEG_ERO.TF_canny_t1;
        else
            Thresh = [EEG_ERO.TF_canny_t2,EEG_ERO.TF_canny_t1];
        end
        std_Devi = EEG_ERO.TF_canny_deviation;
        
        boundary_Num = EEG_ERO.TF_canny_boundaryNum;
        cla reset ;
        X =imread(EEG_ERO.TF_canny_sti_Path{length(EEG_ERO.TF_canny_sti_Path)});
        I =  rgb2gray(X);
        BW = edge(I,'canny',Thresh,std_Devi);
        [B,L] = bwboundaries(BW,'holes');
        imshow(X);
        xlim([0 size(I,2)]);
        ylim([0 size(I,1)]);
        hold on;
        axes(handles.axes1);
        colors=['b' 'g' 'r' 'c' 'm' 'y'];
        if isempty(boundary_Num)
            boundary_Num =0;
        end
        
        if boundary_Num == 0
            for k = 1:length(B)
                boundary = B{k};
                cidx = mod(k,length(colors))+1;
                plot(boundary(:,2),boundary(:,1),'k','linewidth',2);
                
                rndRow = ceil(length(boundary)/(mod(rand*k,7)+1));
                col = boundary(rndRow,2); row = boundary(rndRow,1);
                h = text(col+1, row-1, num2str(L(row,col)));
                set(h,'Color',colors(cidx),'FontSize',14,'FontWeight','bold');
            end
        else
            boundary = B{boundary_Num};
            plot(boundary(:,2),boundary(:,1),'k','linewidth',2);
        end
    else
        assignin('base', 'EEG_ERO',EEG_ERO);
        return;
    end
end
assignin('base', 'EEG_ERO',EEG_ERO);
return;


% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'Morlet CWT',filesep,'canny detector',filesep));
addpath(genpath(Currentpath));


EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROIN = evalin('base', 'ALLEEG_ERO');

EEG_EROIN.TF_canny_t1 = str2num(get(handles.edit2,'string'));
EEG_EROIN.TF_canny_t2 = str2num(get(handles.edit3,'string'));
EEG_EROIN.TF_canny_deviation = str2num(get(handles.edit4,'string'));
EEG_EROIN.TF_canny_boundaryNum = str2num(get(handles.edit5,'string'));

[ALLEEG_EROOUT,EEG_EROOUT] = f_save_parameters_canny(ALLEEG_EROIN,EEG_EROIN);
assignin('base','EEG_ERO',EEG_EROOUT);
assignin('base','ALLEEG_ERO',ALLEEG_EROOUT);
