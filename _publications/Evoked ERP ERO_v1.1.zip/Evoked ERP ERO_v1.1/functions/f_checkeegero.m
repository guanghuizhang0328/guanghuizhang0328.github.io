function f_checkeegero(EEG_ERO)


[chanNum,samPoint,stiNum,subNum] = size(EEG_ERO.data);

stiName = EEG_ERO.Sti_Name;

GroupIndex = EEG_ERO.GroupIdex;
chanlocs = EEG_ERO.chanlocs;

if length(chanlocs) ~= chanNum
     errordlg2('Please input correct channel location file');
elseif length(GroupIndex) ~= subNum
    errordlg2('Please input correct number of subjects for each group !!!'); 
elseif length(stiName) ~= stiNum*max(GroupIndex(:))
    
    errordlg2('Please input correct name of stimuli or between subject factors!!!');
    
end

return