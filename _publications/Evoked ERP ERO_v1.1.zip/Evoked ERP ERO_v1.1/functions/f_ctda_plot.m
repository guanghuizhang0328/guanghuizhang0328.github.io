function [ALLEEG_EROOUTPUT,EEG_EROOUTPUT]= f_ctda_plot(ALLEEG_EROINPUT,EEG_EROIN);
if isempty(EEG_EROIN.data)
    errordlg2('Cannot further analysis an empty dataset');
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end

if EEG_EROIN.TF_index == 1
    errordlg2('The signal has been processed via time-frequency analysis');
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end

if EEG_EROIN.sta_index == 1
    errordlg2('The time windows for  ERPs or the regions for EROs have been selected');
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end

if EEG_EROIN.PCA_index ==1
    errordlg2('>t-PCA>Plot projected components');
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end

%% parameters

Sti_Name = EEG_EROIN.Sti_Name;
GroupIdex =  EEG_EROIN.GroupIdex;
NumGroup = max(GroupIdex(:));
timeStart = EEG_EROIN.epochStart;
timeEnd = EEG_EROIN.epochEnd;
chanlocs =  EEG_EROIN.chanlocs;
D   = double(EEG_EROIN.data);
fs = EEG_EROIN.srate;
[chanNum,samPoints,stiNum,subNum] = size(D);
timeIndex = linspace(timeStart,timeEnd,samPoints);

if ~isempty(EEG_EROIN.fft_index)
 filterFlag =2;   
    
elseif ~isempty(EEG_EROIN.wavelet_index)
   filterFlag =1;     
else
     filterFlag =3; 
end    
filterString = {'Wavelet filter','FFT filter','Conventional method'};
filterName = filterString{filterFlag};

if EEG_EROIN.fft_index ==1
    
    if EEG_EROIN.fft_LowFre ~=0 & EEG_EROIN.fft_HighFre~= 0
        
        filterName = char(strcat('Bandpass',filterName,32,num2str(EEG_EROIN.fft_LowFre),'-',num2str(EEG_EROIN.fft_HighFre),'Hz'));
        
    elseif ~isempty(EEG_EROIN.fft_LowFre) & EEG_EROIN.fft_HighFre==0
        filterName = char(strcat('Highpass ',filterName,num2str(EEG_EROIN.fft_LowFre),'Hz'));
    else
        
        filterName = char(strcat('Lowpass ',filterName,num2str(EEG_EROIN.fft_HighFre),'Hz'));
        
    end
end

%% Input the name of electrodes of interest
EEG_ERO = EEG_EROIN;
promptstr    = { strvcat('Select Interest Electrode(s) ([]=all)')};
cbchanlocs = ['if isempty(EEG_ERO.chanlocs) ' ...
    '   errordlg2(''No chanlocs field'');' ...
    'else' ...
    '   tmpevent = EEG_ERO.chanlocs;' ...
    '   if isnumeric(EEG_ERO.chanlocs(1).labels),' ...
    '        [tmps,tmpstr] = pop_chansel(unique([ tmpevent.labels ]));' ...
    '   else,' ...
    '        [tmps,tmpstr] = pop_chansel(unique({ tmpevent.labels }));' ...
    '   end;' ...
    '   if ~isempty(tmps)' ...
    '       set(findobj(''parent'', gcbf, ''tag'', ''events''), ''string'', tmpstr);' ...
    '   end;' ...
    'end;' ...
    'clear tmps tmpevent tmpv tmpstr tmpfieldnames;' ];

geometry = { [2 1 0.5]};
uilist = { { 'style' 'text'       'string' 'Select interested Electrode(s) ([]=all))' } ...
    { 'style' 'edit'       'string' '' 'tag' 'events' } ...
    { 'style' 'pushbutton' 'string' '...' 'callback' cbchanlocs }};
result = inputgui( geometry, uilist, 'pophelp(''pop_chansel'')', 'Select interested electrode(s)');

if isempty(result)
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end


if strcmp(result{1}, '')
    ChansOfInterestNumbers  = [1:length(chanlocs)];
else
    
    interestchanName =  regexp(result{1},'\s+','split');
    
    %% check input interest electrodes name(s) right or not
    count = 0;
    ChansOfInterestNumbers = [];
    for chanSelected = 1:length(interestchanName)
        for chan = 1:chanNum
            code = strcmp(chanlocs(chan).labels,interestchanName{chanSelected});
            if code == 1
                count =  count +1;
                ChansOfInterestNumbers(count) = chan;
            end
        end
    end
    if length(interestchanName) > length(ChansOfInterestNumbers)
        ChansOfInterestNumbers(length(ChansOfInterestNumbers)+1:length(interestchanName))=0;
    end
    min_Num = min(ChansOfInterestNumbers(:));
    if min_Num == 0
        errordlg2('Please Input Correct Electrode(s) Name');
    end
    
end;
%%
if  length(interestchanName) > 1
    filechanName = char(interestchanName{1});
    for Numofchannel = 1:length(interestchanName) - 1
        filechanName = char(strcat(filechanName,'-',interestchanName{Numofchannel+1}));
    end
else
    filechanName = char(interestchanName);
end
%%



%%
for groupNum = 1:NumGroup
    idx1 = find(GroupIdex == groupNum);
    D_av(:,:,:,groupNum) = squeeze(mean(D(:,:,:,idx1),4));
end
temp = squeeze(mean(D_av(ChansOfInterestNumbers,:,:,:),1));
y_MIN = 1.2*min(temp(:));
y_MAX = 1.2*max(temp(:));
D_P = reshape(temp,samPoints,stiNum*NumGroup);
clear temp;


compTitle = char(strcat(filterName,32,': The grand averaged waveforms'));
figure('color','w','NumberTitle', 'off', 'Name',compTitle);
%             set(gcf,'outerposition',get(0,'screensize'));
set(gca,'fontsize',16,'FontWeight','bold');
hold on;
plot(timeIndex,D_P);
set(gca,'ydir','reverse','FontWeight','bold');
xlim([timeIndex(1),timeIndex(end)]);
ylim([y_MIN,y_MAX]);
grid on;
hold on;
xlabel(['Time/ms'],'fontsize',14);
ylabel(['Amplitude/\muV'],'fontsize',14);
hold on;
legend(Sti_Name,'location','best');
title(filechanName);
%% %%%%%% plot topography
clear D_av; clear D_P;

uilist = {{ 'style' 'text' 'string' 'Plot topograpgy within a time window?','fontweight', 'bold' }...
    { 'string' '' 'style' 'checkbox'  'value' 1 },...
    { 'style' 'text' 'string' 'Yes, press any key!','fontweight', 'bold' }...
    { }};
geometry = {[1 0.2],[1 0.2]};

result = inputgui( 'geometry', geometry, 'uilist', uilist, 'title', '');

if isempty(result)
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end

code =  result{1} ;
if code == 0
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end

pause;
geometry    = { [3 1] [3 1] [3 1]};
uilist = { ...
    { 'Style', 'text', 'string', 'Start time of ERP (ms)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '' }, ...
    ...
    { 'Style', 'text', 'string', 'End time of ERP (ms)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'edit', 'string', '' },...
    { 'Style', 'text', 'string', 'Measurement (1.peak; 2.mean)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'edit', 'string', '1' }};

[ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_projectioncomponents'');', 'Set parameters for plotting topo.');

if isempty(results)
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end

if isempty(results{1}) | isempty(results{2})
    errordlg2('Please set values for the time-window');
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end


ERPStart = eval(results{1});
ERPEnd = eval(results{2});
measurementNum = eval(results{3});

ERPSampointStart = ceil((ERPStart - timeStart)/(1000/fs)) + 1 ;
ERPSampointEnd = ceil((ERPEnd - timeStart)/(1000/fs)) + 1 ;
if measurementNum == 2
    TOPO = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:,:),2));
else
    for Numsub = 1:subNum
        for Numsti = 1:stiNum
            for Numchan = 1:chanNum
                temp = squeeze(D(Numchan,ERPSampointStart:ERPSampointEnd,Numsti,Numsub))';
                [mV  Idx] = max(abs(temp(:)));
                TOPO(Numchan,Numsti,Numsub)  = squeeze(D(Numchan,ERPSampointStart+Idx,Numsti,Numsub));
            end
        end
    end
end
clear temp;

for groupNum = 1:NumGroup
    idx1 = find(GroupIdex == groupNum);
    topo_GA(:,:,groupNum) = squeeze(mean(TOPO(:,:,idx1),3));
    for sti = 1:stiNum
        temp = corrcoef(squeeze(TOPO(:,sti,idx1)));
        topo_similarity{:,:,sti,groupNum} = temp;
    end
end

clear temp;


if stiNum*NumGroup == 4
    
    rowNum = 2;
    columnNum = 2;
elseif stiNum*NumGroup < 4
    rowNum = 1;
    columnNum = stiNum*NumGroup;
    
elseif (4< stiNum*NumGroup) & (stiNum*NumGroup <= 6)
    rowNum = 2;
    columnNum = 3;
elseif (6 < stiNum*NumGroup) & ( stiNum*NumGroup <= 9)
    rowNum = 3;
    columnNum = 3;
elseif (9 < stiNum*NumGroup) & ( stiNum*NumGroup <= 12)
    rowNum = 3;
    columnNum = 4;
elseif (12 < stiNum*NumGroup) & (stiNum*NumGroup <= 16)
    rowNum = 4;
    columnNum = 4;
elseif (16 < stiNum*NumGroup) & (stiNum*NumGroup <= 20)
    rowNum = 4;
    columnNum = 5;
    
end

topo_min = min(topo_GA(:));
topo_max = max(topo_GA(:));

compTitle = char(strcat(filterName,32,': The grand averaged topographies (',num2str(ERPStart),'-',num2str(ERPEnd),'ms)'));
figure('color','w','NumberTitle', 'off', 'Name',compTitle);
count = 0;
for groupNum = 1:NumGroup
    for sti = 1:stiNum
        count = count +1;
        %% plot topography
        subplot(rowNum,columnNum,count,'align');
        topoplot(squeeze(topo_GA(:,sti,groupNum)),chanlocs,'maplimits',[topo_min,topo_max]);
        hold on;
        if count == NumGroup*stiNum
            last_subplot = subplot(rowNum,columnNum,count,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',10);
            set(last_subplot,'pos',last_subplot_position);
        end
        hold on;
        title(char(strcat(Sti_Name{count})));
        
    end
end


compTitle = char(strcat(filterName,32,': The similarity of topographies across all subs.(',num2str(ERPStart),'-',num2str(ERPEnd),'ms)'));
figure('color','w','NumberTitle', 'off', 'Name',compTitle);
count = 0;
for groupNum = 1:NumGroup
    for sti = 1:stiNum
        count = count +1;
        %% plot similarity of topographies across all subjects for each condition
        subplot(rowNum,columnNum,count,'align');
        imagesc(squeeze(topo_similarity{:,:,sti,groupNum}));
        hold on;
        set(gca,'clim',[-1 1]);
        if count == NumGroup*stiNum
            last_subplot = subplot(rowNum,columnNum,count,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',10);
            set(last_subplot,'pos',last_subplot_position);
        end
        hold on;
        colormap('jet');
        title(char(strcat(Sti_Name{count})));
        if count == 1
            xlabel('Subject #');
            ylabel('Subject #');
        end
    end
end

%%
uilist = {{ 'style' 'text' 'string' 'Using the selected the electrode(s) and time window for further analysis ?','fontweight', 'bold' }...
    { 'string' '' 'style' 'checkbox'  'value' 1 }};
geometry = {[1 0.2]};
result = inputgui( 'geometry', geometry, 'uilist', uilist, 'title', '');

if isempty(result)
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
end


code2 =  result{1} ;
%%
if code2 == 0
    ALLEEG_EROOUTPUT = ALLEEG_EROINPUT;
    EEG_EROOUTPUT = EEG_EROIN;
    return;
else
    EEG_EROIN.sta_index = 1;
    EEG_EROIN.measurement_index = measurementNum;
    EEG_EROIN.data = squeeze(mean(TOPO(ChansOfInterestNumbers,:,:),1));
    EEG_EROIN.ERPStart = ERPStart;
    EEG_EROIN.ERPEnd = ERPEnd;
    EEG_EROIN.Interest_ChanName = interestchanName;
    EEG_EROOUTPUT = EEG_EROIN;
    ALLEEG_EROOUTPUT = f_eeg_store(ALLEEG_EROINPUT,EEG_EROOUTPUT);
end
disp(strcat('The temporal and spatial distributions have been plotted'));
return;
