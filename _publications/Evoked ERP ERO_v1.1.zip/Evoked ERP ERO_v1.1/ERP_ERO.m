function varargout = ERP_ERO(varargin)
% ERP_ERO MATLAB code for ERP_ERO.fig
%      ERP_ERO, by itself, creates a new ERP_ERO or raises the existing
%      singleton*.
%
%      H = ERP_ERO returns the handle to a new ERP_ERO or the handle to
%      the existing singleton*.
%
%      ERP_ERO('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ERP_ERO.M with the given input arguments.
%
%      ERP_ERO('Property','Value',...) creates a new ERP_ERO or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ERP_ERO_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ERP_ERO_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ERP_ERO

% Last Modified by GUIDE v2.5 18-May-2020 14:45:09

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ERP_ERO_OpeningFcn, ...
                   'gui_OutputFcn',  @ERP_ERO_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ERP_ERO is made visible.
function ERP_ERO_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ERP_ERO (see VARARGIN)

% Choose default command line output for ERP_ERO
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ERP_ERO wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ERP_ERO_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
xx = imread('Demo.tif'); %% need to change!!!
imshow(xx);
% set(gca,'looseinset',get(gca,'tightinset'));
title('Extracting the evoked ERP/ERO from  averaged ERP dataset (V 1.1)')

EEG_ERO.srate =[];
EEG_ERO.epochStart =[];
EEG_ERO.epochEnd =[];
EEG_ERO.data =[];
EEG_ERO.Sti_Name =[];
EEG_ERO.Sti_Name_within =[];
EEG_ERO.chanlocs =[];
EEG_ERO.GroupIdex =[];
EEG_ERO.betwSub_level = [];
EEG_ERO.withSub_level_one = [];
EEG_ERO.withSub_level_two = [];
EEG_ERO.withSub_level_three = [];
EEG_ERO.Interest_ChanName = [];
EEG_ERO.ERPStart =[];
EEG_ERO.ERPEnd =[];
EEG_ERO.measurement_index = 0;

%%
EEG_ERO.fft_index = [];
EEG_ERO.fft_LowFre = [];
EEG_ERO.fft_HighFre = [];
%%
EEG_ERO.wavelet_index = [];
EEG_ERO.wavelet_lv = [];
EEG_ERO.wavelet_kp = [];
EEG_ERO.measurement_index = 0;
%%
EEG_ERO.PCA_index = [];
EEG_ERO.PCA_R = [];
EEG_ERO.PCA_K = [];

EEG_ERO.PCA_T = [];
EEG_ERO.PCA_Y = [];
EEG_ERO.PCA_peak_T = [];
EEG_ERO.PCA_lambda = [];

%%
EEG_ERO.TF_index = [];
EEG_ERO.TF_LowFre = [];
EEG_ERO.TF_HighFre = [];
EEG_ERO.TF_fb = [];
EEG_ERO.TF_fc = [];
EEG_ERO.TF_fIndex = [];
EEG_ERO.TF_ROI_index = [];
EEG_ERO.TF_ROI_TimeStart = [];
EEG_ERO.TF_ROI_TimeEnd = [];
EEG_ERO.TF_ROI_FreStart = [];
EEG_ERO.TF_ROI_FreEnd = [];


EEG_ERO.TF_canny_index = [];
EEG_ERO.TF_canny_t1 = [];
EEG_ERO.TF_canny_t2 = [];
EEG_ERO.TF_canny_deviation = [];
EEG_ERO.TF_canny_sti_label = [];
EEG_ERO.TF_canny_sti_Path = [];
EEG_ERO.TF_canny_boundaryNum = [];
EEG_ERO.TF_canny_save_parameters.sti = [];
EEG_ERO.TF_canny_save_parameters.I = [];
EEG_ERO.TF_canny_save_parameters.boundary_pixel = [];
EEG_ERO.TF_canny_I = [];
EEG_ERO.TF_canny_boundary_pixel = [];
EEG_ERO.TF_canny_Interest_ChanNum = [];
%%
EEG_ERO.sta_index = 0;
EEG_ERO.filename = {};

ALLEEG_ERO = [];

 eeglab;

assignin('base', 'EEG_ERO',EEG_ERO);
assignin('base', 'ALLEEG_ERO',ALLEEG_ERO);
% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_importdata_Callback(hObject, eventdata, handles)
% hObject    handle to f_importdata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));

EEG_EROINPUT = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');

[EEG_EROOUT, ALLEEG_EROOUT] = f_importdata(EEG_EROINPUT,ALLEEG_EROINPUT);
assignin('base', 'ALLEEG_ERO',ALLEEG_EROOUT);
assignin('base', 'EEG_ERO',EEG_EROOUT);
% --------------------------------------------------------------------
function f_importprocesseddata_Callback(hObject, eventdata, handles)
% hObject    handle to f_importprocesseddata (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));
EEG_EROINPUT = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');
[EEG_EROOUT, ALLEEG_EROOUT] = f_importprocesseddata(EEG_EROINPUT ,ALLEEG_EROINPUT);
assignin('base', 'ALLEEG_ERO',ALLEEG_EROOUT);
assignin('base', 'EEG_ERO',EEG_EROOUT);


% --------------------------------------------------------------------
function f_savemat_Callback(hObject, eventdata, handles)
% hObject    handle to f_savemat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));
EEG_ERO = evalin('base', 'EEG_ERO');
f_savemat(EEG_ERO);

% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_FFTfilterbase_Callback(hObject, eventdata, handles)
% hObject    handle to f_FFTfilterbase (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep,'filter',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROIN = evalin('base', 'ALLEEG_ERO');
[ALLEEG_EROOUT,EEG_EROOUT] = f_FFTfilterbase(ALLEEG_EROIN,EEG_EROIN);
assignin('base', 'ALLEEG_ERO',ALLEEG_EROOUT);
assignin('base', 'EEG_ERO',EEG_EROOUT);



% --------------------------------------------------------------------
function f_WaveletBandfilter_Callback(hObject, eventdata, handles)
% hObject    handle to f_WaveletBandfilter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep,'filter function',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROIN = evalin('base', 'ALLEEG_ERO');
[ALLEEG_EROOUT,EEG_EROOUT] = f_WaveletBandfilter(ALLEEG_EROIN, EEG_EROIN);%% filter the data
assignin('base', 'ALLEEG_ERO',ALLEEG_EROOUT);
assignin('base', 'EEG_ERO',EEG_EROOUT);


% --------------------------------------------------------------------
function Untitled_3_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_select_dataset_Callback(hObject, eventdata, handles)
% hObject    handle to f_select_dataset (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROIN = evalin('base', 'ALLEEG_ERO');
[ALLEEG_EROOUT,EEG_EROOUT] = f_select_dataset(ALLEEG_EROIN, EEG_EROIN);%% filter the data
assignin('base', 'ALLEEG_ERO',ALLEEG_EROOUT);
assignin('base', 'EEG_ERO',EEG_EROOUT);

% --------------------------------------------------------------------
function Untitled_4_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function f_pcaRotated_Callback(hObject, eventdata, handles)
% hObject    handle to f_pcaRotated (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep,'pca',filesep));
addpath(genpath(Currentpath));
EEG_EROINPUT = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');
[ALLEEG_ERO,EEG_ERO] = f_pcaRotated(ALLEEG_EROINPUT,EEG_EROINPUT);
assignin('base', 'ALLEEG_ERO',ALLEEG_ERO);
assignin('base', 'EEG_ERO',EEG_ERO);


% --------------------------------------------------------------------
function f_selectComponents_Callback(hObject, eventdata, handles)
% hObject    handle to f_selectComponents (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep,'pca',filesep));
addpath(genpath(Currentpath));
EEG_EROINPUT = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');
[ALLEEG_ERO,EEG_ERO] = f_selectComponents(ALLEEG_EROINPUT,EEG_EROINPUT);
assignin('base', 'ALLEEG_ERO',ALLEEG_ERO);
assignin('base', 'EEG_ERO',EEG_ERO);

% --------------------------------------------------------------------
function f_projectioncomponents_Callback(hObject, eventdata, handles)
% hObject    handle to f_projectioncomponents (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');
[ALLEEG_ERO,EEG_ERO] = f_projectioncomponents(ALLEEG_EROINPUT,EEG_EROIN);
assignin('base', 'ALLEEG_ERO',ALLEEG_ERO);
assignin('base', 'EEG_ERO',EEG_ERO);


% --------------------------------------------------------------------
function Untitled_5_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_mcwt_nocode_Callback(hObject, eventdata, handles)
% hObject    handle to f_mcwt_nocode (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function f_mcwt_Callback(hObject, eventdata, handles)
% hObject    handle to f_mcwt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep,'Morlet CWT',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');
[ALLEEG_ERO,EEG_ERO] = f_mcwt(ALLEEG_EROINPUT,EEG_EROIN);
assignin('base', 'ALLEEG_ERO',ALLEEG_ERO);
assignin('base', 'EEG_ERO',EEG_ERO);

% --------------------------------------------------------------------
function f_plot_tfr_Callback(hObject, eventdata, handles)
% hObject    handle to f_plot_tfr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep,'Morlet CWT',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');
[ALLEEG_EROOUT,EEG_EROOUT] = f_plot_tfr(ALLEEG_EROINPUT,EEG_EROIN);
assignin('base', 'ALLEEG_ERO',ALLEEG_EROOUT);
assignin('base', 'EEG_ERO',EEG_EROOUT);

% --------------------------------------------------------------------
function Untitled_6_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_withinsubject_rmANOVA_Callback(hObject, eventdata, handles)
% hObject    handle to f_withinsubject_rmANOVA (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep,'statistical analysis',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
f_withinsubject_rmANOVA(EEG_EROIN);


% --------------------------------------------------------------------
function Untitled_7_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_between_subject_two_factor_rmanova_Callback(hObject, eventdata, handles)
% hObject    handle to f_between_subject_two_factor_rmanova (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep,'statistical analysis',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
f_between_subject_two_factor_rmanova(EEG_EROIN);


% --------------------------------------------------------------------
function f_between_subject_three_factor_anovan_Callback(hObject, eventdata, handles)
% hObject    handle to f_between_subject_three_factor_anovan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep,'statistical analysis',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
f_between_subject_three_factor_anovan(EEG_EROIN);


% --------------------------------------------------------------------
function Untitled_8_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_plot_tfr_canny_Callback(hObject, eventdata, handles)
% hObject    handle to f_plot_tfr_canny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep,'Morlet CWT',filesep,'canny detector',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
EEG_EROOUT = f_plot_tfr_canny(EEG_EROIN);
assignin('base', 'EEG_ERO',EEG_EROOUT);



% --------------------------------------------------------------------
function f_edgedetection_canny_Callback(hObject, eventdata, handles)
% hObject    handle to f_edgedetection_canny (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));

f_edgedetection_canny();


% --------------------------------------------------------------------
function Untitled_9_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_output_excel_spss_Callback(hObject, eventdata, handles)
% hObject    handle to f_output_excel_spss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));
Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
f_output_excel_spss(EEG_EROIN);


% --------------------------------------------------------------------
function Untitled_10_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function f_ctda_plot_Callback(hObject, eventdata, handles)
% hObject    handle to f_ctda_plot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
p1 = mfilename('fullpath');
i= findstr(p1,filesep);
p1=p1(1:i(end));

Currentpath = char(strcat(p1,'functions',filesep));
addpath(genpath(Currentpath));
EEG_EROIN = evalin('base', 'EEG_ERO');
ALLEEG_EROINPUT = evalin('base', 'ALLEEG_ERO');
[ALLEEG_ERO,EEG_ERO] = f_ctda_plot(ALLEEG_EROINPUT,EEG_EROIN);
assignin('base', 'ALLEEG_ERO',ALLEEG_ERO);
assignin('base', 'EEG_ERO',EEG_ERO);


% --------------------------------------------------------------------
function Untitled_11_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
