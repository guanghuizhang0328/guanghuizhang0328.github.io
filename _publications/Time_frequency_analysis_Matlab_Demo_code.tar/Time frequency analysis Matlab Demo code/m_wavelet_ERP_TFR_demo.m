clear all
close all
clc
%%
tic

load GA_P3_erp_ar_diff_waves_lpfilt;


data_intest = squeeze(ERP.bindata(13,:,3));%%data of interest

fs = ERP.srate;%%sampling rate
Fc = 1;%%center frequency
fb=1;%%frequency band
fl = 1;%%低频截止频率
fh = 20;%%高频截止频率
FreNum = 50;%%频率点数
fIndex = logspace(log10(fl),log10(fh),FreNum);%%频率索引
wname =  ['cmor',num2str(fb),'-',num2str(Fc)];%%小波名称:cmor
scale = fs*Fc./fIndex;%%小波变换的尺度设置
tIndex = ERP.times;


COEFS = abs(cwt(data_intest,scale,wname));
Baseline = [-200 0];

%%去基线
baselinePstart = ceil((Baseline(1)-tIndex(1))/(1000/fs))+1;
baselinePend = ceil((Baseline(2)-tIndex(1))/(1000/fs));
COEFS= COEFS-repmat(mean(COEFS(:,baselinePstart:baselinePend),2),1,size(COEFS,2));

%%plot time frequency representation
FontSize = 12;
figure('color','w','NumberTitle', 'on');
set(gca,'fontsize',FontSize,'FontWeight','normal');
set(gcf,'outerposition',get(0,'screensize'));
pcolor(tIndex,fIndex,squeeze(COEFS(:,:)));
shading('interp');
hold on;
set(gca,'yscale','log');%y轴刻度方式
set(gca,'ytick',[ 1 3 5 10 20]);%显示刻度值
xlim([min(tIndex) max(tIndex)]);%轴范围
ylim([fl fh]);
%     caxis([1 20]);%颜色轴取值
title('P3','FontWeight','normal','Color','k','fontsize',FontSize);
colorbar;

xlabel('Time/ms','FontWeight','normal','Color','k','fontsize',FontSize);
ylabel('Frequency/Hz','FontWeight','normal','Color','k','fontsize',FontSize);
hold on;
colormap('jet');




%%
toc