clear
clc
close all 
%%
tic
%% winthin-subject analysis: A*B*C: 2*2*3

 X = xlsread('withinsubjects_threefactors.xls');
 factorNames = {'A','B','C'};
 
 
Y = reshape(X,[],1);

subNum = size(X,1);
stiOne = 2;
stiTwo = 2;
stiThree = 3;
stiNum = stiOne*stiTwo*stiThree;
BTFacs =[];
WInFacs = [];
count = 0;
for is = 1:stiOne
    IdexStart = subNum*(is-1)*stiTwo*stiThree+1;
    IdexEnd =  is*subNum*stiTwo*stiThree;
    WInFacs(IdexStart:IdexEnd,1) = is;
    for iss  = 1:stiTwo
        for isss  =1:stiThree
            count  = count +1;
            IdexStart = subNum*(count-1)+1;
            IdexEnd =  subNum*count;
            WInFacs(IdexStart:IdexEnd,2) = iss;
            WInFacs(IdexStart:IdexEnd,3) = isss;
        end
    end
end

S = [];
for iss = 1:stiNum
    IdexStart = subNum*(iss-1)+1;
    IdexEnd =  iss*subNum;
    S(IdexStart:IdexEnd,1) =1:subNum ;
end

X = [Y,WInFacs,S];
sta = f_withinanova_rm3(X,0.05,factorNames);



%%
toc