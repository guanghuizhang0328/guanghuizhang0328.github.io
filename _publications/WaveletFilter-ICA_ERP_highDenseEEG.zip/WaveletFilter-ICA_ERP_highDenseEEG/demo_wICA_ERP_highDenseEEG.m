%%% This code was written by Dr. Fengyu Cong in June 2013
%%% Department of Mathematical Information Technology, University of Jyv�skyl�, Finland
%%% Address: PL35(Agora), 40014, Jyv�skyl�, Finland
%%% Tel.: +358-40-8053255 (Mobile)
%%% E-mails: Fengyu.Cong@jyu.fi, FengyuCong@gmail.com
%%% Homepage: http://users.jyu.fi/~fecong

%%% Using this code please cite the following articles

%%% Fengyu Cong, Igor Kalyakin, Hong Li, Tiina Huttunen-Scott, Yixiang Huang, Heikki Lyytinen, Tapani Ristaniemi,
%%% Answering Six Questions in Extracting Children's Mismatch Negativity through Combining Wavelet Decomposition and Independent Component Analysis,
%%% Cognitive Neurodynamics, 2011, 5(4): 343-359.

%%% Fengyu Cong, Paavo H.T. Lepp�nen, Piia Astikainen, Jarmo H�m�l�inen, Jari K. Hietanen, Tapani Ristaniemi,
%%% Dimension Reduction: Additional Benefit of an Optimal Filter for Independent Component Analysis to Extract Event-related Potentials,
%%% Journal of Neuroscience Methods, 2011, 201(1): 269-280.

%%% Fengyu Cong, Igor Kalyakin, Tapani Ristaniemi,
%%% Can Back-Projection Fully Resolve Polarity Indeterminacy of ICA in Study of ERP?
%%% Biomedical Signal Processing and Control, 2011, 6(4): 422-426.

%%% Fengyu Cong, Zhaoshui He, Jarmo H�m�l�inen, Andrzej Cichocki and Tapani Ristaniemi,
%%% Determining the Number of Sources in High-density EEG Recordings of Event-related Potentials by Model Order Selection,
%%% Proc. IEEE Workshop on Machine Learning for Signal Processing (MLSP) 2011, Beijing, China, September 18-21, 2011.

%%% More details are listed in the homepage 'wICA' : http://users.jyu.fi/~fecong/wICA.html

%%% please run EEGLAB first. Otherwise, the topography of ERP can not be plotted

clear
clc
close all

tic
%% information of conventionally preprocessed ERP data
dP = [pwd,'\data\'];
sn = ['demo'];
NumChannels = 128;
typicalElectrodeNum = 6; %%% FCz
fs = 500; %% Hz
timeStart = -100;
timeEnd = 600;
%%
fn = [dP,sn,'.dat'];
fid = fopen(fn,'r');
d = fread(fid,[NumChannels,inf],'float32');
NumSamples = length(d);
%%%%% d is with dimensions of number of channels by number of samples

timeIndex=linspace(timeStart,timeEnd,NumSamples);
xMin=min(timeIndex);
xMax=max(timeIndex);
yMin=1.1*min(d(:));
yMax=1.1*max(d(:));
%%
fs0 = 1000;
if fs < fs0
    ratio0 = ceil(fs0/fs);
    x = resample(d',ratio0,1);
    x = x';
else
    ratio0 = 1;
    x = d;
end
%% locations of electrodes
LOC=readlocs('128.elp');
clc
%% wavelet filter
wname='rbio6.8'; %%% name of the wavelet
lv=10; %% number of levels for the decomposition
kp=[3 4 5 6]; %% the coefficients at the levels 8, 7, 6 and 5 are chosen for the reconstruction
for is = 1:NumChannels
    X(is,:) = f_filterWavelet(x(is,:),lv,wname,kp); %%% For more details, please read Cong et al. (Journal of Medical and Biological Engineering, DOI: 10.5405/jmbe.908,2012,in press)
end
%% Determining the number of sources
covX = cov(X');
[Vx,Dx] = eig(covX);
lambda = diag(Dx);
%% estimate the number of sources in the noisy mixtures through model order selection-GAP
delta = 0.000000000001; %% eps for GAP
K = f_Gap(lambda,delta);
%% dimension reduction, i.e., converting overdetermined model to determined model
V = Vx(:,(NumChannels-K+1):NumChannels);
Z = V'*X;
SelectedPCAcomponents = Z;
SelectedPCAcomponents = flipud(SelectedPCAcomponents);
ratio = 4;
Z = resample(Z',ratio,1); %%% upsampling the data to have more samples for avoiding overfitting in ICA decomposition
Z = Z';
%%
if fs<fs0
    X = resample(X',1,ratio0);
    X = X';
    SelectedPCAcomponents = resample(SelectedPCAcomponents',1,ratio0);
    SelectedPCAcomponents = SelectedPCAcomponents';
end
%% ICASSO
NumSources = K;
NumRuns = 100;
sR_FastICA=icassoEst('both', Z , NumRuns, 'lastEig', NumSources, 'g', 'tanh', ...
    'approach', 'symm');
sRExp=icassoExp(sR_FastICA);
[iq,A,W,S]=icassoShow(sRExp,'L',NumSources,'colorlimit',[.8 .9]);
B=inv(W);
Y = resample(S',1,ratio*ratio0); %%% downsampling to the original sampling frequency when the data was imported
Y = Y';
compMin = 1.1*min(Y);
compMax = 1.1*max(Y);
%% plotting the data filtered and decomposed
count = 0;
figure
set(gcf,'outerposition',get(0,'screensize'))
for is = 6:10:NumChannels
    count = count + 1;
    subplot(3,5,count)
    plot(timeIndex,d(is,:),'-.','linewidth',2)
    grid on
    hold on
    plot(timeIndex,X(is,:),'r-','linewidth',2)
    xlim([xMin xMax])
    ylim([yMin yMax])
    if count == 1
        xlabel('Time/ms')
        ylabel(['Amplitude/','\mu','V'])
        tN=['ERP data at channel #',int2str(is)];
    else
        tN=['#',int2str(is)];
    end
    title(tN)
end
legend('Raw data','Filtered data')
%% plotting the selected PCA component according to its contribution to the decomposed data
figure
set(gcf,'outerposition',get(0,'screensize'))
for is = 1:NumSources
    subplot(3,ceil(NumSources/3),is)
    plot(timeIndex,SelectedPCAcomponents(is,:),'m','linewidth',2)
    grid on
    xlim([xMin xMax])
    if is == 1
        xlabel('Time/ms')
        ylabel(['Amplitude/','\mu','V'])
        tN=['PCA-comp. #',int2str(is)];
    else
        tN=['#',int2str(is)];
    end
    title(tN,'fontsize',14)
end
legend('Variance is according to contributions to the decomposed data')
clc
%% plotting the component according to the order of its peak latency
[a,b] = max(abs(Y),[],2);
[b,idx] = sort(b);
iq = iq(idx);
Y = Y(idx,:);
minV = 1.1*min(Y(:));
maxV = 1.1*max(Y(:));

figure
set(gcf,'outerposition',get(0,'screensize'))
for is = 1:K;
    subplot(4,6,is)
    set(gca,'fontsize',12)
    plot(timeIndex,Y(is,:),'k-','linewidth',2)
    hold on
    plot(timeIndex,X(typicalElectrodeNum,:),'r-.','linewidth',2)
    hold off
    if is == 1
        set(gca,'fontsize',14)
        tN=['Comp # ',int2str(is)];
        title(tN)
        xlabel('Time/ms')
    else
        tN=['# ',int2str(is)];
        title(tN)
    end
    xlim([xMin xMax])
    ylim([minV maxV])
end
legend('ICA component','Wavelet-filtered data at typical electrode')

%% plot topo of each component
B = inv(W);
TOPO = V*B;
TOPO = TOPO(:,idx);

figure
set(gcf,'outerposition',get(0,'screensize'))
for is = 1:size(TOPO,2);
    
    TOPO(:,is) = TOPO(:,is)-mean(TOPO(:,is));
    TOPO(:,is) = TOPO(:,is)/std(TOPO(:,is));
    
    subplot(4,6,is)
    set(gca,'fontsize',12)
    topoplot(TOPO(:,is),LOC);
    
    if is == 1
        set(gca,'fontsize',14)
        tN=['Comp # ',int2str(is)];
    else
        tN=['# ',int2str(is)];
    end
    title(tN)
end

Hd = colorbar('peer',gca);
set(get(Hd,'ylabel'),'String', 'Amplitude','fontsize',14);

%% selecting the component to be projected
fprintf('\n')
seNum = input('Please input the number of the selected component shown in the figure presenting ICA-comp.: seNum = ');
fprintf('\n')
compStart = input('For topography of the selected component, please input the timing (ms) that the peak starts: compStart = '); %% ms
fprintf('\n')
compEnd = input('For topography of the selected component, please input the timing (ms) that the peak ends: compEnd = '); %% ms
fprintf('\n')
%%% projecting the selected component back to the electrode field to correct the variance indeterminacy of ICA component
TOPO = V*B;
TOPO = TOPO(:,idx);
E = TOPO(:,seNum)*Y(seNum,:);
% %%%%%%%%%% For detailes about the projection and the correction, Please read the following articles:
% %%%%%%%%%% Cong et al. (Biomedical Signal Processing and Control, 2011, 6(4): 422-426.)
% %%%%%%%%%% Cong et al. (Biomedizinische Technik / Biomedical Engineering, 2011, 56(4): 223�234.)

count = 0;
figure
set(gcf,'outerposition',get(0,'screensize'))
for is = 6:10:NumChannels
    count = count + 1;
    subplot(3,5,count)
    plot(timeIndex,E(is,:),'k--','linewidth',3)
    grid on
    hold on
    plot(timeIndex,X(is,:),'r-','linewidth',2)
    xlim([xMin xMax])
    ylim([yMin yMax])
    if count == 1
        xlabel('Time/ms')
        ylabel(['Amplitude/','\mu','V'])
        tN=['ERP data at channel #',int2str(is)];
    else
        tN=['#',int2str(is)];
    end
    title(tN)
end
legend('ICA-projection','Filtered data')

%%
methodStr = {'Conventional','Wavelet filter','ICA'};

figure
set(gca,'fontsize',14)
plot(timeIndex,d(typicalElectrodeNum,:),'k','linewidth',2)
hold on
plot(timeIndex,X(typicalElectrodeNum,:),'k:','linewidth',2)
plot(timeIndex,E(typicalElectrodeNum,:),'k--','linewidth',4)
xlabel('Time/ms')
ylabel(['Amplitude/','\mu','V'])
xlim([xMin xMax])
legend(methodStr,'location','southwest')
title('ERP data at typical electrode')
%%

%%% plotting topography of one component
timeReso = 1000/fs;
sampStart = (abs(timeStart)+compStart)/timeReso;
sampEnd = (abs(timeStart)+compEnd)/timeReso;
topoRaw = mean(d(:,sampStart:sampEnd),2);
topoFiltered = mean(X(:,sampStart:sampEnd),2);
topoICA = mean(E(:,sampStart:sampEnd),2);
dataStr = ['mean from ',int2str(compStart),'ms to ',int2str(compEnd),'ms'];

figure
set(gcf,'outerposition',get(0,'screensize'))

subplot(1,3,1)
set(gca,'fontsize',14)
topoplot(topoRaw,LOC,'electrodes','off');
tN=['Topo of conventional ERP data: ',dataStr];
title(tN)
colorbar

subplot(1,3,2)
set(gca,'fontsize',14)
topoplot(topoFiltered,LOC,'electrodes','off');
tN=['Filtered ERP data'];
title(tN)
colorbar

subplot(1,3,3)
set(gca,'fontsize',14)
topoplot(topoICA,LOC,'electrodes','off');
tN=['ICA ERP data: Comp #',int2str(seNum)];
title(tN)
colorbar

%%
fprintf('\n')
verbose = input('please input 1 for saving new data or 0 for not saving new data : verbose = '); %% ms
fprintf('\n')
if verbose == 1
    fn = [dP,'\ICA\',sn,'.dat'];
    fid = fopen(fn,'w');
    fwrite(fid,E,'float32');
    
    fN = [dP,'\waveletFilter\',sn,'.dat'];
    fid = fopen(fN,'w');
    fwrite(fid,X,'float32');
    
end
%% program ends
toc