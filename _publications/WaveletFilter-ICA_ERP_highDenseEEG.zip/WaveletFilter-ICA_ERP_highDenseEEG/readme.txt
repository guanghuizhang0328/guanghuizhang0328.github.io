Please run EEGLAB before using the demo. It does not matter whether the codes for EEGLAB and the codes of the demo for ICA are in the same folder or not.


Please run 'demo_wICA_ERP_highDenseEEG.m' to see the results when the systematic ICA approach is performed on the ERP data.


The toolboxes of FastICA and ICASSO are used in the demo. They were downloaded from the following links 

http://research.ics.tkk.fi/ica/icasso/  and  http://research.ics.tkk.fi/ica/fastica/

EEGLAB can be downloaded via http://sccn.ucsd.edu/eeglab/

Note: Wavelet toolbox of MATLAB is specially required to run the demo since the wavelet filter is used.

