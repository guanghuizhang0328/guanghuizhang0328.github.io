function K=f_Gap(lambda, Mydelta)

%%% MATLAB codes for GAP were written by Professor Zhaoshui He
%%%%%%%%%%%%%%%%%%%%%%%%%  in Faculty of Automation, Guangdong University of Technology, Guang Zhou, China
%%%%%%%%%%%%%%%%%%%%%%%%%  in 2011
%%%%%%%%%%%%%%%%%%%%%%%%%  Email: he_shui@tom.com  
%%% Referece: 
%%%  Z. He, A. Cichocki, S. Xie and K. Choi, 
%%% "Detecting the number of clusters in n-way probabilistic clustering," 
%%% IEEE Trans. Pattern Anal. Mach. Intell., vol. 32, pp. 2006-2021, Nov, 2010. 
%% 
len=length(lambda);
nklambda=sort(lambda,1,'descend');
if isempty(Mydelta)
    Mydelta=eps;
end

for k=0:len-1
    if (k<len-2)
        temp=mean(nklambda(k+2:len));
        
        if (nklambda(k+1)-temp<Mydelta)
            GAP(k+1)=1;
        else
            GAP(k+1)=(nklambda(k+2)-temp)/(nklambda(k+1)-temp);
        end              
    end
end

[kkvalue,K]=min(GAP);  