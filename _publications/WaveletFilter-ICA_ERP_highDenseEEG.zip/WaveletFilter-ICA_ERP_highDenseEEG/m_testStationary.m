clear
clc
close all


tic

NumChannels = 128;
dP = [pwd,'\data\'];
sn = ['demo'];
fn = [dP,sn,'.dat'];
fid = fopen(fn,'r');
d = fread(fid,[NumChannels,inf],'float32');

indexChannel = randperm(NumChannels);
x = d(indexChannel(1:10),:);



toc