clear
clc
close all
%%
tic

X = xlsread('betweenSubjects_twoFactors.xls');
X = X(:,2:end);
% Y = reshape(X,[],1);
subNum = size(X,1);
stiNum = size(X,2);
GroupNum = 2;
GroupOne = 20;
GroupTwo = 20;
Group_Idx = [ones(GroupOne,1);ones(GroupTwo,1)*2];

BTFacs =[];
WInFacs = [];
S = [];
count = 0;
Y = [];
for is = 1:GroupNum
    idx1 = find(Group_Idx == is);
    X1 = X(idx1,:);
    X1  = reshape(X1,[],1);
    Y = [Y;X1];

    for iss  = 1:stiNum
        
        BTFacs = [BTFacs;ones(length(idx1),1)*is];
        %%
        WInFacs = [WInFacs; ones(length(idx1),1)*iss];
        %%
        S =[S;idx1];
    end
end


D(:,1)= Y;
D(:,2)= BTFacs;
D(:,3)= WInFacs;
D(:,4)= S;
factorNames={'G','S'};
 [SSQs, DFs, MSQs, Fs, Ps] = f_mixed_between_within_anova1(D,factorNames);


[EpsHF EpsGG] = GenCalcHFEps(Y,BTFacs,WInFacs,S)
%%
toc