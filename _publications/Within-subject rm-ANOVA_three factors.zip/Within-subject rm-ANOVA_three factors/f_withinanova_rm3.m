function table = f_withinanova_rm3(X,alpha,factorNames)
% RMAOV33 Three-way Analysis of Variance With Repeated Measures on Three Factors Test.
%   This is a three-factor analysis of variance design in which all factors are within-
%   subjects variables. In repeated measures designs, the same participants are used
%   in all conditions. This is like an extreme matching. This allows for reduction of 
%   error variance due to subject factors. Fewer participants can be used in an repeated
%   measures design. Repeated measures designs make it easier to see an effect of the
%   independent variable on the dependent variable (if there is such an effect).
%   Due that there is no way to obtain an independent estimate of error component, for
%   we have only one score per cell, and therefore no within-cell variance. However,
%   each of the interactions with subjects can be shown to serve as a denominator for 
%   an F ratio. So, each effect to be tested has its own error term. Thus every effect
%   is tested by the interaction of that effect with the Subject effect.
%   The SS components are divided up for this design in a way that is best illustrated
%   in a SS tree, as shown:
%                                         
%                                 /    
%                                | SSS  
%                                |           /        / 
%                                |          |        | SSA 
%                                |          |   A   < 
%                                |          |        | [SSEA]
%                                |          |         \         
%                                |          |    
%                                |          |         / 
%                                |          |        | SSB 
%                                |          |   B   < 
%                                |          |        | [SSEB]
%                                |          |         \         
%                                |          |    
%                                |          |         / 
%                                |          |        | SSC 
%                                |          |   C   < 
%                                |          |        | [SSEC]
%                                |          |         \         
%                                |          |    
%                        SSTO   <           |         /
%                                |          |        | SSAxB
%                                | SSW-S   <   AB   <  
%                                |          |        | [SSEAB]
%                                |          |         \
%                                |          | 
%                                |          |         / 
%                                |          |        | SSAxC
%                                |          |  AC   < 
%                                |          |        | [SSEAC]
%                                |          |         \
%                                |          |
%                                |          |         / 
%                                |          |        | SSBxC 
%                                |          |  BC   <
%                                |          |        | [SSEBC]
%                                |          |
%                                |          |         / 
%                                |          |        | SSAxBxC 
%                                |          | ABC   <
%                                |          |        | [SSEABC]
%                                 \          \        \         
%                    
%   Syntax: function [RMAOV33] = RMAOV33(X,alpha) 
%      
%     Inputs:
%          X - data matrix (Size of matrix must be n-by-5;dependent variable=column 1;
%              independent variable 1 (within subjects)=column 2;independent variable 2
%              (within subjects)=column 3; independent variable 3 (within subjects)
%              =column 4; subject=column 5). 
%      alpha - significance level (default = 0.05).
%    Outputs:
%            - Complete Analysis of Variance Table.
%
%    Example: From the example of Howell (2002, p. 510-512). There he examine driver behavior as a 
%             function of two times of day, three types of course, and three models of cars. There
%             were three drivers, each of whom drove each model on each course at each time of day.
%             The dependent variable is the number of steering errors as shown on the below table.
%             Use a significance level = 0.05.

%    Created by A. Trujillo-Ortiz, R. Hernandez-Walls and F.A. Trujillo-Perez
%               Facultad de Ciencias Marinas
%               Universidad Autonoma de Baja California
%               Apdo. Postal 453
%               Ensenada, Baja California
%               Mexico.
%               atrujo@uabc.mx
%
%    Copyright.January 10, 2006.
%
%    ---Special thanks are given to Georgina M. Blanc from the Vision Center Laboratory of the 
%       Salk Institute for Biological Studies, La Jolla, CA, for encouraging us to create
%       this m-file-- 
%
%    To cite this file, this would be an appropriate format:
%    Trujillo-Ortiz, A., R. Hernandez-Walls and F.A. Trujillo-Perez. (2006). RMAOV33: Three-way 
%      Analysis of Variance With Repeated Measures on Three Factors Test. A MATLAB file. [WWW document].
%      URL http://www.mathworks.com/matlabcentral/fileexchange/loadFile.do?objectId=9638
%
%    References:
%    Howell, D. C. (2002), Statistical Methods for Psychology. 5th ed. 
%             Pacific Grove, CA:Duxbury Wadsworth Group.
%

% if nargin < 2
%    alpha = 0.05; %(default)
% end; 

if (alpha <= 0 | alpha >= 1)
   fprintf('Warning: significance level must be between 0 and 1\n');
   return;
end;

if nargin < 1, 
   error('Requires at least one input argument.');
   return;
end;

a = max(X(:,2));
b = max(X(:,3));
c = max(X(:,4));
s = max(X(:,5));
[EpsHF  EpsGG]= GenCalcHFEps(X(:,1),[],X(:,2:4),X(:,end));
%%

CT = (sum(X(:,1)))^2/length(X(:,1));  %correction term
SSTO = sum(X(:,1).^2)-CT;  %total sum of squares
v16 = length(X(:,1))-1;  %total degrees of freedom
   
%procedure related to the subjects.
S = [];
indice = X(:,5);
for l = 1:s
    Xe = find(indice==l);
    eval(['S' num2str(l) '=X(Xe,1);']);
    eval(['x =((sum(S' num2str(l) ').^2)/length(S' num2str(l) '));']);
    S = [S,x];
end;

SSS = sum(S)-CT;
v15 = s-1;

%--Procedure Related to the Within-Subjects--
%procedure related to the IV1 (independent variable 1 [within-subjects]).
A = [];
indice = X(:,2);
for i = 1:a
    Xe = find(indice==i);
    eval(['A' num2str(i) '=X(Xe,1);']);
    eval(['x =((sum(A' num2str(i) ').^2)/length(A' num2str(i) '));']);
    A = [A,x];
end;
SSA = sum(A)-CT;  %sum of squares for the IV1
v1 = a-1;  %degrees of freedom for the IV1
MSA = SSA/v1;  %mean square for the IV1

%% Greenhouse-Geisser
V1_G = v1*EpsGG(1);
MSA_G = SSA/V1_G;
%% Huynh-Feldt
V1_H = v1*EpsHF(1);
MSA_H = SSA/V1_H; 

%procedure related to the IV1-error.
EIV1 = [];
for i = 1:a
    for l = 1:s
        Xe = find((X(:,2)==i) & (X(:,5)==l));
        eval(['IV1S' num2str(i) num2str(l) '=X(Xe,1);']);
        eval(['x =((sum(IV1S' num2str(i) num2str(l) ').^2)/length(IV1S' num2str(i) num2str(l) '));']);
        EIV1 = [EIV1,x];
    end;
end;
SSEA = sum(EIV1)-sum(A)-sum(S)+CT;  %sum of squares of the IV1-error
v2 = v1*v15;  %degrees of freedom of the IV1-error
MSEA = SSEA/v2;  %mean square for the IV1-error
%% Greenhouse-Geisser
V2_G = V1_G*v15;  %degrees of freedom of the IV1-error
MSEA_G = SSEA/V2_G;  %mean square for the IV1-error

V2_H = V1_H*v15;  %degrees of freedom of the IV1-error
MSEA_H = SSEA/V2_H;  %mean square for the IV1-error

%F-statistics calculation.
F1 = MSA/MSEA;

%Probability associated to the F-statistics.
P1 = 1 - fcdf(F1,v1,v2);  

P1_G = 1 - fcdf(F1,V1_G,V2_G); 
P1_H = 1 - fcdf(F1,V1_H,V2_H); 
%procedure related to the IV2 (independent variable 2 [within-subjects]).
B = [];
indice = X(:,3);
for j = 1:b
    Xe = find(indice==j);
    eval(['B' num2str(j) '=X(Xe,1);']);
    eval(['x =((sum(B' num2str(j) ').^2)/length(B' num2str(j) '));']);
    B =[B,x];
end;
SSB = sum(B)-CT;  %sum of squares for the IV2
v3 = b-1;  %degrees of freedom for the IV2
MSB = SSB/v3;  %mean square for the IV2
%% Greenhouse-Geisser
V3_G = v3*EpsGG(2);
MSB_G = SSB/V3_G;
%% Huynh-Feldt
V3_H = v3*EpsHF(2);
MSB_H = SSB/V3_H; 

%procedure related to the IV2-error.
EIV2 = [];
for j = 1:b
    for l = 1:s
        Xe = find((X(:,3)==j) & (X(:,5)==l));
        eval(['IV2S' num2str(j) num2str(l) '=X(Xe,1);']);
        eval(['x =((sum(IV2S' num2str(j) num2str(l) ').^2)/length(IV2S' num2str(j) num2str(l) '));']);
        EIV2 = [EIV2,x];
    end;
end;
SSEB = sum(EIV2)-sum(B)-sum(S)+CT;  %sum of squares of the IV2-error
v4 = v3*v15;  %degrees of freedom of the IV2-error
MSEB = SSEB/v4;  %mean square for the IV2-error

%% Greenhouse-Geisser
V4_G = V3_G*v15;  %degrees of freedom of the IV1-error
MSEB_G = SSEB/V4_G;  %mean square for the IV1-error

V4_H = V3_H*v15;  %degrees of freedom of the IV1-error
MSEB_H = SSEB/V4_H;  %mean square for the IV1-error


%F-statistics calculation.
F2 = MSB/MSEB;

%Probability associated to the F-statistics.
P2 = 1 - fcdf(F2,v3,v4);    
P2_G = 1 - fcdf(F2,V3_G,V4_G); 
P2_H = 1 - fcdf(F2,V3_H,V4_H); 

%procedure related to the IV3 (independent variable 3 [within-subject]).
C = [];
indice = X(:,4);
for k = 1:c
    Xe = find(indice==k);
    eval(['C' num2str(k) '=X(Xe,1);']);
    eval(['x =((sum(C' num2str(k) ').^2)/length(C' num2str(k) '));']);
    C =[C,x];
end;
SSC = sum(C)-CT;  %sum of squares for the IV3
v5 = c-1;  %degrees of freedom for the IV3
MSC = SSC/v5;  %mean square for the IV3

%% Greenhouse-Geisser
V5_G = v5*EpsGG(3);
MSC_G = SSC/V5_G;
%% Huynh-Feldt
V5_H = v5*EpsHF(3);
MSC_H = SSC/V5_H; 

%procedure related to the IV3-error.
EIV3 = [];
for k = 1:c
    for l = 1:s
        Xe = find((X(:,4)==k) & (X(:,5)==l));
        eval(['IV3S' num2str(k) num2str(l) '=X(Xe,1);']);
        eval(['x =((sum(IV3S' num2str(k) num2str(l) ').^2)/length(IV3S' num2str(k) num2str(l) '));']);
        EIV3 = [EIV3,x];
    end;
end;
SSEC = sum(EIV3)-sum(C)-sum(S)+CT;  %sum of squares of the IV3-error
v6 = v5*v15;  %degrees of freedom of the IV3-error
MSEC = SSEC/v6;  %mean square for the IV3-error

%% Greenhouse-Geisser
V6_G = V5_G*v15;  %degrees of freedom of the IV1-error
MSEC_G = SSEC/V6_G;  %mean square for the IV1-error

V6_H = V5_H*v15;  %degrees of freedom of the IV1-error
MSEC_H = SSEC/V6_H;  %mean square for the IV1-error


%F-statistics calculation.
F3 = MSC/MSEC;

%Probability associated to the F-statistics.
P3 = 1 - fcdf(F3,v5,v6);    
P3_G = 1 - fcdf(F3,V5_G,V6_G); 
P3_H = 1 - fcdf(F3,V5_H,V6_H); 
%procedure related to the IV1 and IV2 (within- and within- subject).
AB = [];
for i = 1:a
    for j = 1:b
        Xe = find((X(:,2)==i) & (X(:,3)==j));
        eval(['AB' num2str(i) num2str(j) '=X(Xe,1);']);
        eval(['x =((sum(AB' num2str(i) num2str(j) ').^2)/length(AB' num2str(i) num2str(j) '));']);
        AB = [AB,x];
    end;
end;
SSAB = sum(AB)-sum(A)-sum(B)+CT;  %sum of squares of the IV1xIV2
v7 = v1*v3;  %degrees of freedom of the IV1xIV2
MSAB = SSAB/v7;  %mean square for the IV1xIV2
%% Greenhouse-Geisser
V7_G = v7*EpsGG(4);
MSAB_G = SSAB/V7_G;
%% Huynh-Feldt
V7_H = v7*EpsHF(4);
MSAB_H = SSAB/V7_H; 


%procedure related to the IV1-IV2-error.
EIV12 = [];
for i = 1:a
    for j = 1:b
        for l = 1:s
            Xe = find((X(:,2)==i) & (X(:,3)==j) & (X(:,5)==l));
            eval(['IV12S' num2str(i) num2str(j) num2str(l) '=X(Xe,1);']);
            eval(['x =((sum(IV12S' num2str(i) num2str(j) num2str(l) ').^2)/length(IV12S' num2str(i) num2str(j) num2str(l) '));']);
            EIV12 = [EIV12,x];
        end;
    end;
end;
SSEAB = sum(EIV12)-sum(AB)-sum(EIV2)+sum(B)-sum(EIV1)+sum(A)+sum(S)-CT;
v8= v2*v3;  %degrees of freedom of the IV1-IV2-error
MSEAB = SSEAB/v8;  %mean square for the IV1-IV2-error
%% Greenhouse-Geisser
V8_G = V7_G*v15;  %degrees of freedom of the IV1-error
MSEAB_G = SSEAB/V8_G;  %mean square for the IV1-error

V8_H = V7_H*v15;  %degrees of freedom of the IV1-error
MSEAB_H = SSEAB/V8_H;  %mean square for the IV1-error



%F-statistics calculation
F4 = MSAB/MSEAB;

%Probability associated to the F-statistics.
P4 = 1 - fcdf(F4,v7,v8);
P4_G = 1 - fcdf(F4,V7_G,V8_G); 
P4_H = 1 - fcdf(F4,V7_H,V8_H); 
%procedure related to the IV1 and IV3 (between- and within- subject).
AC = [];
for i = 1:a
    for k = 1:c
        Xe = find((X(:,2)==i) & (X(:,4)==k));
        eval(['AC' num2str(i) num2str(k) '=X(Xe,1);']);
        eval(['x =((sum(AC' num2str(i) num2str(k) ').^2)/length(AC' num2str(i) num2str(k) '));']);
        AC = [AC,x];
    end;
end;
SSAC = sum(AC)-sum(A)-sum(C)+CT;  %sum of squares of the IV1xIV3
v9 = v1*v5;  %degrees of freedom of the IV1xIV3
MSAC = SSAC/v9;  %mean square for the IV1xIV3
%% Greenhouse-Geisser
V9_G = v9*EpsGG(5);
MSAC_G = SSAC/V9_G;
%% Huynh-Feldt
V9_H = v9*EpsHF(5);
MSAC_H = SSAC/V9_H; 
%procedure related to the IV1-IV3-error.
EIV13 = [];
for i = 1:a
    for k = 1:c
        for l = 1:s
            Xe = find((X(:,2)==i) & (X(:,4)==k) & (X(:,5)==l));
            eval(['IV13S' num2str(i) num2str(k) num2str(l) '=X(Xe,1);']);
            eval(['x =((sum(IV13S' num2str(i) num2str(k) num2str(l) ').^2)/length(IV13S' num2str(i) num2str(k) num2str(l) '));']);
            EIV13 = [EIV13,x];
        end;
    end;
end;
SSEAC = sum(EIV13)-sum(AC)-sum(EIV3)+sum(C)-sum(EIV1)+sum(A)+sum(S)-CT;
v10 = v2*v5;  %degrees of freedom of the IV1-IV3-error
MSEAC = SSEAC/v10;  %mean square for the IV1-IV3-error
%% Greenhouse-Geisser
V10_G = V9_G*v15;  %degrees of freedom of the IV1-error
MSEAC_G = SSEAC/V10_G;  %mean square for the IV1-error

V10_H = V9_H*v15;  %degrees of freedom of the IV1-error
MSEAC_H = SSEAC/V10_H;  %mean square for the IV1-error

%F-statistics calculation
F5 = MSAC/MSEAC;

%Probability associated to the F-statistics.
P5 = 1 - fcdf(F5,v9,v10);
P5_G = 1 - fcdf(F5,V9_G,V10_G); 
P5_H = 1 - fcdf(F5,V9_H,V10_H); 
%procedure related to the IV2 and IV3 (within- and within- subject).
BC = [];
for j = 1:b
    for k = 1:c
        Xe = find((X(:,3)==j) & (X(:,4)==k));
        eval(['BC' num2str(j) num2str(k) '=X(Xe,1);']);
        eval(['x =((sum(BC' num2str(j) num2str(k) ').^2)/length(BC' num2str(j) num2str(k) '));']);
        BC = [BC,x];
    end;
end;
SSBC = sum(BC)-sum(B)-sum(C)+CT;  %sum of squares of the IV2xIV3
v11 = v3*v5;  %degrees of freedom of the IV2xIV3
MSBC = SSBC/v11;  %mean square for the IV2xIV3
%% Greenhouse-Geisser
V11_G = v11*EpsGG(6);
MSBC_G = SSBC/V11_G;
%% Huynh-Feldt
V11_H = v11*EpsHF(6);
MSBC_H = SSBC/V11_H; 

%procedure related to the IV2-IV3-error.
EIV23 = [];
for j = 1:b
    for k = 1:c
        for l = 1:s
            Xe = find((X(:,3)==j) & (X(:,4)==k) & (X(:,5)==l));
            eval(['IV23S' num2str(j) num2str(k) num2str(l) '=X(Xe,1);']);
            eval(['x =((sum(IV23S' num2str(j) num2str(k) num2str(l) ').^2)/length(IV23S' num2str(j) num2str(k) num2str(l) '));']);
            EIV23 = [EIV23,x];
        end;
    end;
end;
SSEBC = sum(EIV23)-sum(BC)-sum(EIV3)+sum(C)-sum(EIV2)+sum(B)+sum(S)-CT;
v12 = v4*v5;  %degrees of freedom of the IV2-IV3-error
MSEBC = SSEBC/v12;  %mean square for the IV2-IV3-error
%% Greenhouse-Geisser
V12_G = V11_G*v15;  
MSEBC_G = SSEBC/V12_G;  

V12_H = V11_H*v15;  
MSEBC_H = SSEBC/V12_H; 

%F-statistics calculation
F6 = MSBC/MSEBC;

%Probability associated to the F-statistics.
P6 = 1 - fcdf(F6,v11,v12);
P6_G = 1 - fcdf(F6,V11_G,V12_G); 
P6_H = 1 - fcdf(F6,V11_H,V12_H); 

%procedure related to the IV1, IV2 and IV3 (within, within- and within- subject).
ABC = [];
for i = 1:a
    for j = 1:b
        for k = 1:c
            Xe = find((X(:,2)==i) & (X(:,3)==j) & (X(:,4)==k));
            eval(['AB' num2str(i) num2str(j) num2str(k) '=X(Xe,1);']);
            eval(['x =((sum(AB' num2str(i) num2str(j) num2str(k) ').^2)/length(AB' num2str(i) num2str(j) num2str(k) '));']);
            ABC = [ABC,x];
        end;
    end;
end;
SSABC = sum(ABC)+sum(A)+sum(B)+sum(C)-sum(AB)-sum(AC)-sum(BC)-CT;  %sum of squares of the IV1xIV2xIV3
v13 = v1*v3*v5;  %degrees of freedom of the IV1xIV2xIV3
MSABC = SSABC/v13;  %mean square for the IV1xIV2xIV3
%% Greenhouse-Geisser
V13_G = v13*EpsGG(7);
MSABC_G = SSABC/V13_G;
%% Huynh-Feldt
V13_H = v13*EpsHF(7);
MSABC_H = SSABC/V13_H; 

%procedure related to the IV1-IV2-IV3-error.
EIV123 = [];
for i = 1:a
    for j = 1:b
        for k = 1:c
            for l = 1:s
                Xe = find((X(:,2)==i) &(X(:,3)==j) & (X(:,4)==k) & (X(:,5)==l));
                eval(['IV123S' num2str(i) num2str(j) num2str(k) num2str(l) '=X(Xe,1);']);
                eval(['x =((sum(IV123S' num2str(i) num2str(j) num2str(k) num2str(l) ').^2)/length(IV123S' num2str(i) num2str(j) num2str(k) num2str(l) '));']);
                EIV123 = [EIV123,x];
            end;
        end;
    end;
end;
SSEABC = sum(EIV123)-sum(ABC)-sum(EIV23)+sum(BC)-sum(EIV13)+sum(AC)+sum(EIV3)-sum(C)-sum(EIV12)+sum(AB)+sum(EIV2)-sum(B)+sum(EIV1)-sum(A)-sum(S)+CT;  %sum of squares of the IV1-IV2-IV3-error
v14 = v2*v3*v5;  %degrees of freedom of the IV1-IV2-IV3-error
MSEABC = SSEABC/v14;  %mean square for the IV1-IV2-IV3-error
%% Greenhouse-Geisser
V14_G = V13_G*v15;  
MSEABC_G = SSEABC/V14_G;  

V14_H = V13_H*v15;  
MSEABC_H = SSEABC/V14_H; 
%F-statistics calculation
F7 = roundn(MSABC/MSEABC,-3);

%Probability associated to the F-statistics.
P7 = roundn(1 - fcdf(F7,v13,v14),-3);
P7_G = roundn(1 - fcdf(F7,V13_G,V14_G),-3); 
P7_H = roundn(1 - fcdf(F7,V13_H,V14_H),-3); 

SSWS = SSA+SSEA+SSB+SSEB+SSC+SSEC+SSAB+SSEAB+SSAC+SSAC+SSEAC+SSBC+SSEBC+SSABC+SSEABC;
vWS = v1+v2+v3+v4+v5+v6+v7+v8+v9+v10+v11+v12+v13+v14;
%%
table = {'Source','Correction Method','SS','df','MS','F','p'
         factorNames{1},'Sphericity Assumed', roundn(SSA,-3), roundn(v1,-3),  roundn(MSA,-3), roundn(F1,-3), roundn(P1,-3)
                  []      ,'Greenhouse-Geisser', roundn(SSA,-3),roundn(V1_G,-3),roundn(MSA_G,-3),roundn(F1,-3),roundn(P1_G,-3)
         []             ,'Huynd-Feldt',        roundn(SSA,-3), roundn(V1_H,-3),roundn(MSA_H,-3),roundn(F1,-3),roundn(P1_H,-3)
         ['Error(',factorNames{1},')'],'Sphericity Assumed',roundn(SSEA,-3),roundn(v2,-3),roundn(MSEA,-3),[],[]
         []             ,'Greenhouse-Geisser',roundn(SSEA,-3),roundn(V2_G,-3),roundn(MSEA_G,-3),[],[]
          []             ,'Huynd-Feldt',roundn(SSEA,-3),roundn(V2_H,-3),roundn(MSEA_H,-3),[],[]
          factorNames{2},'Sphericity Assumed', roundn(SSB,-3),roundn(v3,-3),roundn(MSB,-3),roundn(F2,-3),roundn(P2,-3)
         []             ,'Greenhouse-Geisser', roundn(SSB,-3),roundn(V3_G,-3),roundn(MSB_G,-3),roundn(F2,-3),roundn(P2_G,-3)
         []             ,'Huynd-Feldt',        roundn(SSB,-3),roundn(V3_H,-3),roundn(MSB_H,-3),roundn(F2,-3),roundn(P2_H,-3)
         ['Error(',factorNames{2},')'],'Sphericity Assumed',roundn(SSEB,-3),roundn(v4,-3),roundn(MSEB,-3),[],[]
         []            ,'Greenhouse-Geisser',roundn(SSEB,-3),roundn(V4_G,-3),roundn(MSEB_G,-3),[],[]
          []            ,'Huynd-Feldt',roundn(SSEB,-3),roundn(V4_H,-3),roundn(MSEB_H,-3),[],[]
          factorNames{3},'Sphericity Assumed', roundn(SSC,-3),roundn(v5,-3),roundn(MSC,-3),roundn(F3,-3),roundn(P3,-3)
         []             ,'Greenhouse-Geisser', roundn(SSC,-3),roundn(V5_G,-3),roundn(MSC_G,-3),roundn(F3,-3),roundn(P3_G,-3)
         []             ,'Huynd-Feldt',      roundn(SSC,-3),roundn(V5_H,-3),roundn(MSC_H,-3),roundn(F3,-3),roundn(P3_H,-3)
         ['Error(',factorNames{3},')'],'Sphericity Assumed',roundn(SSEC,-3),roundn(v6,-3),roundn(MSEC,-3),[],[]
         []            ,'Greenhouse-Geisser',roundn(SSEC,-3),roundn(V6_G,-3),roundn(MSEC_G,-3),[],[]
          []             ,'Huynd-Feldt',roundn(SSEC,-3),roundn(V6_H,-3),roundn(MSEC_H,-3),[],[]
          
          [factorNames{1},'X',factorNames{2}],'Sphericity Assumed', roundn(SSAB,-3),roundn(v7,-3),roundn(MSAB,-3),roundn(F4,-3),roundn(P4,-3)
         []             ,'Greenhouse-Geisser', roundn(SSAB,-3),roundn(V7_G,-3),roundn(MSAB_G,-3),roundn(F4,-3),roundn(P4_G,-3)
         []             ,'Huynd-Feldt',        roundn(SSAB,-3),roundn(V7_H,-3),roundn(MSAB_H,-3),roundn(F4,-3),roundn(P4_H,-3)
         ['Error(',factorNames{1},'X',factorNames{2},')'],'Sphericity Assumed',roundn(SSEAB,-3),roundn(v8,-3),roundn(MSEAB,-3),[],[]
         []             ,'Greenhouse-Geisser',roundn(SSEAB,-3),roundn(V8_G,-3),roundn(MSEAB_G,-3),[],[]
          []             ,'Huynd-Feldt',roundn(SSEAB,-3),roundn(V8_H,-3),roundn(MSEAB_H,-3),[],[]
          
          [factorNames{1},'X',factorNames{3}],'Sphericity Assumed', roundn(SSAC,-3),roundn(v9,-3),roundn(MSAC,-3),roundn(F5,-3),roundn(P5,-3)
         []             ,'Greenhouse-Geisser', roundn(SSAC,-3),roundn(V9_G,-3),roundn(MSAC_G,-3),roundn(F5,-3),roundn(P5_G,-3)
         []             ,'Huynd-Feldt',        roundn(SSAC,-3),roundn(V9_H,-3),roundn(MSAC_H,-3),roundn(F5,-3),roundn(P5_H,-3)
         ['Error(',factorNames{1},'X',factorNames{3},')'],'Sphericity Assumed',roundn(SSEAC,-3),roundn(v10,-3),roundn(MSEAC,-3),[],[]
         []             ,'Greenhouse-Geisser',roundn(SSEAC,-3),roundn(V10_G,-3),roundn(MSEAC_G,-3),[],[]
          []             ,'Huynd-Feldt',roundn(SSEAC,-3),roundn(V10_H,-3),roundn(MSEAC_H,-3),[],[]
          
           [factorNames{2},'X',factorNames{3}],'Sphericity Assumed', roundn(SSBC,-3),roundn(v11,-3),roundn(MSBC,-3),roundn(F6,-3),roundn(P6,-3)
         []             ,'Greenhouse-Geisser', roundn(SSBC,-3),roundn(V11_G,-3),roundn(MSBC_G,-3),roundn(F6,-3),roundn(P6_G,-3)
         []             ,'Huynd-Feldt',        roundn(SSBC,-3),roundn(V11_H,-3),roundn(MSBC_H,-3),roundn(F6,-3),roundn(P6_H,-3)
         ['Error(',factorNames{2},'X',factorNames{3},')'],'Sphericity Assumed',roundn(SSEBC,-3),roundn(v12,-3),roundn(MSEBC,-3),[],[]
         []             ,'Greenhouse-Geisser',roundn(SSEBC,-3),roundn(V12_G,-3),roundn(MSEBC_G,-3),[],[]
          []             ,'Huynd-Feldt',roundn(SSEBC,-3),roundn(V12_H,-3),roundn(MSEBC_H,-3),[],[]
         
           [factorNames{1}','X',factorNames{2},'X',factorNames{3}],'Sphericity Assumed', roundn(SSABC,-3),roundn(v13,-3),roundn(MSABC,-3),roundn(F7,-3),roundn(P7,-3)
         []             ,'Greenhouse-Geisser', roundn(SSABC,-3),roundn(V13_G,-3),roundn(MSABC_G,-3),roundn(F7,-3),roundn(P7_G,-3)
         []             ,'Huynd-Feldt',        roundn(SSABC,-3),roundn(V13_H,-3),roundn(MSABC_H,-3),roundn(F7,-3),roundn(P7_H,-3)
         ['Error(',factorNames{1}','X',factorNames{2},'X',factorNames{3},')'],'Sphericity Assumed',roundn(SSEABC,-3),roundn(v14,-3),roundn(MSEABC,-3),[],[]
         []             ,'Greenhouse-Geisser',roundn(SSEABC,-3),roundn(V14_G,-3),roundn(MSEABC_G,-3),[],[]
          []             ,'Huynd-Feldt',roundn(SSEABC,-3),roundn(V14_H,-3),roundn(MSEABC_H,-3),[],[]}

%     if (isequal(displayopt, 'on'))
%         digits = [-1 -1 -1 0 -1 2 5];
%         statdisptable(table, 'repeated measures ANOVA ', 'ANOVA Table', '', digits);
% %     end