function res = error_bc
res = false;
