%%% Forming a fourth-order tensor : channals*time points*stimuli*subjects

%%%
%%% This code was written by  Guanghui Zhang in May 2020
%%% Faculty of Information Technology, University of Jyv�skyl�, Finland
%%% Address: PL35(Agora), 40014, Jyv�skyl�, Finland
%%% Tel.: +358-46-3207995 (Mobile)
%%% E-mails: zhang.guanghui@foxmail.com
%%% Research gate: https://www.researchgate.net/profile/Zhang_Guanghui/research

%%% Using the code and toolbox, please read and cite the following articles

%%% Zhang, G., Zhang, C., Cao, S., Xia, X., Tan, X., Si, L., ... & Cong, F. (2020).
%%% Multi-domain Features of the Non-phase-locked Component of Interest Extracted from ERP Data by Tensor Decomposition.
%%% Brain Topography, 33(1), 37-47.Doi: https://doi.org/10.1007/s10548-019-00750-8

%%% Zhang, G., Ristaniemi, T., & Cong, F. (2020).
%%% Objective Extraction of Evoked Event-related Oscillations from Time-frequency Representation of Event-related Potentials.
%%% Preprint,bioRxiv.Doi: https://doi.org/10.1101/2020.05.17.100511

%%% Cong, F., Huang, Y., Kalyakin, I., Li, H., Huttunen-Scott, T., Lyytinen, H., & Ristaniemi, T. (2012).
%%% Frequency-response-based wavelet decomposition for extracting children�s mismatch negativity elicited by uninterrupted sound.
%%% Journal of Medical and Biological Engineering, 32, 205-214. Doi: https://doi.org/10.5405/jmbe.908

%%% Cong, F., Tapani, R., & Heikki, L. (2015).
%%% Advanced signal processing on brain event-related potentials: filtering ERPs in time, frequency and space domains sequentially and simultaneously (Vol. 13).
%%% World Scientific.

%%% Delorme, A., & Makeig, S. (2004).
%%% EEGLAB: an open source toolbox for analysis of single-trial EEG dynamics including independent component analysis.
%%% Journal of Neuroscience Methods, 134(1), 9-21. Doi: https://doi.org/10.1016/j.jneumeth.2003.10.009

clear
clc
close all
%%
tic

%% input the parameters for the the inputed signal
EEG_EROIN1 = [];
EEG_ERO = f_importparameters_forming_fourth_tensor(EEG_EROIN1);

EEG_import_parametpers = [];
stiName = EEG_ERO.Sti_Name;
groupNum = EEG_ERO.betwSub_level;

fileType = {'From EEGLAB. .set','From Brain vis. Rec. .vhdr file'};

fileTypeString = {'*.SET*;*.set','.vhdr'};
count = 0;
for jj = 1:1000
    
    
    geometry    = {[3 1.5] [3 1.5] [3 1.5]};
    
    uilist = {...
        { 'Style', 'text', 'string', 'The name of stimulus(click on the selected option)', 'horizontalalignment', 'center', 'fontweight', 'bold' }, ...
        { 'Style', 'popupmenu', 'string', stiName, ...
        'horizontalalignment', 'center', 'tag',  'sphfile' },...
        { 'Style', 'text', 'string', {}, 'horizontalalignment', 'right', 'fontweight', 'bold' }, ...
        { 'Style', 'popupmenu', 'string', {}, ...
        'horizontalalignment', 'right', 'tag',  'sphfile' },...
        { 'Style', 'text', 'string', 'The file type for the selected stimulus (click on the selected option)', 'horizontalalignment', 'center', 'fontweight', 'bold' }, ...
        { 'Style', 'popupmenu', 'string', fileType, ...
        'horizontalalignment', 'center', 'tag',  'sphfile' }};
    
    [ results newcomments ] = inputgui( geometry, uilist);
    
    
    code15 = intersect(EEG_import_parametpers,results{1});
    if ~isempty(code15)
        errordlg2(['The data has been imported for:',32,stiName{results{1}}]);
    else
        
        [inputname, inputpath] = uigetfile2(fileTypeString{results{3}}, ['Load datasets for stimulus:', 32,stiName{results{1}}], 'multiselect', 'on');
        drawnow;
        %%
        if groupNum <2
            %%% Importing data for the within-subject
            [EEG_ERO,EEG_import_parametpers] = f_import_data_within_subject(EEG_ERO,inputname,inputpath,results,EEG_import_parametpers);
        else
            %%%  Import data for the between-subjet
            [EEG_ERO,EEG_import_parametpers] = f_import_data_between_subject(EEG_ERO,inputname,inputpath,results,EEG_import_parametpers);
            %%
            
        end
        
    end
    %%
    
    count1 = 0;
    for iii = 1:length(EEG_import_parametpers)
        
        code11 = intersect([1:length(stiName)], EEG_import_parametpers(iii));
        if ~isempty(code11)
            count1 = count1 +1;
        end
        
    end
    
    if count1 == length(stiName)
        
        if groupNum < 2
            EEG_ERO.GroupIdex = ones(size(EEG_ERO.data,4),1);
        end
        break;
    end
    
end

[fn pn, filterindex] = uiputfile('*.mat','Save as');

FN = char(strcat(fn(1:end-4),'_structure.mat'));
save([pn FN],'EEG_ERO','-v7.3');

Fn = char(strcat(fn(1:end-4),'_fourth_order_tensor.mat'));
data = EEG_ERO.data;
save([pn Fn],'data','-v7.3');
%%
toc

