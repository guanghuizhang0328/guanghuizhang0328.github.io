function [EEG_EROOUT, EEG_import_parametpersout] = f_import_data_between_subject(EEG_EROIN,inputname,inputpath,results,EEG_import_parametpersin);
%%

stiName = EEG_EROIN.Sti_Name;
groupNum = EEG_EROIN.betwSub_level;
GroupIdex = EEG_EROIN.GroupIdex;

code11 = setdiff([1:length(stiName)], EEG_import_parametpersin);

if isempty(code11)
    errordlg2(['The signals for all stimuli have been imported']);
    EEG_EROIN.GroupIdex = ones(size(EEG_EROIN.data,4),1);
    EEG_EROOUT = EEG_EROIN;
    EEG_import_parametpersout = EEG_import_parametpersin;
    return;
end

% if ~isempty(EEG_import_parametpersin)
%     if size(EEG_EROIN.data,4) ~= length(inputname)
%         errordlg2(['The number of subjects for',32,stiName{results{1}},32,'is not consistent with the previous one!!!']);
%         EEG_EROOUT = EEG_EROIN;
%         EEG_import_parametpersout = EEG_import_parametpersin;
%         return;
%     end
%     
% end


stiNum1 = length(stiName)/groupNum;
idx1 = [];
idx1 = find(GroupIdex == ceil(results{1}/stiNum1));
%%%

for Numofsub1 = 1:length(inputname)
    D = [];
    if results{3} ==1
        D1  = pop_loadset(inputname{Numofsub1},inputpath);
        D1 = eeg_checkset( D1 );
    elseif results{3} == 2
        D1  = pop_loadbv(inputpath,inputname{Numofsub1});
        D1 = eeg_checkset( D1 );
    end
    
    [a,b,c] = size(D1.data);
    
    if c > 1
        errordlg2(['Please average the trials']);
    end
    
    EEG_EROIN.data(:,:,(results{1}- (ceil(results{1}/stiNum1)-1)*stiNum1),idx1(Numofsub1))  = double(D1.data);
end
EEG_import_parametpersin(length(EEG_import_parametpersin)+1) = results{1};
EEG_import_parametpersout = EEG_import_parametpersin;

EEG_EROOUT = EEG_EROIN;

return;