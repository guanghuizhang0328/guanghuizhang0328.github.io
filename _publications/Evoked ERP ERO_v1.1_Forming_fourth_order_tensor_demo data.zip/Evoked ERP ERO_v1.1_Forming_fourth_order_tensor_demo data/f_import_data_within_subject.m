function [EEG_EROOUT,EEG_import_parametpersout] = f_import_data_within_subject(EEG_EROIN,inputname,inputpath,results,EEG_import_parametpersin);
%%

stiName = EEG_EROIN.Sti_Name;

code11 = setdiff([1:length(stiName)], EEG_import_parametpersin);

if isempty(code11)
    errordlg2(['The signals for all stimuli have been imported']);
    EEG_EROIN.GroupIdex = ones(size(EEG_EROIN.data,4),1);
    EEG_EROOUT = EEG_EROIN;
    EEG_import_parametpersout = EEG_import_parametpersin;
    return;
end

if ~isempty(EEG_import_parametpersin)
    if size(EEG_EROIN.data,4) ~= length(inputname)
        errordlg2(['The number of subjects for',32,stiName{results{1}},32,'is not consistent with the previous one!!!']);
        EEG_EROOUT = EEG_EROIN;
        EEG_import_parametpersout = EEG_import_parametpersin;
        return;
    end
    
end

for Numofsub = 1:length(inputname)
    D = [];
    if results{3} ==1
        D  = pop_loadset(inputname{Numofsub},inputpath);
        D = eeg_checkset( D );
    elseif results{3} ==2
        D  = pop_loadbv(inputpath,inputname{Numofsub});
        D = eeg_checkset(D);
    end
    
    [a,b,c] = size(D.data);
    
    if c > 1
        errordlg2(['Please average the trials']);
        EEG_EROOUT = EEG_EROIN;
        return;
    end
    
    EEG_EROIN.data(:,:,results{1},Numofsub)  = double(D.data);
end
EEG_import_parametpersin(length(EEG_import_parametpersin)+1) = results{1};
EEG_import_parametpersout = EEG_import_parametpersin;


EEG_EROOUT = EEG_EROIN;

return;
