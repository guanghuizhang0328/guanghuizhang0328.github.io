% modified from EEGlab function-pop_importdata() - import data from a Matlab variable or disk file by calling
%                    importdata().


function EEG_EROOUT = f_importparameters_forming_fourth_tensor(EEG_EROIN);

% p1 = mfilename('fullpath');
% i= findstr(p1,filesep);
% p1=p1(1:i(end));
% Currentpath = char(strcat(p1,'functions',filesep));
% addpath(genpath(Currentpath));
EEG_EROIN = f_eeg_ero_emptyset(EEG_EROIN);
% popup window parameters
% -----------------------

commandload = [ '[filename, filepath] = uigetfile(''*'', ''Select a text file'');' ...
    'if filename(1) ~=0,' ...
    '   set(findobj(''parent'', gcbf, ''tag'', tagtest), ''string'', [ filepath filename ]);' ...
    'end;' ...
    'clear filename filepath tagtest;' ];

geometry    = { [1.4 2.3 0.5] [1] [2 1 2 1] [2 1 2 1] [2 1 2 1] [2 1 2 1]};

uilist = { ...
    { 'Style', 'text', 'string', 'Channel location file (.mat)', 'horizontalalignment', 'right' , 'fontweight', 'bold' },  ...
    { 'Style', 'edit', 'string', '', 'horizontalalignment', 'left', 'tag',  'sphfile' }, ...
    { 'Style', 'pushbutton', 'string', 'Browse', 'callback', [ 'tagtest = ''sphfile'';' commandload ] },{}...
    ...
    { 'Style', 'text', 'string', 'Data sampling rate (Hz)', 'horizontalalignment', 'right', ...
    }, { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Levels of first-factor (within-subject)', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '0' }, ...
    ...
    { 'Style', 'text', 'string', 'Epoch Start (ms)', 'horizontalalignment', 'right', ...
    },  { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Levels of second-factor (within-subject)', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Epoch End (ms)', 'horizontalalignment', 'right', ...
    }, { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Levels of third-factor (within-subject)', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Levels of between-subject factors', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '1' }, ...
    {},   {}};



[ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_importparameters_forming_fourth_tensor'');', 'Import dataset info -- f_importparameters_forming_fourth_tensor()');


if isempty(results)
    EEG_EROOUT = EEG_EROIN;
    return;
end


results1 = results([1:2,4,6]);



count1 = 0;
for ii = 1:length(results1)
    if isempty(results1{ii}) == 1
        count1 = count1 +1;
    end
end

if count1 ~= 0
    errordlg2('Please input the necessary parameters');
    EEG_EROOUT = EEG_EROIN;
    return;
else
    

    EEG_EROIN.chanlocs  = importdata(results{1});
    EEG_EROIN.srate = str2num(results{2});
    EEG_EROIN.epochStart = str2num(results{4});
    EEG_EROIN.epochEnd = str2num(results{6});
    factor1= str2num(results{3});
    factor2= str2num(results{5});
    factor3= str2num(results{7});
    groupNum = str2num(results{8});
    
    if groupNum < 2
        
        if factor1 < 2
            errordlg2('The levels for the 1st factor should be more than 1');
            EEG_EROOUT = EEG_EROIN;
            return;
        end
        
          
        if (factor1 == 0 & factor2 ~= 0)| (factor1 == 0 & factor3 ~= 0)
            errordlg2('The levels for the 1st factor should be more than 1');
            EEG_EROOUT = EEG_EROIN;
  
            return;
        end
        
        Sti_Name = f_form_stiname_withsub(factor1,factor2,factor3);
   
    EEG_EROIN.Sti_Name = Sti_Name;
    EEG_EROIN.betwSub_level = groupNum;
    EEG_EROIN.withSub_level_one = factor1;
    EEG_EROIN.withSub_level_two = factor2;
    EEG_EROIN.withSub_level_three = factor3;
     
        
    else
    [GroupIdex,Sti_Name,Sti_Name_within] = f_form_stiname_betwsub(groupNum,factor1,factor2,factor3);
    EEG_EROIN.Sti_Name_within = Sti_Name_within;
    
    EEG_EROIN.Sti_Name = Sti_Name;
    EEG_EROIN.GroupIdex = GroupIdex;
    EEG_EROIN.betwSub_level = groupNum;
    EEG_EROIN.withSub_level_one = factor1;
    EEG_EROIN.withSub_level_two = factor2;
    EEG_EROIN.withSub_level_three = factor3;
    
    
    
    end
 
    
  
    
 
    
   EEG_EROOUT = EEG_EROIN;

end;
return;
