
function f_rmanova(topo_box,NumGroups,factor1,factor2,factor3,Group_Idx)


[subNum,stiNum]= size(topo_box);
if NumGroups == 1
    
    levelNum_first= factor1;
    levelNum_second = factor2;
    levelNum_third = factor3;
    %%  one-way ANOVA
    if levelNum_first > 0 & levelNum_second == 0 & levelNum_third == 0
        X = [];
        X = topo_box;
        stiNum = levelNum_first;
        BTFacs =[];
        WInFacs = [];
        for is = 1:size(X,2)
            IdexStart = subNum*(is-1)+1;
            IdexEnd =  is*subNum;
            WInFacs(IdexStart:IdexEnd,1) = is;
        end
        %%
        S = [];
        for iss = 1:stiNum
            IdexStart = subNum*(iss-1)+1;
            IdexEnd =  iss*subNum;
            S(IdexStart:IdexEnd,1) =1:subNum ;
        end
        factorNames = {'A'};
        correction_string.BTFacs = BTFacs;
        correction_string.WInFacs=WInFacs;
        correction_string.S = S;
        [p, table] = f_anova1_rm(X,correction_string);
        %%  two-way ANOVA
    elseif  levelNum_first > 0 & levelNum_second > 0 & levelNum_third == 0
        
        Y = [];
        Y = reshape(topo_box,[],1);
        stiOne = levelNum_first;
        stiTwo = levelNum_second ;
        stiNum = stiOne*stiTwo;
        BTFacs =[];
        WInFacs = [];
        count = 0;
        for is = 1:stiOne
            IdexStart = subNum*(is-1)*stiTwo+1;
            IdexEnd =  is*subNum*stiTwo;
            WInFacs(IdexStart:IdexEnd,1) = is;
            for iss  = 1:stiTwo
                count  = count +1;
                IdexStart = subNum*(count-1)+1;
                IdexEnd =  subNum*count;
                WInFacs(IdexStart:IdexEnd,2) = iss;
            end
        end
        
        S = [];
        for iss = 1:stiNum
            IdexStart = subNum*(iss-1)+1;
            IdexEnd =  iss*subNum;
            S(IdexStart:IdexEnd,1) =1:subNum ;
        end
        factorNames = {'A','B'};
        D = reshape(Y,1 ,[]);
        stat = f_rm_anova2(D,WInFacs,S,factorNames);
        
        %%  three-way ANOVA
    elseif  levelNum_first > 0 & levelNum_second > 0 & levelNum_third > 0
        Y = [];
        X = [];
        Y = reshape(topo_box,[],1);
        stiOne = levelNum_first;
        stiTwo = levelNum_second ;
        stiThree =levelNum_third;
        
        BTFacs =[];
        WInFacs = [];
        count = 0;
        for is = 1:stiOne
            IdexStart = subNum*(is-1)*stiTwo*stiThree+1;
            IdexEnd =  is*subNum*stiTwo*stiThree;
            WInFacs(IdexStart:IdexEnd,1) = is;
            for iss  = 1:stiTwo
                for isss  =1:stiThree
                    count  = count +1;
                    IdexStart = subNum*(count-1)+1;
                    IdexEnd =  subNum*count;
                    WInFacs(IdexStart:IdexEnd,2) = iss;
                    WInFacs(IdexStart:IdexEnd,3) = isss;
                end
            end
        end
        
        S = [];
        for iss = 1:stiNum
            IdexStart = subNum*(iss-1)+1;
            IdexEnd =  iss*subNum;
            S(IdexStart:IdexEnd,1) =1:subNum ;
        end
        factorNames = {'A','B','C'};
        X = [Y,WInFacs,S];
        sta = f_withinanova_rm3(X,0.05,factorNames);
    end
    %% between subjects analysis
else
    
    levelNum_first= NumGroups;
    levelNum_second = factor1;
    levelNum_third = factor2;
    %% two-way ANOVA
    if levelNum_first > 0 & levelNum_second > 0 & levelNum_third == 0
        
        BTFacs =[];
        WInFacs = [];
        S = [];
        Y = [];
        for is = 1:NumGroups
            idx1 = find(Group_Idx == is);
            X1 = topo_box(idx1,:);
            X1  = reshape(X1,[],1);
            Y = [Y;X1];
            for iss  = 1:stiNum
                
                BTFacs = [BTFacs;ones(length(idx1),1)*is];
                %%
                WInFacs = [WInFacs; ones(length(idx1),1)*iss];
                %%
                S =[S;idx1];
            end
        end
        D_a(:,1)= Y;
        D_a(:,2)= BTFacs;
        D_a(:,3)= WInFacs;
        D_a(:,4)= S;
        factorNames={'Group','Factor'};
        disp('>>The repated meansurement ANOVA results for two-factor of between-subject analysis:');
        [SSQs, DFs, MSQs, Fs, Ps] = f_mixed_between_within_anova1(D_a,factorNames);
        %% three-way ANOVA
    elseif   levelNum_first > 0 & levelNum_second > 0 & levelNum_third > 0
        X = reshape(topo_box,1,[]);
        count = 0;
        count1 = 0;
        for Numoflevel_second = 1:levelNum_second
            idxStart = subNum*levelNum_third*(Numoflevel_second-1) + 1;
            idxEnd = subNum*levelNum_third*(Numoflevel_second);
            staIDX(idxStart:idxEnd,3) = Numoflevel_second;
            for Numoflevel_third = 1:levelNum_third
                count = count + 1;
                idxStart1 = subNum*(count-1) + 1;
                idxEnd1 = subNum*(count);
                staIDX(idxStart1:idxEnd1,2) = Numoflevel_third;
                count1  = count1 +1;
                idxStart2 = subNum*(count1-1) + 1;
                idxEnd2 = subNum*(count1);
                staIDX(idxStart2:idxEnd2,1) = Group_Idx;
            end
        end
        varnames(3) = cellstr({'Group'});
        varnames(1) = cellstr({'A'});
        varnames(2) = cellstr({'B'});
        disp('>>The n-way ANOVA results for  three-factorof between-subject analysis:');
        fprintf('\n');
        [~,atab] = anovan(X,staIDX,'model',3 ,'varnames',strvcat('A', 'B', 'Group'))
    end
end
return;