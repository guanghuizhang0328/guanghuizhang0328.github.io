function f_output_excel(TOPO,interestchanName,ChansOfInterestNumbers,Stimulus_Name,Measure_channel_Flag,Group_Idx)


excelEnd_1   = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q',...
    'R','S','T','U','V','W','X','Y','Z'};
count = 0;
for iss = 1:5
    for is  = 1:length(excelEnd_1)
        count = count +1;
        excelEnd_2{count} = [excelEnd_1{iss},excelEnd_1{is}];
    end
end
excelEnd = [excelEnd_1,excelEnd_2];



if Measure_channel_Flag==1
    %%%%%%%averaging electrodes
    data = squeeze(mean(TOPO(ChansOfInterestNumbers,:,:),1));
    data = permute(data,[2 1]);
    Names_sti= Stimulus_Name;
else
    %%%%%%%%Not averaging electrodes
    temp = squeeze(TOPO(ChansOfInterestNumbers,:,:));
    data= [];
    for Numofchan = 1:length(ChansOfInterestNumbers)
        data = [data,squeeze(temp(Numofchan,:,:))'];
    end
    %%%%%%%%%%%%organize the names for stimuli
    count= 0;
    for Numofchan = 1:length(ChansOfInterestNumbers)
        for Numofsti = 1:length(Stimulus_Name)
            count = count+1;
            Names_sti{count}= strcat(interestchanName{Numofchan},'-',Stimulus_Name{Numofsti});
        end
    end
end

NumGroups = max(Group_Idx(:));

if NumGroups == 1
    x = data;
    rangeName = Names_sti;
else
    x = [Group_Idx,data];
    rangeName = ['Group', Names_sti];
end


[filename, pathname, filterindex] = uiputfile({'*.xlsx','Excel-files (*.xlsx)'},'Save as .xlsx');
% fileName= char(strcat(pathname, filename));
%         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[rowNum,columnNum] = size(x);


excelName = filename;
heandrang = strcat('A1:',excelEnd{columnNum},int2str(1));
datarang = strcat('A2:',excelEnd{columnNum},int2str(rowNum+1));
xlswrite([pathname excelName],rangeName,heandrang);
xlswrite([pathname excelName],x,datarang);%% if cann't output data ,please replace excelName{1,1} by excelName

return;