function f_withinsubject_rmANOVA(EEG_ERO);

if isempty(EEG_ERO.data)
    errordlg2('Cannot further analysis an empty dataset');
    return;
end

if EEG_ERO.betwSub_level > 1
    errordlg2('>Statistical Analysis>Between-subject ANOVA');
    return;
end

% if EEG_ERO.PCA_measurement_index == 0
%     errordlg2('The signal is not processed using PCA, please check it');
%     return;
% end



if EEG_ERO.sta_index ==0
    errordlg2('The signal is not processed, please check it');
    return;
end

%%
groupNum = EEG_ERO.betwSub_level ;
factor1 = EEG_ERO.withSub_level_one;
factor2 = EEG_ERO.withSub_level_two ;
factor3 = EEG_ERO.withSub_level_three;
stiNum = length(EEG_ERO.Sti_Name);

if stiNum == 2
    errordlg2('Can not use rm-ANOVA');
end



data = double(EEG_ERO.data);
topo_box = data';

if factor1 > 0 & factor2 == 0 & factor3 == 0
    
    if factor1 ~= size(data,1)
        errordlg2('Please check data');
        return;
    end
    [subNum,stiNum]= size(topo_box);
    X = topo_box;
    stiNum = factor1;
    BTFacs =[];
    WInFacs = [];
    for is = 1:size(X,2)
        IdexStart = subNum*(is-1)+1;
        IdexEnd =  is*subNum;
        WInFacs(IdexStart:IdexEnd,1) = is;
    end
    %%
    S = [];
    for iss = 1:stiNum
        IdexStart = subNum*(iss-1)+1;
        IdexEnd =  iss*subNum;
        S(IdexStart:IdexEnd,1) =1:subNum ;
    end
    factorNames = {'A'};
    
    correction_string.BTFacs = BTFacs;
    correction_string.WInFacs=WInFacs;
    correction_string.S = S;
    [p, table] = f_anova1_rm(X,correction_string);
    %%  two-way ANOVA
elseif  factor1 > 0 & factor2 > 0 & factor3 == 0
    
    if factor1*factor2 ~= size(data,1)
        errordlg2('Please check data');
        return;
    end
    
    [subNum,stiNum]= size(topo_box);
    Y = reshape(topo_box,[],1);
    stiOne = factor1;
    stiTwo = factor2;
    stiNum = stiOne*stiTwo;
    BTFacs =[];
    WInFacs = [];
    count = 0;
    for is = 1:stiOne
        IdexStart = subNum*(is-1)*stiTwo+1;
        IdexEnd =  is*subNum*stiTwo;
        WInFacs(IdexStart:IdexEnd,1) = is;
        for iss  = 1:stiTwo
            count  = count +1;
            IdexStart = subNum*(count-1)+1;
            IdexEnd =  subNum*count;
            WInFacs(IdexStart:IdexEnd,2) = iss;
        end
    end
    
    S = [];
    for iss = 1:stiNum
        IdexStart = subNum*(iss-1)+1;
        IdexEnd =  iss*subNum;
        S(IdexStart:IdexEnd,1) =1:subNum ;
    end
    factorNames = {'A','B'};
    D = reshape(Y,1 ,[]);
    sta = f_rm_anova2(D,WInFacs,S,factorNames);
    %
    %%  three-way ANOVA
elseif  factor1 > 0 & factor2 > 0 & factor3 > 0
    if factor1*factor2*factor3 ~= size(data,1)
        errordlg2('Please check data');
        return;
    end
    
    [subNum,stiNum]= size(topo_box);
    Y = reshape(topo_box,[],1);
    stiOne = factor1;
    stiTwo = factor2 ;
    stiThree =factor3;
    
    BTFacs =[];
    WInFacs = [];
    count = 0;
    for is = 1:stiOne
        IdexStart = subNum*(is-1)*stiTwo*stiThree+1;
        IdexEnd =  is*subNum*stiTwo*stiThree;
        WInFacs(IdexStart:IdexEnd,1) = is;
        for iss  = 1:stiTwo
            for isss  =1:stiThree
                count  = count +1;
                IdexStart = subNum*(count-1)+1;
                IdexEnd =  subNum*count;
                WInFacs(IdexStart:IdexEnd,2) = iss;
                WInFacs(IdexStart:IdexEnd,3) = isss;
            end
        end
    end
    
    S = [];
    for iss = 1:stiNum
        IdexStart = subNum*(iss-1)+1;
        IdexEnd =  iss*subNum;
        S(IdexStart:IdexEnd,1) =1:subNum ;
    end
    X = [];
    factorNames = {'A','B','C'};
    X = [Y,WInFacs,S];
    sta = f_withinanova_rm3(X,0.05,factorNames);
end
return;