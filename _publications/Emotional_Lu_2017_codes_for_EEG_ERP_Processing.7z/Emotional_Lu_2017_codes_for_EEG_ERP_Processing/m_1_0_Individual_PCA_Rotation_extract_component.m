%%% Using PCA to extract ERPs of interest from the filtered single-trial dataset of individual subject separately and analysing back-projection:
%%%     1.Estimate the number of sources by using cumulative explained variance  method
%%%     2.Plot rotated temporal and spatial components
%%%     3.Select the componnets associated with ERPs of interest.
%%%     4.Project the selected components to the electrode fields (i.e., in microvolts)
%%%     5.Averaing waveforms over trials under each condition
%%%     6.Save the current data as .mat file
%%% Analyzing back-projection of ERPs of interest:
%%%     1.Plot averaged waveforms (over trials) at specific eletrodes
%%%     2.Plot averaged topographies (over trials) within predifined time-window for ERPs


%%% In order to run this code, please install EEGLAB toolboxes. It can be downloaded from http://sccn.ucsd.edu/eeglab/
%%% This code was written by GuangHui Zhang in July 2021, JYU
%%% Faculty of Information Technology, University of Jyv�skyl�
%%% Address: Seminaarinkatu 15,PO Box 35, FI-40014 University of Jyv�skyl�,Jyv�skyl�, FINLAND
%%% E-mails: zhang.guanghui@foxmail.com


%%% When using this code, please cite the following articles:
%%% 1. Guanghui Zhang, Xueyan Li, Yingzhi Lu, Timo Tiihonen, Zheng Chang, and Fengyu Cong. (2021). 
%%%    Single-trial-based Temporal Principal Component Analysis on Extracting Event-related Potentials of Interest for an Individual Subject.
%%%    bioRxiv. DOI:10.1101/2021.03.10.434892
%%% 2. Fengyu Cong, Yixiang Huang, Igor Kalyakin, Hong Li, Tiina Huttunen-Scott, Heikki Lyytinen, Tapani Ristaniemi,
%%%    Frequency Response based Wavelet Decomposition to Extract Children's Mismatch Negativity Elicited by Uninterrupted Sound,
%%%    Journal of Medical and Biological Engineering, 2012, 32(3): 205-214, DOI: 10.5405/jmbe.908
%%% 3. Guanghui Zhang, Xueyan Li, and Fengyu Cong. Objective Extraction of Evoked Event-related Oscillation from Time-frequency Representation of Event-related Potentials.
%%%    Neural Plasticity. DOI:10.1155/2020/8841354
%%% 4. Lu, Y., Luo, Y., Lei, Y., Jaquess, K. J., Zhou, C., & Li, H. (2016). Decomposing valence intensity effects in disgusting and fearful stimuli: an event-related potential study.
%%%    Social neuroscience, 11(6), 618-626. doi:https://doi.org/10.1080/17470919.2015.1120238


clear
clc
close all
%%
tic
%Location of the main study directory
%This method of specifying the study directory only works if you run the script;
%for running individual lines of code, replace the study directory with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment
Subject_file_Path = fileparts(fileparts(mfilename('fullpath')));


%Location of the folder that contains this script and any associated processing files
%This method of specifying the current file path only works if you run the script;
%For running individual lines of code, replace the current file path with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment\Codes_for_EEG_ERP_Processing
Current_File_Path = fileparts(mfilename('fullpath'));
%% add function into path
Currentpath1 = char(strcat(Current_File_Path,filesep,'functions',filesep));
addpath(genpath(Currentpath1));
%%
%%%
if exist('Parameter_individual_subject.mat','file') ==0
    
    
    geometry    = { [1.4 2.3 0.5] [1] [2 1 2 1] [2 1 2 1] [2 1 2 1] [5 1]};
    editcomments = [ 'tmp = pop_comments(get(gcbf, ''userdata''), ''Edit comments of current dataset'');' ...
        'if ~isempty(tmp), set(gcf, ''userdata'', tmp); end; clear tmp;' ];
    commandload = [ '[filename, filepath] = uigetfile(''*'', ''Select a text file'');' ...
        'if filename(1) ~=0,' ...
        '   set(findobj(''parent'', gcbf, ''tag'', tagtest), ''string'', [ filepath filename ]);' ...
        'end;' ...
        'clear filename filepath tagtest;' ];
    
    
    uilist = { ...
        { 'Style', 'text', 'string', 'Channel location file (.mat)', 'horizontalalignment', 'right' , 'fontweight', 'bold' },  ...
        { 'Style', 'edit', 'string', '', 'horizontalalignment', 'left', 'tag',  'sphfile' }, ...
        { 'Style', 'pushbutton', 'string', 'Browse', 'callback', [ 'tagtest = ''sphfile'';' commandload ] },{}...
        ...
        { 'Style', 'text', 'string', 'Data sampling rate (Hz)', 'horizontalalignment', 'right', ...
        }, { 'Style', 'edit', 'string', '0' }, ...
        { 'Style', 'text', 'string', 'Levels of first-factor (within-subject)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', '0' }, ...
        ...
        { 'Style', 'text', 'string', 'Epoch Start (ms)', 'horizontalalignment', 'right', ...
        },  { 'Style', 'edit', 'string', '0' }, ...
        { 'Style', 'text', 'string', 'Levels of second-factor (within-subject)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', '0' }, ...
        { 'Style', 'text', 'string', 'Epoch End (ms)', 'horizontalalignment', 'right', ...
        }, { 'Style', 'edit', 'string', '0' }, ...
        { 'Style', 'text', 'string', 'Levels of third-factor (within-subject)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', '0' }, ...
        { 'Style', 'text', 'string', 'Method (1.PCA; 2. Time-domain analysis;3. Wavelet filter; 4.WF+PCA)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', '1' }};
    
    
    [ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_importdata'');', 'Import dataset info -- f_importdata()');
    
    chanlocs  = importdata(results{1});
    fs = str2num(results{2});
    timeStart = str2num(results{4});
    timeEnd = str2num(results{6});
    factor1= str2num(results{3});
    factor2= str2num(results{5});
    factor3= str2num(results{7});
    MethodFlag =  str2num(results{8});
    Stimulus_Name = f_form_stiname_withsub(factor1,factor2,factor3);
    chanlocs_Pth =results{1};
    
    save('Parameter_individual_subject','chanlocs_Pth','fs','timeStart','timeEnd','factor1','factor2','factor3','MethodFlag','Stimulus_Name');
    
else
    
    
    load Parameter_individual_subject;
    
    geometry    = { [1.4 2.3 0.5] [1] [2 1 2 1] [2 1 2 1] [2 1 2 1] [5 1]};
    editcomments = [ 'tmp = pop_comments(get(gcbf, ''userdata''), ''Edit comments of current dataset'');' ...
        'if ~isempty(tmp), set(gcf, ''userdata'', tmp); end; clear tmp;' ];
    commandload = [ '[filename, filepath] = uigetfile(''*'', ''Select a text file'');' ...
        'if filename(1) ~=0,' ...
        '   set(findobj(''parent'', gcbf, ''tag'', tagtest), ''string'', [ filepath filename ]);' ...
        'end;' ...
        'clear filename filepath tagtest;' ];
    
    uilist = { ...
        { 'Style', 'text', 'string', 'Channel location file (.mat)', 'horizontalalignment', 'right' , 'fontweight', 'bold' },  ...
        { 'Style', 'edit', 'string', chanlocs_Pth, 'horizontalalignment', 'left', 'tag',  'sphfile' }, ...
        { 'Style', 'pushbutton', 'string', 'Browse', 'callback', [ 'tagtest = ''sphfile'';' commandload ] },{}...
        ...
        { 'Style', 'text', 'string', 'Data sampling rate (Hz)', 'horizontalalignment', 'right', ...
        }, { 'Style', 'edit', 'string', fs }, ...
        { 'Style', 'text', 'string', 'Levels of first-factor (within-subject)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', factor1 }, ...
        ...
        { 'Style', 'text', 'string', 'Epoch Start (ms)', 'horizontalalignment', 'right', ...
        },  { 'Style', 'edit', 'string', timeStart }, ...
        { 'Style', 'text', 'string', 'Levels of second-factor (within-subject)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', factor2 }, ...
        { 'Style', 'text', 'string', 'Epoch End (ms)', 'horizontalalignment', 'right', ...
        }, { 'Style', 'edit', 'string', timeEnd }, ...
        { 'Style', 'text', 'string', 'Levels of third-factor (within-subject)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', factor3 }, ...
        { 'Style', 'text', 'string', 'Method (1.PCA; 2. Time-domain analysis; 3. Wavelet filter; 4. WF+PCA)', 'horizontalalignment', 'right', ...
        },   { 'Style', 'edit', 'string', MethodFlag }};
    
    
    [ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_importdata'');', 'Import dataset info -- f_importdata()');
    
    chanlocs  = importdata(results{1});
    fs = str2num(results{2});
    timeStart = str2num(results{4});
    timeEnd = str2num(results{6});
    factor1= str2num(results{3});
    factor2= str2num(results{5});
    factor3= str2num(results{7});
    MethodFlag =  str2num(results{8});
    chanlocs_Pth =results{1};
    save('Parameter_individual_subject','chanlocs_Pth','fs','timeStart','timeEnd','factor1','factor2','factor3','MethodFlag','Stimulus_Name');
end





fileType = {'From EEGLAB. .set','From Brain vis. Rec. .vhdr file','From ERPlab. .erp file'};

fileTypeString = {'*.SET*;*.set','.vhdr','.erp'};

Data = [];

for Numofsti = 1:length(Stimulus_Name)
    
    
    geometry    = {[3 1.5] [3 1.5] [3 1.5]};
    
    uilist = {...
        { 'Style', 'text', 'string', 'The name of stimulus(click on the selected option)', 'horizontalalignment', 'center', 'fontweight', 'bold' }, ...
        { 'Style', 'popupmenu', 'string', Stimulus_Name, ...
        'horizontalalignment', 'center', 'tag',  'sphfile' },...
        { 'Style', 'text', 'string', {}, 'horizontalalignment', 'right', 'fontweight', 'bold' }, ...
        { 'Style', 'popupmenu', 'string', {}, ...
        'horizontalalignment', 'right', 'tag',  'sphfile' },...
        { 'Style', 'text', 'string', 'The file type for the selected stimulus (click on the selected option)', 'horizontalalignment', 'center', 'fontweight', 'bold' }, ...
        { 'Style', 'popupmenu', 'string', fileType, ...
        'horizontalalignment', 'center', 'tag',  'sphfile' }};
    
    [ results3 newcomments ] = inputgui( geometry, uilist);
    
    Filetype  = results3{3};
    
    
    [inputname, inputpath] = uigetfile2(fileTypeString{results3{3}}, ['Load datasets for stimulus:', 32,Stimulus_Name{results3{1}}], 'multiselect', 'on');
    drawnow;
    
    EEG =[];
    d3  =[];
    if Filetype == 1
        EEG = pop_loadset(inputname,inputpath);
        EEG = eeg_checkset( EEG );
        EEG = pop_select( EEG,'nochannel',{'TP9' 'VEOG' 'TP10' 'HEOG'});
        EEG = eeg_checkset( EEG );
        d3 = double(EEG.data);
    elseif Filetype == 2
        EEG = pop_loadbv(inputpath,inputname);
        EEG = eeg_checkset(EEG);
        EEG = pop_select( EEG,'nochannel',{'TP9' 'VEOG' 'TP10' 'HEOG'});
        EEG = eeg_checkset( EEG );
        d3 = double(EEG.data);
        
    else
        EEG = pop_loaderp( 'filename', inputname, 'filepath', inputpath);
        d3 = double(EEG.bindata);
    end
    
    Data{Numofsti}=d3;
end




%%%%%%%%convnentinal time domain analysis
if MethodFlag ==2
    
    stiNum = length(Data);
    D = [];
    for Numofstimuli = 1:stiNum
        data = [];
        data = Data{Numofstimuli};
        D(:,:,Numofstimuli) = squeeze(mean(data,3));
    end
    
    
    %%%wavelet filter
elseif   MethodFlag ==3
    
    d3 =[];
    data = [];
    data = Data{1};
    [chanNum,NumSamps,trialNum] = size(data);
    wname = ['rbio6.8'];%% Name of the wavelet
    
    if fs <= 1024 & fs > 512
        lv = 10;
    elseif fs <= 512 & fs > 256
        lv = 9;
    elseif 128 < fs & fs <= 256
        lv = 8;
    end
    
    kp = [2 3 4 5 6]; %% Reconstruction and output the result
    timePstart = round((0-timeStart)/(1000/fs))+1;
    
    %%Frequency responses of wavelet filter
    Len=NumSamps;
    Dura = NumSamps;
    FFTLen=fs*10;
    freqRs=fs/FFTLen;
    freLow=fs/FFTLen;
    freHigh = 35;
    binLow=freLow/freqRs;
    binHigh=freHigh/freqRs;
    timeIndex=(1:(2*Len-1))*1000/fs;
    fIndex=freLow:freqRs:freHigh;
    sig=[zeros(Len-1,1);1; zeros(Len-1,1)];
    tIndex = linspace(-Dura,Dura,length(sig));
    %%%%%%%%%%%%%%%%%%%%%%% Wavelet filter
    WLDsig=f_filterWavelet(sig,lv,wname,kp);
    WLDsigFFT=fft(WLDsig,FFTLen);
    spec=abs(WLDsigFFT(binLow:binHigh,:));
    WaveletfreqResp=20*log10(spec/max(spec));
    Waveletphase = 2*pi*phase(WLDsigFFT(binLow:binHigh));
    
    figure(101);
    % set(gcf,'outerposition',get(0,'screensize'));
    subplot(2,1,1);
    set(gca,'fontsize',20);
    hold on;
    plot(fIndex,WaveletfreqResp,'k','linewidth',3);
    xlim([freLow,freHigh]);
    ylim([-100 20]);
    tN = ['Magnitude of frequency responses '];
    title(tN,'fontsize',16);
    xlabel('Frequency/Hz','fontsize',16);
    ylabel('Attenuation/dB','fontsize',16);
    legend(' Wavelet filter','location','Southwest')
    
    subplot(2,1,2);
    set(gca,'fontsize',20);
    hold on;
    plot(fIndex,Waveletphase,'k','linewidth',3);
    xlim([freLow,freHigh]);
    tN = ['Phase of frequency responses'];
    title(tN,'fontsize',16);
    xlabel('Frequency/Hz','fontsize',16);
    ylabel('Angle/degree','fontsize',16);
    %%
    stiNum = length(Data);
    D = [];
    for Numofsti = 1:stiNum
        
        %%load data of each subject under each condition
        d3 =[];
        data = [];
        data = Data{Numofsti};
        [chanNum,sampoints,trialNum] = size(data);
        for Numoftrial = 1:trialNum
            for chan = 1:size(data,1)
                temp = squeeze(data(chan,:,Numoftrial))' ;
                temp1 = f_filterWavelet(temp,lv,wname,kp);
                temp1 = temp1 - mean(temp1(1:timePstart));
                d3 (chan,:,Numoftrial) = temp1;
                
            end
        end
        
        D(:,:,Numofsti) = squeeze(mean(d3,3));
    end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
elseif MethodFlag ==1 | MethodFlag ==4
    
    if MethodFlag ==4
        
       
        data = [];
        data = Data{1};
        [chanNum,NumSamps,trialNum] = size(data);
        wname = ['rbio6.8'];%% Name of the wavelet
        
        if fs <= 1024 & fs > 512
            lv = 10;
        elseif fs <= 512 & fs > 256
            lv = 9;
        elseif 128 < fs & fs <= 256
            lv = 8;
        end
        
        kp = [2 3 4 5 6]; %% Reconstruction and output the result
        timePstart = round((0-timeStart)/(1000/fs))+1;
        
        %%Frequency responses of wavelet filter
        Len=NumSamps;
        Dura = NumSamps;
        FFTLen=fs*10;
        freqRs=fs/FFTLen;
        freLow=fs/FFTLen;
        freHigh = 35;
        binLow=freLow/freqRs;
        binHigh=freHigh/freqRs;
        timeIndex=(1:(2*Len-1))*1000/fs;
        fIndex=freLow:freqRs:freHigh;
        sig=[zeros(Len-1,1);1; zeros(Len-1,1)];
        tIndex = linspace(-Dura,Dura,length(sig));
        %%%%%%%%%%%%%%%%%%%%%%% Wavelet filter
        WLDsig=f_filterWavelet(sig,lv,wname,kp);
        WLDsigFFT=fft(WLDsig,FFTLen);
        spec=abs(WLDsigFFT(binLow:binHigh,:));
        WaveletfreqResp=20*log10(spec/max(spec));
        Waveletphase = 2*pi*phase(WLDsigFFT(binLow:binHigh));
        
        figure(101);
        % set(gcf,'outerposition',get(0,'screensize'));
        subplot(2,1,1);
        set(gca,'fontsize',20);
        hold on;
        plot(fIndex,WaveletfreqResp,'k','linewidth',3);
        xlim([freLow,freHigh]);
        ylim([-100 20]);
        tN = ['Magnitude of frequency responses '];
        title(tN,'fontsize',16);
        xlabel('Frequency/Hz','fontsize',16);
        ylabel('Attenuation/dB','fontsize',16);
        legend(' Wavelet filter','location','Southwest')
        
        subplot(2,1,2);
        set(gca,'fontsize',20);
        hold on;
        plot(fIndex,Waveletphase,'k','linewidth',3);
        xlim([freLow,freHigh]);
        tN = ['Phase of frequency responses'];
        title(tN,'fontsize',16);
        xlabel('Frequency/Hz','fontsize',16);
        ylabel('Angle/degree','fontsize',16);
        %%
        stiNum = length(Data);
        Data_WF = [];
        for Numofsti = 1:stiNum
            
            %%load data of each subject under each condition
            d3 =[];
            data = [];
            data = Data{Numofsti};
            [chanNum,sampoints,trialNum] = size(data);
            for Numoftrial = 1:trialNum
                for chan = 1:chanNum
                    temp = squeeze(data(chan,:,Numoftrial))' ;
                    temp1 = f_filterWavelet(temp,lv,wname,kp);
                    temp1 = temp1 - mean(temp1(1:timePstart));
                    d3 (chan,:,Numoftrial) = temp1;
                    
                end
                
            end
            
            Data_WF{Numofsti} = d3;
        end
        
        Data = [];
        Data = Data_WF;
    end
    
    Numsti = length(Data);
    X = [];
    count1 = 0;
    count = 0;
    sti_trial_label =[];
    for Numofsti = 1:Numsti
        
        data = [];
        data = Data{Numofsti};
        
        count1= count1+1;
        %%%
        [chanNum,samPoints,trialNum] = size(data);
        sti_trial_label = [sti_trial_label;count1*ones(trialNum,1)];
        
        for Numoftrial = 1:trialNum
            count = count +1;
            X(:,:,count)  = squeeze(data(:,:,Numoftrial));
        end
        
        
    end
    
    %%
    [NumChans,NumSamps,Numtrials] = size(X);
    X = permute(X,[2 1 3]);
    %% grouping data into a matrixgroup_Index = ones(NumSubs,1);
    X= reshape(X,NumSamps,NumChans*Numtrials);
    timeIndex = linspace(timeStart,timeEnd,NumSamps);
    
    %%PCA
    [coef,score,lambda] = pca(X');
    ratio = f_explainedVariance(lambda);
    %%
    threshold = [99 95 90];
    for is = 1:length(threshold)
        [va idx] = find(ratio<threshold(is));
        thresholdcomponetsNum(is) = length(idx)+1;
    end
    %%
    for is = 1:length(lambda)
        ratio_sigle(is) = 100*lambda(is)./sum(lambda);
    end
    %%
    figure(100);
    set(gcf,'outerposition',get(0,'screensize'))
    subplot(2,2,1);
    set(gca,'fontsize',14)
    plot(lambda,'ko','linewidth',4)
    xlim([0.5 NumSamps+0.5])
    title('Magnitude of lambda')
    xlabel('Lambda #')
    ylim([-lambda(1) 1.5*lambda(1)])
    
    subplot(2,2,2);
    set(gca,'fontsize',14)
    plot(ratio,'k-.','linewidth',4)
    xlim([0.5 NumSamps+0.5])
    title('Explained variance of accumulated lambda(%)')
    xlabel('Accumulated lambda')
    ylim([0 120])
    
    subplot(2,2,3);
    set(gca,'fontsize',14)
    plot(lambda,'ko','linewidth',4)
    xlim([0.5 100+0.5])
    xlabel('Lambda #')
    ylim([-lambda(1) 1.5*lambda(1)])
    
    subplot(2,2,4);
    set(gca,'fontsize',14)
    plot(ratio,'k-.','linewidth',4)
    xlim([0.5 100+0.5])
    xlabel('Accumulated lambda')
    ylim([0 120])
    %%first components labmdaexp
    x = 1;
    y = ratio(1);
    y = roundn(y,-2);
    text(x+1,y-1,['(' num2str(x) ',' num2str(y) '%)'],'fontsize',16,'color','b');%%color  x,y label
    text(x,y,'0','color','r','fontsize',10);
    %%mark x y axis
    hold on;
    x1 = thresholdcomponetsNum(1);
    y1 = threshold(1);
    plot([x1 x1], [0 y1],'r','linewidth',1);%%mark x axis
    plot([0 x1], [y1 y1],'r','linewidth',1);%%mark y axis
    text(x1-5,y1+6,['(' num2str(x1) ',' num2str(y1) '%)'],'fontsize',16,'color','b');
    hold on;
    x2 = thresholdcomponetsNum(2);
    y2 = threshold(2);
    plot([x2 x2], [0 y2],'r','linewidth',1);%%mark x axis
    plot([0 x2], [y2 y2],'r','linewidth',1);%%mark y axis
    text(x2+1,y2-2,['(' num2str(x2) ',' num2str(y2) '%)'],'fontsize',16,'color','b');
    hold on;
    x3 = thresholdcomponetsNum(3);
    y3 = threshold(3);
    plot([x3 x3], [0 y3],'r','linewidth',1);%%mark x axis
    plot([0 x3], [y3 y3],'r','linewidth',1);%%mark y axis
    text(x3+1,y3-5,['(' num2str(x3) ',' num2str(y3) '%)'],'fontsize',16,'color','b');
    %%
    
    
   geometry    = { [2 1 2 1] [2 1 2 1]};
    uilist = { ...
        { 'Style', 'text', 'string', 'The number of reserved components', 'horizontalalignment', 'right','fontweight', 'bold'},...
        { 'Style', 'edit', 'string', '1' },{},{}...
        { 'Style', 'text', 'string', 'Lower edge for baseline correction', 'horizontalalignment', 'right','fontweight', 'bold'},...
        { 'Style', 'edit', 'string', timeStart },...
        { 'Style', 'text', 'string', 'Upper edge for baseline correction', 'horizontalalignment', 'right','fontweight', 'bold'},...
        { 'Style', 'edit', 'string', 0 }};
    
    [ results_R newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_form_stiname'');', 'Select the reserved components');
    R = str2num(results_R{1});
      
    baselineStart = str2num(results_R{2});
    baselineEnd = str2num(results_R{3});
    
    ratio_sigle_keep = ratio_sigle(1:R);
    
    
    V = coef(:,1:R);
    Z = score(:,1:R);
    %% rotation for blind source separation
    [translated_V,W] = rotatefactors(V, 'Method','promax','power',3,'Maxit',500);
    B = inv(W');
    Y = Z*W; %%% spatial components
    T = V*B;  %%% temporal components
    
    [peakValue,peakTime] = max(abs(T));
    baselinePstart = ceil((0-baselineStart)/(1000/fs))+1;
    baselinePend = ceil((0-baselineEnd)/(1000/fs))+1;
    
    for r = 1 :R
        temp = T(:,r);
        T (:,r) =  temp - mean(temp(baselinePend:baselinePstart));
        peak_T(r) = ceil((peakTime(r)-1)*(1000/fs)) + timeStart;
    end
    %%
    topo = [];
    topo = reshape(Y',R,NumChans,Numtrials);
    RHO = [];
    topo_av = [];
    for Numofsti =1:Numsti
        idx1 = find(sti_trial_label == Numofsti);
        topo_av(:,:,Numofsti) =  squeeze(mean(topo(:,:,idx1),3));
        for k = 1:R
            temp1 = corr(squeeze(topo(k,:,idx1)));
            topo_similarity{:,:,k,Numofsti} = temp1;
            RHO(k,Numofsti) = mean(temp1(:));
        end
    end
    rowNum = 3;
    columnNum = Numsti;
    
    rho = mean(RHO,2);
    [rho_ranked, idx] = sort(rho,'descend');
    for kk = 1:R
        k = idx(kk);
        topo_k = squeeze(topo_av(k,:,:));
        mV = max(abs(topo_k(:)));
        figure(k);
        set(gcf,'outerposition',get(0,'screensize'));
        %%plot temporal components
        subplot(rowNum,columnNum,[1:columnNum],'align')
        set(gca,'fontsize',14)
        plot(timeIndex,T(:,k),'k','linewidth',3)
        xlim([timeStart timeEnd])
        grid on
        xlabel('Time/ms')
        ylabel('Magnitude')
        title(['Comp #',int2str(k),'(Explained variance =',num2str(roundn(ratio_sigle_keep(k),-2)),'%, Peak Time = ',num2str(peak_T(k)),'ms)']);
        set(gca,'ydir','reverse');
        count = 0;
        for Numofsti = 1:Numsti
            count = count +1;
            %%plot spatial components
            subplot(rowNum,columnNum,columnNum + count,'align')
            set(gca,'fontsize',14)
            topoplot(squeeze(topo_av(k,:,Numofsti)),chanlocs,'maplimits',[-mV,mV]);
            
            tN = Stimulus_Name{Numofsti};
            
            title(tN,'fontsize',14);
            if columnNum + count  == 2*columnNum %%position of colorbar
                last_subplot = subplot(rowNum,columnNum,count+columnNum,'align');
                last_subplot_position = get(last_subplot,'position');
                colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
                set(last_subplot,'pos',last_subplot_position);
            end
            
            %%plot similarities of topographies acroos all trials
            subplot(rowNum,columnNum,2*columnNum+count,'align')
            set(gca,'fontsize',14)
            imagesc(squeeze(topo_similarity{:,:,k,Numofsti}))
            set(gca,'clim',[-1 1])
            if Numofsti ==1
                tN = strcat('Similarity#',num2str(roundn(rho_ranked(kk),-2)),32,Stimulus_Name{Numofsti});
            else
                tN = Stimulus_Name{Numofsti};
            end
            title(tN,'fontsize',14);
            
            
            if Numofsti == 1
                xlabel('Trial #')
                ylabel('Trial #')
            end
            
            if 2*columnNum+count  == 3*columnNum
                last_subplot = subplot(rowNum,columnNum,2*columnNum+count,'align');
                last_subplot_position = get(last_subplot,'position');
                colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
                set(last_subplot,'pos',last_subplot_position);
            end
            
        end
    end
    
    msgbox('If you want to reset orders of selected components,Please press any key!!!')
    pause;
    
    
    geometry    = { [2 1]};
    uilist = { ...
        { 'Style', 'text', 'string', 'The orders of the selected components', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '1' }};
    
    [ results_K newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_form_stiname'');', 'Select the extracted components of interest');
    selectedComponentNumbers = str2num(results_K{1});
    
    temp= [];
    E = T(:,selectedComponentNumbers)*Y(:,selectedComponentNumbers)'; %% back-projection
    temp = reshape(E,NumSamps,NumChans,Numtrials);
    
    D= [];
    count1=0;
    for Numofsti =1:Numsti
        idx1 = find(sti_trial_label == Numofsti);
        D(:,:,Numofsti) =  squeeze(mean(temp(:,:,idx1),3));
    end
    %%% store data of each subject
    D = permute(D,[2 1 3]);
    
end

%% select electrodes
promptstr    = { strvcat('Select interested electrode(s) ([]=all)')};
cbchanlocs = ['if isempty(chanlocs) ' ...
    '   errordlg2(''No chanlocs field'');' ...
    'else' ...
    '   tmpevent = chanlocs;' ...
    '   if isnumeric(chanlocs(1).labels),' ...
    '        [tmps,tmpstr] = pop_chansel(unique([ tmpevent.labels ]));' ...
    '   else,' ...
    '        [tmps,tmpstr] = pop_chansel(unique({ tmpevent.labels }));' ...
    '   end;' ...
    '   if ~isempty(tmps)' ...
    '       set(findobj(''parent'', gcbf, ''tag'', ''events''), ''string'', tmpstr);' ...
    '   end;' ...
    'end;' ...
    'clear tmps tmpevent tmpv tmpstr tmpfieldnames;' ];

geometry = { [2 1 0.5] [5 0.85]};
uilist = { { 'style' 'text'       'string' 'Select Interest Electrode(s) ([]=all))' } ...
    { 'style' 'edit'       'string' '' 'tag' 'events' } ...
    { 'style' 'pushbutton' 'string' '...' 'callback' cbchanlocs },...
    { 'Style', 'text', 'string', 'Averaged waveforms of selected channels (1.Yes;2.No)?', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '1' }};
result1 = inputgui( geometry, uilist, 'pophelp(''pop_chansel'')', 'Select interested electrode(s)');

Waveform_Flag= str2num(result1{2});
if strcmp(result1{1}, '')
    ChansOfInterestNumbers  = [1:length(chanlocs)];
else
    interestchanName =  regexp(result1{1},'\s+','split');
    
    %% check input interest electrodes name(s) right or not
    count = 0;
    ChansOfInterestNumbers = [];
    for chanSelected = 1:length(interestchanName)
        for chan = 1:length(chanlocs)
            code = strcmp(chanlocs(chan).labels,interestchanName{chanSelected});
            if code == 1
                count =  count +1;
                ChansOfInterestNumbers(count) = chan;
            end
        end
    end
    if length(interestchanName) > length(ChansOfInterestNumbers)
        ChansOfInterestNumbers(length(ChansOfInterestNumbers)+1:length(interestchanName))=0;
    end
    min_Num = min(ChansOfInterestNumbers(:));
    if min_Num == 0
        errordlg2('Please Input Correct Electrode(s) Name')
    end
    
end

if  length(interestchanName) > 1
    filechanName = char(interestchanName{1});
    for Numofchannel = 1:length(interestchanName) - 1
        filechanName = char(strcat(filechanName,'-',interestchanName{Numofchannel+1}));
    end
else
    filechanName = char(interestchanName);
end

tIndex = linspace(timeStart,timeEnd,size(D,2));

if Waveform_Flag==1
    %%%%%%%%%%%%%%Plot the grand averaged waveforms at the typical electrodes
    D_av_w = squeeze(mean(D(ChansOfInterestNumbers,:,:),1));
    y_MIN = 1.1*min(D_av_w(:));
    y_MAX = 1.1*max(D_av_w(:));
    %%%Plot waveform
    figure;
    set(gcf,'outerposition',get(0,'screensize'))
    %     subplot(rowNum,columnNum,count);
    set(gca,'fontsize',16,'FontWeight','bold');
    plot(tIndex, D_av_w,'linewidth',2)
    
    set(gca,'ydir','reverse','FontWeight','bold');
    xlim([timeStart,timeEnd]);
    ylim([y_MIN,y_MAX]);
    hold on;
    xlabel(['Time/ms'],'fontsize',16);
    ylabel(['Amplitude/\muV'],'fontsize',16);
    legend(Stimulus_Name,'location','best')
    tN = strcat('Waveform at',32,filechanName);
    title(tN,'fontsize',16);
else
    
    
    temp = squeeze(D(ChansOfInterestNumbers,:,:));
    y_MIN = 1.1*min(temp(:));
    y_MAX = 1.1*max(temp(:));
    
    
    for Numofchan = 1:length(ChansOfInterestNumbers)
        
        D_av_w  =squeeze(D(ChansOfInterestNumbers(Numofchan),:,:));
        %%
        
        figure;
        set(gcf,'outerposition',get(0,'screensize'))
        set(gca,'fontsize',16,'FontWeight','bold');
        
        plot(tIndex, D_av_w,'linewidth',2)
        hold on;
        set(gca,'ydir','reverse','FontWeight','bold');
        xlim([timeStart,timeEnd]);
        ylim([y_MIN,y_MAX]);
        hold on;
        xlabel(['Time/ms'],'fontsize',16);
        ylabel(['Amplitude/\muV'],'fontsize',16);
        legend(Stimulus_Name,'location','best')
        tN = strcat('Grand Averaged Waveform at',32,interestchanName{Numofchan});
        title(tN,'fontsize',16);
    end
    
    
end
%%topography
%%%%%%%%%%%%%Determining the time-window for ERP of interest.
geometry    = { [2 1 2 1],[5 1],[2 1 2 1]};
uilist = { ...
    { 'Style', 'text', 'string', 'Edege of ERP start', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '190' }, ...
    ...
    { 'Style', 'text', 'string', 'Edge of ERP end', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'edit', 'string', '290' },...
    { 'Style', 'text', 'string', 'Meansurement method (1.Mean; 2.Peak)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '1' }, ...
    { 'Style', 'text', 'string', 'Row Number (Plot figure)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '' }, ...
    ...
    { 'Style', 'text', 'string', 'Column Number (Plot figure)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'edit', 'string', '' }};

[ results_TW newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_form_stiname'');', 'Time-window');

ERPStart = str2num(results_TW{1});
ERPEnd = str2num(results_TW{2});
MeanFlag = str2num(results_TW{3});
rowNum = str2num(results_TW{4});
columnNum = str2num(results_TW{5});


ERPSampointStart = round((ERPStart - timeStart)/(1000/fs)) + 1 ;
ERPSampointEnd = round((ERPEnd - timeStart)/(1000/fs)) + 1 ;

TOPO = [];
if MeanFlag ==1
    TOPO = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:),2));%% mean measurement
else
    %% peak measurement
    
    for stimulusNumFactorOne = 1:size(D,3)
        for chanNum = 1:size(D,1)
            temp = squeeze(D(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne))';
            [mV  Idx] = max(abs(temp(:)));
            TOPO(chanNum,stimulusNumFactorOne)  = squeeze(D(chanNum,ERPSampointStart+Idx,stimulusNumFactorOne));
        end
    end
end
mv_max = max(TOPO(:));
mv_min = min(TOPO(:));

figure;
set(gcf,'outerposition',get(0,'screensize'));
for sti = 1:size(TOPO,2)
    subplot(rowNum,columnNum,sti,'align')
    set(gca,'fontsize',16,'FontWeight','bold')
    topoplot(squeeze(TOPO(:,sti)),chanlocs,'maplimits',[mv_min,mv_max]);
    
    tN = [Stimulus_Name{sti}];
    title(tN,'fontsize',16);
    hold on;
    
    
    if sti == size(TOPO,2)
        last_subplot = subplot(rowNum,columnNum,sti,'align');
        last_subplot_position = get(last_subplot,'position');
        colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
        set(last_subplot,'pos',last_subplot_position);
    end
    
    colormap('jet');
end


geometry    = { [5 1]};
uilist = { ...
    { 'Style', 'text', 'string', 'Save the current data as .mat (1.Yes; 2.No)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '2' }};
[ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_form_stiname'');', '');
codeFlag  = str2num(results{1});
if codeFlag ==1
    for ii =  1:100
        [filename, pathname, filterindex] = uiputfile({'*.mat','MAT-files (*.mat)'},'Save as .mat');
        fn= char(strcat(pathname, filename));
        
        if filterindex == 0
            errordlg2('Please give a name for the saved signal');
            return;
            
        else
            save(fn,'D', '-v7.3'); 
            break;
        end
    end
end

uiwait(msgbox('The program ends'));
%% program end
toc
