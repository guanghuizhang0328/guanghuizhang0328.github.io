%%% Plot boxes of mean-peak amplitudes for different techniques

%%% Please uses the output from:
%%% m_Filter_data_by_wavelet_filter.m;m_Conventional_time_domain_analysis_for_filtered_data;m_single_trials_Group_PCA_Rotation_Projection_filtered_data
%%% m_Averaged_Group_PCA_Rotation__Projection_filtered_data;m_individual_analysis_PCA_Rotation_single_trial_filtered_data;


%%% In order to run this code, please install EEGLAB toolboxes. It can be downloaded from http://sccn.ucsd.edu/eeglab/
%%% This code was written by GuangHui Zhang in Match 2021, JYU
%%% Faculty of Information Technology, University of Jyv�skyl�
%%% Address: Seminaarinkatu 15,PO Box 35, FI-40014 University of Jyv�skyl�,Jyv�skyl�, FINLAND
%%% E-mails: zhang.guanghui@foxmail.com


%%% When using this code, please cite the following articles:
%%% 1. Fengyu Cong, Yixiang Huang, Igor Kalyakin, Hong Li, Tiina Huttunen-Scott, Heikki Lyytinen, Tapani Ristaniemi,
%%% Frequency Response based Wavelet Decomposition to Extract Children's Mismatch Negativity Elicited by Uninterrupted Sound,
%%% Journal of Medical and Biological Engineering, 2012, 32(3): 205-214, DOI: 10.5405/jmbe.908
%%% 2. Guanghui Zhang, Xueyan Li, and Fengyu Cong. Objective Extraction of Evoked Event-related Oscillation from Time-frequency Representation of Event-related Potentials.
%%% Neural Plasticity. DOI:10.1155/2020/8841354
%%% 3. Lu, Y., Luo, Y., Lei, Y., Jaquess, K. J., Zhou, C., & Li, H. (2016). Decomposing valence intensity effects in disgusting and fearful stimuli: an event-related potential study.
%%% Social neuroscience, 11(6), 618-626. doi:https://doi.org/10.1080/17470919.2015.1120238








clear
clc
close all
%%
tic


%Location of the main study directory
%This method of specifying the study directory only works if you run the script;
%for running individual lines of code, replace the study directory with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment
Subject_file_Path = fileparts(fileparts(mfilename('fullpath')));


%Location of the folder that contains this script and any associated processing files
%This method of specifying the current file path only works if you run the script;
%For running individual lines of code, replace the current file path with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment\Codes_for_EEG_ERP_Processing
Current_File_Path = fileparts(mfilename('fullpath'));

%% add function into path
Currentpath1 = char(strcat(Current_File_Path,filesep,'functions',filesep));
addpath(genpath(Currentpath1));






%% load datasets for different techniques
X(:,:,:,:,1) = importdata('X_WF_all_trials.mat');
X(:,:,:,:,2) = importdata('X_individual_wavelet_PCA_single_trial.mat');
X(:,:,:,:,3) = importdata('PCA_average_group_level_rotation_R_15_K_2  4  9.mat');
X(:,:,:,:,4) = importdata('PCA_single_trial_group_level_rotation_R_31_K_3  10  12.mat');

fs = 1000;
timeStart = -200;
timeEnd = 900;
ERPStart  = 190;
ERPEnd = 290;
load chanlocs;

Sti_names = {'MD','MF','ED','EF','DN','DF'};
%%
ERPSampointStart = round((ERPStart - timeStart)/(1000/fs)) + 1 ;
ERPSampointEnd = round((ERPEnd - timeStart)/(1000/fs)) + 1 ;
[NumChans,NumSamps,NumSti,NumSubs,Numconds] = size(X);
tIndex = linspace(timeStart,timeEnd,NumSamps);

chanInterestNum = [3 4 5 10 11 15];

TOPO_mean = squeeze(mean(X(:,ERPSampointStart:ERPSampointEnd,:,:,:),2));
for Numofcondition = 1:Numconds
    for subNum = 1:NumSubs
        for stimulusNumFactorOne = 1:NumSti
            for chanNum = 1:NumChans
                temp = squeeze(X(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum,Numofcondition))';
                [mV  Idx] = max(abs(temp(:)));
                TOPO_peak(chanNum,stimulusNumFactorOne,subNum,Numofcondition)  = squeeze(X(chanNum,ERPSampointStart+Idx,stimulusNumFactorOne,subNum,Numofcondition));
            end
        end
    end
    
end


TOPO_mean_av = squeeze(mean(TOPO_mean(chanInterestNum,:,:,:),1));
TOPO_peak_av = squeeze(mean(TOPO_peak(chanInterestNum,:,:,:),1));

%%plot box
XTickLabels= {'MD','MF','ED','EF','DN','DF'};

temp  =TOPO_mean_av(:);
shiftxs= temp -min(temp(:));
shiftxs=shiftxs/max(shiftxs)*2-1;

xs=.4/4; %the best half width for a 'group or catagory' is .4 and there are 2 subgroups (male/female)
width=xs*.4;% width of each box with a small gap between subgroups

subplot(2,1,1);
set(gcf,'outerposition',get(0,'screensize'));
hold on;
set(gca,'fontsize',14);
hold on;
for Numofsti  =1:NumSti
    Sti2 = whisker_boxplot(Numofsti-0.6*xs,squeeze(TOPO_mean_av(Numofsti,:,2)),[1 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti3 = whisker_boxplot(Numofsti+0.6*xs,squeeze(TOPO_mean_av(Numofsti,:,3)),[0 0 1],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti1 = whisker_boxplot(Numofsti-1.8*xs,squeeze(TOPO_mean_av(Numofsti,:,1)),[0 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti4 = whisker_boxplot(Numofsti+1.8*xs,squeeze(TOPO_mean_av(Numofsti,:,4)),[0 1 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    set(gca,'XTick',1:length(XTickLabels),'XTickLabels',XTickLabels)
    
end
legend([Sti1(1) Sti2(1) Sti3(1) Sti4(1)],{'WF','iPCA','aPCA','sPCA'});
ylim([-10 3]);
xlim([0.5 6.5]);
tN = strcat('Mean measurement: Amplitudes for different conditions');
title(tN,'fontsize',14);
%%peak measurement
XTickLabels= {'MD','MF','ED','EF','DN','DF'};
 ylabel(['Amplitude/\muV'],'fontsize',16);
temp  =TOPO_peak_av(:);
shiftxs= temp -min(temp(:));
shiftxs=shiftxs/max(shiftxs)*2-1;

xs=.4/4; %the best half width for a 'group or catagory' is .4 and there are 2 subgroups (male/female)
width=xs*.4;% width of each box with a small gap between subgroups

subplot(2,1,2);
set(gcf,'outerposition',get(0,'screensize'));
hold on;
set(gca,'fontsize',14);
hold on;
for Numofsti  =1:NumSti
    Sti2 = whisker_boxplot(Numofsti-0.6*xs,squeeze(TOPO_peak_av(Numofsti,:,2)),[1 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti3 = whisker_boxplot(Numofsti+0.6*xs,squeeze(TOPO_peak_av(Numofsti,:,3)),[0 0 1],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti1 = whisker_boxplot(Numofsti-1.8*xs,squeeze(TOPO_peak_av(Numofsti,:,1)),[ 0 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti4 = whisker_boxplot(Numofsti+1.8*xs,squeeze(TOPO_peak_av(Numofsti,:,4)),[0 1 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    set(gca,'XTick',1:length(XTickLabels),'XTickLabels',XTickLabels)
    
end
% legend([Sti1(1) Sti2(1) Sti3(1) Sti4(1)],{'WF','iPCA','aPCA','sPCA'}); [1 0.5 1]
ylim([-11 5]);
xlim([0.5 6.5]);
tN = strcat('Peak measurement: Amplitudes for different conditions');
title(tN,'fontsize',14);

%%
toc