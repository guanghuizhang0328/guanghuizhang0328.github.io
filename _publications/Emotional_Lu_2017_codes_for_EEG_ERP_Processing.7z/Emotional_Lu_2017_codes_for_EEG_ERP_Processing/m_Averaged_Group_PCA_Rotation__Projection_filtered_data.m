%%% Using PCA to extract ERPs of interest from the averaged ERP datasets of all subjects simultaneously and analysing back-projection:
%%%     1.Estimate the number of sources by using cumulative explained variance  method
%%%     2.Plot rotated temporal and spatial components
%%%     3.Select the componnets associated with N2 of interest.
%%%     4.Project the selected components to the electrode fields (i.e., in microvolts)
%%% Analysing back-projection of N2:
%%%     1.Plot grand waveforms at specific eletrodes
%%%     2.Plot grand topographies within predifined time-window for N2
%%%     3.Plot similarities of topographies across all subjects for N2
%%%     4.Calculate statistical analysis results (two-way ANOVA)

%%% Please uses the output from: m_Filter_data_by_wavelet_filter.m AND m_Conventional_time_domain_analysis_for_filtered_data
%%% In order to run this code, please install EEGLAB toolboxes. It can be downloaded from http://sccn.ucsd.edu/eeglab/
%%% This code was written by GuangHui Zhang in Match 2021, JYU
%%% Faculty of Information Technology, University of Jyv�skyl�
%%% Address: Seminaarinkatu 15,PO Box 35, FI-40014 University of Jyv�skyl�,Jyv�skyl�, FINLAND
%%% E-mails: zhang.guanghui@foxmail.com


%%% When using this code, please cite the following articles:
%%% 1. Fengyu Cong, Yixiang Huang, Igor Kalyakin, Hong Li, Tiina Huttunen-Scott, Heikki Lyytinen, Tapani Ristaniemi,
%%% Frequency Response based Wavelet Decomposition to Extract Children's Mismatch Negativity Elicited by Uninterrupted Sound,
%%% Journal of Medical and Biological Engineering, 2012, 32(3): 205-214, DOI: 10.5405/jmbe.908
%%% 2. Guanghui Zhang, Xueyan Li, and Fengyu Cong. Objective Extraction of Evoked Event-related Oscillation from Time-frequency Representation of Event-related Potentials.
%%% Neural Plasticity. DOI:10.1155/2020/8841354
%%% 3. Lu, Y., Luo, Y., Lei, Y., Jaquess, K. J., Zhou, C., & Li, H. (2016). Decomposing valence intensity effects in disgusting and fearful stimuli: an event-related potential study.
%%% Social neuroscience, 11(6), 618-626. doi:https://doi.org/10.1080/17470919.2015.1120238


clear
clc
close all
%%
tic
%Location of the main study directory
%This method of specifying the study directory only works if you run the script;
%for running individual lines of code, replace the study directory with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment
Subject_file_Path = fileparts(fileparts(mfilename('fullpath')));


%Location of the folder that contains this script and any associated processing files
%This method of specifying the current file path only works if you run the script;
%For running individual lines of code, replace the current file path with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment\Codes_for_EEG_ERP_Processing
Current_File_Path = fileparts(mfilename('fullpath'));

%List of subjects to process, based on the name of the folder that contains that subject's data
Subject_Name = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20'};

% List of stimulus for each subject to process separately, based on the name of the sub-folder that contains that subject's data
Stimulus_Name = {'MD','MF','ED','EF','ND','NF'};

%% add function into path
Currentpath1 = char(strcat(Current_File_Path,filesep,'functions',filesep));
addpath(genpath(Currentpath1));

%%Judging whether the averaged ERP data are generated or not
if exist('X_WF_all_trials.mat','file')==0.
hs = msgbox('Please, run:m_Filter_data_by_wavelet_filter.m', 'Error','warn');
ht = findobj(hs, 'Type', 'text');
set(ht, 'FontSize', 20, 'Unit', 'normal');
set(hs,'Position',[500 400 550 100])
end

%%% Judging whether tmeplate is generated or not
if exist('Topo_190_290_mean_wavelet.mat','file')== 0
hs = msgbox('Please, run:m_Conventional_time_domain_analysis_for_filtered_data.m', 'Error','warn');
ht = findobj(hs, 'Type', 'text');
set(ht, 'FontSize', 20, 'Unit', 'normal');
set(hs,'Position',[500 400 750 100])
end



%%
ERPStart  =190;%% The lower interval of time-window for N2
ERPEnd = 290; %% The upper interval of time-window for N2
ChansOfInterestNames = {'FC3','FCz','FC4','C3','Cz','C4'};%% Names of electrodes of interest


load chanlocs;
timeStart = -200;
timeEnd = 900;
fs = 1000;

TOPO_original = importdata('Topo_190_290_mean_wavelet.mat');%% load template for help to select components of interest

ERPSampointStart = round((ERPStart - timeStart)/(1000/fs)) + 1;
ERPSampointEnd = round((ERPEnd - timeStart)/(1000/fs)) + 1;
%%load data
X = [];
X = importdata('X_WF_all_trials.mat');

[NumChans,NumSamps,Numsti,NumSubs] = size(X);
group_Index = ones(NumSubs,1);
NumGroups = max(group_Index);
X = permute(X,[2 1 3 4]);
%% grouping data into a matrix
X= reshape(X,NumSamps,NumChans*Numsti*NumSubs);
timeIndex = linspace(timeStart,timeEnd,NumSamps);

%%PCA
[coef,score,lambda] = pca(X');
ratio = f_explainedVariance(lambda);

threshold = [99 95 90];
for is = 1:length(threshold)
    [va idx] = find(ratio<threshold(is));
    thresholdcomponetsNum(is) = length(idx)+1;
end
%%
for is = 1:length(lambda)
    ratio_sigle(is) = 100*lambda(is)./sum(lambda);
end
%%
figure(100)
set(gcf,'outerposition',get(0,'screensize'))
subplot(2,2,1);
set(gca,'fontsize',14)
plot(lambda,'ko','linewidth',4)
xlim([0.5 NumSamps+0.5])
title('Magnitude of lambda')
xlabel('Lambda #')
ylim([-lambda(1) 1.5*lambda(1)])

subplot(2,2,2);
set(gca,'fontsize',14)
plot(ratio,'k-.','linewidth',4)
xlim([0.5 NumSamps+0.5])
title('Explained variance of accumulated lambda(%)')
xlabel('Accumulated lambda')
ylim([0 120])

subplot(2,2,3);
set(gca,'fontsize',14)
plot(lambda,'ko','linewidth',4)
xlim([0.5 70+0.5])
xlabel('Lambda #')
ylim([-lambda(1) 1.5*lambda(1)])

subplot(2,2,4);
set(gca,'fontsize',14)
plot(ratio,'k-.','linewidth',4)
xlim([0.5 100+0.5])
xlabel('Accumulated lambda')
ylim([0 120])
%%first components labmdaexp
x = 1;
y = ratio(1);
y = roundn(y,-2);
text(x+1,y-1,['(' num2str(x) ',' num2str(y) '%)'],'fontsize',16,'color','b');%%color  x,y label
text(x,y,'0','color','r','fontsize',10);
%%mark x y axis
hold on;
x1 = thresholdcomponetsNum(1);
y1 = threshold(1);
plot([x1 x1], [0 y1],'r','linewidth',1);%%mark x axis
plot([0 x1], [y1 y1],'r','linewidth',1);%%mark y axis
text(x1-5,y1+6,['(' num2str(x1) ',' num2str(y1) '%)'],'fontsize',16,'color','b');
hold on;
x2 = thresholdcomponetsNum(2);
y2 = threshold(2);
plot([x2 x2], [0 y2],'r','linewidth',1);%%mark x axis
plot([0 x2], [y2 y2],'r','linewidth',1);%%mark y axis
text(x2+1,y2-2,['(' num2str(x2) ',' num2str(y2) '%)'],'fontsize',16,'color','b');
hold on;
x3 = thresholdcomponetsNum(3);
y3 = threshold(3);
plot([x3 x3], [0 y3],'r','linewidth',1);%%mark x axis
plot([0 x3], [y3 y3],'r','linewidth',1);%%mark y axis
text(x3+1,y3-5,['(' num2str(x3) ',' num2str(y3) '%)'],'fontsize',16,'color','b');
%%
prompt = {'The number of estimated sources:'};
dlg_title = 'Input';
num_lines = 1;
def = {'15'};
answer = inputdlg(prompt,dlg_title,num_lines,def);

R  =str2num(answer{1});

for is = 1:length(lambda)
    ratio_sigle(is) = 100*lambda(is)./sum(lambda);
end
ratio_sigle_keep = ratio_sigle(1:R);

%% rotation
V = coef(:,1:R);
Z = score(:,1:R);
%% rotation for blind source separation
[translated_V,W] = rotatefactors(V, 'Method','promax','power',3,'Maxit',500);
B = inv(W');
Y = Z*W; %%% spatial components
T = V*B;  %%% temporal components

[peakValue,peakTime] = max(abs(T));
timePstart = ceil((0-timeStart)/(1000/fs))+1;
for r = 1 :R
    temp = T(:,r);
    T (:,r) =  temp - mean(temp(1:timePstart));
    peak_T(r) = round((peakTime(r)-1)*(1000/fs)) + timeStart;
end
%%
topo = reshape(Y',R,NumChans,Numsti,NumSubs);
topo_similarity_AV =[];

for Numofgroup = 1:NumGroups
    Index = find(group_Index==Numofgroup);
    for Numofsti =1:Numsti
        temp= [];
        temp = squeeze(topo(:,:,Numofsti,Index));
        topo_av(:,:,Numofsti,Numofgroup) =  squeeze(mean(temp,3));
        for k = 1:R
            temp1 = corr(squeeze(topo(k,:,Numofsti,Index)));
            topo_similarity{:,:,k,Numofsti,Numofgroup} = temp1;
            RHO(k,Numofsti,Numofgroup) = mean(temp1(:));
        end
    end
end
rho = mean(RHO,2);
[rho_ranked, idx] = sort(rho,'descend');
%% Explained variance of each component of keep componets and Correlation Coefficient between spatial components
Sti_names = {'MD','MF','ED','EF','DN','DF'};
%%  plot results of temporal components and spatial components

rowNum = 3;
columnNum = 6;

count_rr = ceil(rowNum/2)*columnNum+ 1;
for kk = 1:R
    k = idx(kk);
    topo_k = squeeze(topo_av(k,:,:,:));
    
    topo_corr = corrcoef(TOPO_original,topo_k);%% calculate the correlation coefficient between spatial component and template
    
    mV = max(abs(topo_k(:)));
    figure(k)
    set(gcf,'outerposition',get(0,'screensize'))
    subplot(rowNum,columnNum,[1:columnNum],'align');
    hold on;
    set(gca,'fontsize',14);
    hold on;
    plot(timeIndex,T(:,k),'k','linewidth',3);
    xlim([timeStart timeEnd])
    grid on
    xlabel('Time/ms')
    ylabel('Magnitude')
    title(['Comp #',int2str(k),'(Explained variance:',num2str(roundn(ratio_sigle_keep(k),-2)),'%, Peak Time:',num2str(peak_T(k)),'ms)']);
    set(gca,'ydir','reverse');
    count = 0;
    for Numofgroup =1:NumGroups
        for Numofsti = 1:Numsti
            count = count +1;
            subplot(rowNum,columnNum,columnNum + count,'align');
            hold on;
            set(gca,'fontsize',14);
            hold on;
            topoplot(squeeze(topo_av(k,:,Numofsti,Numofgroup)),chanlocs,'maplimits',[-mV,mV]);
            
            if columnNum + count  == 2*columnNum
                last_subplot = subplot(rowNum,columnNum,count+columnNum,'align');
                last_subplot_position = get(last_subplot,'position');
                colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
                set(last_subplot,'pos',last_subplot_position);
            end
            
            if Numofsti == 1
                tN = strcat('CC#',num2str(roundn(abs(topo_corr(1,2)),-2)),32,'-',Sti_names{Numofsti});
            else
                tN = Sti_names{count};
            end
            title(tN,'fontsize',14);
            set(gca,'clim',[-mV mV])
            subplot(rowNum,columnNum,ceil(rowNum/2)*columnNum+count,'align')
            set(gca,'fontsize',14);
            hold on;
            imagesc(squeeze(topo_similarity{:,:,k,Numofsti,Numofgroup}))
            set(gca,'clim',[-1 1])
            xlim([0.5,NumSubs+0.5]);
            ylim([0.5,NumSubs+0.5]);
            if ceil(rowNum/2)*columnNum+count  == 3*columnNum
                last_subplot = subplot(rowNum,columnNum,ceil(rowNum/2)*columnNum+count,'align');
                last_subplot_position = get(last_subplot,'position');
                colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
                set(last_subplot,'pos',last_subplot_position);
            end
            if ceil(rowNum/2)*columnNum +count == count_rr
                xlabel('Subject #')
                ylabel('Subject #')
            end
            
        end
    end
end
%%
for is  = 1:100
    prompt = {'The orders  of the desired components:'};
    dlg_title = 'Input';
    num_lines = 1;
    def = {'2 4 9'};
    answer = inputdlg(prompt,dlg_title,num_lines,def);
    selectedComponentNumbers = str2num(answer{1});
    min_Num = min(selectedComponentNumbers);
    if min_Num == 0
        uiwait(msgbox('Input incorrect number'));
    else
        break;
    end
end
close all;

temp= [];
E = T(:,selectedComponentNumbers)*Y(:,selectedComponentNumbers)';
temp = reshape(E,NumSamps,NumChans,Numsti,NumSubs);
D = permute(temp,[2 1 3 4]);

fileNameNew = ['PCA_average_group_level_rotation_R_',num2str(R),'_K_',num2str(selectedComponentNumbers)];
save(fileNameNew,'D','-v7.3');


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Analysing the back-projection for aPCA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[NumChans,NumSamps,NumSti,NumSubs] = size(D);
tIndex = linspace(timeStart,timeEnd,NumSamps);

Group_Idx= ones(NumSubs,1);
NumGroups = max(Group_Idx);

%%Find the orders of the desired electrodes
ChansOfInterestNumbers = [];
count = 0;
for chanSelected = 1:length(ChansOfInterestNames)
    for chan = 1:NumChans
        code = strcmp(chanlocs(chan).labels,ChansOfInterestNames{chanSelected});
        if code == 1
            count =  count +1;
            ChansOfInterestNumbers(count) = chan;
        end
    end
end

if  length(ChansOfInterestNames) > 1
    filechanName = char(ChansOfInterestNames{1});
    for Numofchannel = 1:length(ChansOfInterestNames) - 1
        filechanName = char(strcat(filechanName,',',32,ChansOfInterestNames{Numofchannel+1}));
    end
else
    filechanName = char(ChansOfInterestNames);
end
%% measurement meathods:mean value/peak value
TOPO = [];
TOPO = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:,:),2));

TOPO_peak = [];
for subNum = 1:NumSubs
    for stimulusNumFactorOne = 1:NumSti
        for chanNum = 1:NumChans
            temp = squeeze(D(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum))';
            [mV  Idx] = max(abs(temp(:)));
            TOPO_peak(chanNum,stimulusNumFactorOne,subNum)  = squeeze(D(chanNum,ERPSampointStart+Idx,stimulusNumFactorOne,subNum));
        end
    end
end

%% calculating the topography of the data
topo_similarity = [];
for groupNum = 1:NumGroups
    idx1 = find(Group_Idx == groupNum);
    D_av(:,:,:,groupNum) = squeeze(mean(D(:,:,:,idx1),4));
    topo_GA(:,:,groupNum) = squeeze(mean(TOPO(:,:,idx1),3));
    for sti = 1:NumSti
        temp = corrcoef(squeeze(TOPO(:,sti,idx1)));
        topo_similarity(:,:,sti,groupNum) = temp;
    end
end
%% the Grand waveform(s) at interest electrode(s)
Stimulus_Name = {'MD','MF','ED','EF','ND','NF'};
mv_max = max(topo_GA(:));
mv_min = min(topo_GA(:));


D_av_w = squeeze(mean(D_av(ChansOfInterestNumbers,:,:,:),1));
y_MIN = 1.1*min(D_av_w(:));
y_MAX = 1.1*max(D_av_w(:));
y_max = 1.5*max(abs(D_av_w(:)));
%%


figure(1);
set(gcf,'outerposition',get(0,'screensize'))
count = 0;
count_s = 0;
for groupNum = 1:NumGroups
    count = count  + 1;
    %     subplot(rowNum,columnNum,count);
    set(gca,'fontsize',16,'FontWeight','bold');
    for sti = 1:NumSti
        count_s= count_s+1;
        switch count_s
            case 1
                plot(tIndex, D_av_w(:,sti,groupNum),'k','linewidth',2)
                hold on;
            case 2
                plot(tIndex, D_av_w(:,sti,groupNum),'k--','linewidth',2)
                hold on;
            case 3
                plot(tIndex, D_av_w(:,sti,groupNum),'r','linewidth',4)
                hold on;
            case 4
                plot(tIndex, D_av_w(:,sti,groupNum),'r--','linewidth',4)
                hold on;
            case 5
                plot(tIndex, D_av_w(:,sti,groupNum),'b','linewidth',2)
                hold on;
            case 6
                plot(tIndex, D_av_w(:,sti,groupNum),'b-.','linewidth',2)
                hold on;
        end
        set(gca,'ydir','reverse','FontWeight','bold');
        xlim([timeStart,timeEnd]);
        ylim([y_MIN,y_MAX]);
        
        hold on;
    end
    
    xlabel(['Time/ms'],'fontsize',16);
    ylabel(['Amplitude/\muV'],'fontsize',16);
    legend(Stimulus_Name,'location','best')
    tN = strcat('aPCA-grand Averaged Waveform at',32,filechanName);
    title(tN,'fontsize',16);
end

% figureName = char(strcat('aPCA_GA_Waveform_',num2str(ERPStart),'_',num2str(ERPEnd)),Measurment_Name{measureFlag},'.png');
% saveas(figure(1),figureName,'png');
% saveas(figure(1),figureName,'fig');

%%  Plot grand averaged topographies for different experimental conditions
rowNum =2;
columnNum = 3;
figure(2)
set(gcf,'outerposition',get(0,'screensize'));
count = 0;
for groupNum = 1:NumGroups
    for sti = 1:NumSti/2
        count = count +1;
        subplot(rowNum,columnNum,count,'align')
        set(gca,'fontsize',16,'FontWeight','bold')
        topoplot(squeeze(topo_GA(:,2*(sti-1)+1,groupNum)),chanlocs,'maplimits',[mv_min,mv_max]);
        if count == 1
            tN = strcat('aPCA-Grand averaged topography-',Stimulus_Name{2*(sti-1)+1});
        else
            tN = [Stimulus_Name{2*(sti-1)+1}];
        end
        
        title(tN,'fontsize',16);
        hold on;
        
        
        subplot(rowNum,columnNum,count+columnNum,'align')
        set(gca,'fontsize',16,'FontWeight','bold')
        topoplot(squeeze(topo_GA(:,2*sti,groupNum)),chanlocs,'maplimits',[mv_min,mv_max]);
        
        tN = strcat(Stimulus_Name{2*sti});
        title(tN,'fontsize',16);
        hold on;
        
        if count == 1
            xlabel('Subject #')
            ylabel('Subject #')
        elseif count*rowNum == NumSti*NumGroups
            last_subplot = subplot(rowNum,columnNum,count+columnNum,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
            set(last_subplot,'pos',last_subplot_position);
        end
        
        colormap('jet');
    end
end

% figureName = char(strcat('aPCA_GA_topo_',num2str(ERPStart),'_',num2str(ERPEnd),32,Measurment_Name{measureFlag}));
% saveas(figure(2),figureName,'png');
% saveas(figure(2),figureName,'fig');
%%  the correlation coefficient of topography between subjects
figure(3)
set(gcf,'outerposition',get(0,'screensize'));
count = 0;
for groupNum = 1:NumGroups
    for sti = 1:NumSti/2
        count = count +1;
        subplot(rowNum,columnNum,count,'align')
        set(gca,'fontsize',16,'FontWeight','bold');
        hold on;
        imagesc(squeeze(topo_similarity(:,:,2*(sti-1)+1,groupNum)))
        set(gca,'clim',[-1 1]);
        if count == 1
            tN = strcat('aPCA-Similarities of topograpgies over all subjects-',Stimulus_Name{2*(sti-1)+1});
        else
            tN = [Stimulus_Name{2*(sti-1)+1}];
        end
        xlim([0.5,NumSubs+0.5]);
        ylim([0.5,NumSubs+0.5]);
        
        title(tN,'fontsize',16);
        hold on;
        subplot(rowNum,columnNum,count+columnNum,'align')
        set(gca,'fontsize',16,'FontWeight','bold');
        hold on;
        imagesc(squeeze(topo_similarity(:,:,2*sti,groupNum)))
        set(gca,'clim',[-1 1]);
        tN = strcat(Stimulus_Name{2*sti});
        title(tN,'fontsize',16);
        hold on;
        xlim([0.5,NumSubs+0.5]);
        ylim([0.5,NumSubs+0.5]);
        
        if count == 1
            xlabel('Subject #')
            ylabel('Subject #')
        elseif count*rowNum == NumSti*NumGroups
            last_subplot = subplot(rowNum,columnNum,count+columnNum,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
            set(last_subplot,'pos',last_subplot_position);
        end
        
        colormap('jet');
    end
end
% figureName = char(strcat('aPCA_GA_smilarities_',num2str(ERPStart),'_',num2str(ERPEnd),32,Measurment_Name{measureFlag}));
% saveas(figure(3),figureName,'png');
% saveas(figure(3),figureName,'fig');


%%%%%%%%%%%%%%MEAN MEASUREMENT%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
measureFlag = 1;%% Choose method for measuring ampltideus of N2 under different experimental conditions (1.Mean measurement; 2.Peak measurement)
Measurment_Name = {'Mean','Peak'};
topo_box = squeeze(mean(TOPO(ChansOfInterestNumbers,:,:),1))';
%%box plot
figure;
set(gcf,'outerposition',get(0,'screensize'));
hold on;
set(gca,'fontsize',14);
hold on;

temp1  =topo_box(:);
shiftxs= temp1 -min(temp1(:));
shiftxs=shiftxs/max(shiftxs)*2-1;

xs=.4/2; %the best half width for a 'group or catagory' is .4 and there are 2 subgroups (male/female)
width=xs*.4;% width of each box with a small gap between subgroups
XTickLabels= {'Extreme', 'Moderate','Neutral'};

for Numofsti  =1:NumSti/2
    Sti1 = whisker_boxplot(Numofsti-0.6*xs,squeeze(topo_box(:,2*(Numofsti-1)+1)),[1 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti2 = whisker_boxplot(Numofsti+0.6*xs,squeeze(topo_box(:,2*Numofsti)),[0 0 1],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
end
hold on;
set(gca,'XTick',1:length(XTickLabels),'XTickLabels',XTickLabels)
legend([Sti1(1) Sti2(1)],{'Disgusting','Fearful'});
ylim([-10 4]);
tN = strcat('aPCA-',Measurment_Name{measureFlag},32,'measurement: Amplitudes for different conditions');
title(tN,'fontsize',14);
ylabel(['Amplitude/\muV'],'fontsize',16);

%%  Two-Way anova
% within-subjects analysis
disp('Statistical results for mean measurement');
[subNum,stiNum]= size(topo_box);
Y = reshape(topo_box,[],1);
stiOne =3;
stiTwo = 2;
stiNum = stiOne*stiTwo;
BTFacs =[];
WInFacs = [];
count = 0;
for is = 1:stiOne
    IdexStart = subNum*(is-1)*stiTwo+1;
    IdexEnd =  is*subNum*stiTwo;
    WInFacs(IdexStart:IdexEnd,1) = is;
    for iss  = 1:stiTwo
        count  = count +1;
        IdexStart = subNum*(count-1)+1;
        IdexEnd =  subNum*count;
        WInFacs(IdexStart:IdexEnd,2) = iss;
    end
end

S = [];
for iss = 1:stiNum
    IdexStart = subNum*(iss-1)+1;
    IdexEnd =  iss*subNum;
    S(IdexStart:IdexEnd,1) =1:subNum ;
end
factorNames = {'Valence','Negative-category '};
D = reshape(Y,1 ,[]);
sta = f_rm_anova2(D,WInFacs,S,factorNames);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Peak Measurement%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


measureFlag = 2;%% Choose method for measuring ampltideus of N2 under different experimental conditions (1.Mean measurement; 2.Peak measurement)
Measurment_Name = {'Mean','Peak'};
topo_box = squeeze(mean(TOPO_peak(ChansOfInterestNumbers,:,:),1))';
%%box plot
figure;
set(gcf,'outerposition',get(0,'screensize'));
hold on;
set(gca,'fontsize',14);
hold on;

temp1  =topo_box(:);
shiftxs= temp1 -min(temp1(:));
shiftxs=shiftxs/max(shiftxs)*2-1;

xs=.4/2; %the best half width for a 'group or catagory' is .4 and there are 2 subgroups (male/female)
width=xs*.4;% width of each box with a small gap between subgroups
XTickLabels= {'Extreme', 'Moderate','Neutral'};

for Numofsti  =1:NumSti/2
    Sti1 = whisker_boxplot(Numofsti-0.6*xs,squeeze(topo_box(:,2*(Numofsti-1)+1)),[1 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti2 = whisker_boxplot(Numofsti+0.6*xs,squeeze(topo_box(:,2*Numofsti)),[0 0 1],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
end
hold on;
set(gca,'XTick',1:length(XTickLabels),'XTickLabels',XTickLabels)
legend([Sti1(1) Sti2(1)],{'Disgusting','Fearful'});
ylim([-12 4]);
tN = strcat('aPCA-',Measurment_Name{measureFlag},32,'measurement: Amplitudes for different conditions');
title(tN,'fontsize',14);
ylabel(['Amplitude/\muV'],'fontsize',16);

%%  Two-Way anova
% within-subjects analysis
disp('Statistical results for peak measurement');
[subNum,stiNum]= size(topo_box);
Y = reshape(topo_box,[],1);
stiOne =3;
stiTwo = 2;
stiNum = stiOne*stiTwo;
BTFacs =[];
WInFacs = [];
count = 0;
for is = 1:stiOne
    IdexStart = subNum*(is-1)*stiTwo+1;
    IdexEnd =  is*subNum*stiTwo;
    WInFacs(IdexStart:IdexEnd,1) = is;
    for iss  = 1:stiTwo
        count  = count +1;
        IdexStart = subNum*(count-1)+1;
        IdexEnd =  subNum*count;
        WInFacs(IdexStart:IdexEnd,2) = iss;
    end
end

S = [];
for iss = 1:stiNum
    IdexStart = subNum*(iss-1)+1;
    IdexEnd =  iss*subNum;
    S(IdexStart:IdexEnd,1) =1:subNum ;
end
factorNames = {'Valence','Negative-category '};
D = reshape(Y,1 ,[]);
sta = f_rm_anova2(D,WInFacs,S,factorNames);


uiwait(msgbox('The program ends'));
%% program end
toc
