%%% Using PCA to extract ERPs of interest from the filtered single-trial dataset of individual subject separately and analysing back-projection:
%%%     1.Estimate the number of sources by using cumulative explained variance  method
%%%     2.Plot rotated temporal and spatial components
%%%     3.Select the componnets associated with N2 of interest.
%%%     4.Project the selected components to the electrode fields (i.e., in microvolts)
%%% Analysing back-projection of N2:
%%%     1.Plot grand waveforms at specific eletrodes
%%%     2.Plot grand topographies within predifined time-window for N2
%%%     3.Plot similarities of topographies across all subjects for N2
%%%     4.Calculate statistical analysis results (two-way ANOVA)

%%% Please uses the output from: m_Filter_data_by_wavelet_filter.m
%%% In order to run this code, please install EEGLAB toolboxes. It can be downloaded from http://sccn.ucsd.edu/eeglab/
%%% This code was written by GuangHui Zhang in Match 2021, JYU
%%% Faculty of Information Technology, University of Jyv�skyl�
%%% Address: Seminaarinkatu 15,PO Box 35, FI-40014 University of Jyv�skyl�,Jyv�skyl�, FINLAND
%%% E-mails: zhang.guanghui@foxmail.com


%%% When using this code, please cite the following articles:
%%% 1. Fengyu Cong, Yixiang Huang, Igor Kalyakin, Hong Li, Tiina Huttunen-Scott, Heikki Lyytinen, Tapani Ristaniemi,
%%% Frequency Response based Wavelet Decomposition to Extract Children's Mismatch Negativity Elicited by Uninterrupted Sound,
%%% Journal of Medical and Biological Engineering, 2012, 32(3): 205-214, DOI: 10.5405/jmbe.908
%%% 2. Guanghui Zhang, Xueyan Li, and Fengyu Cong. Objective Extraction of Evoked Event-related Oscillation from Time-frequency Representation of Event-related Potentials.
%%% Neural Plasticity. DOI:10.1155/2020/8841354
%%% 3. Lu, Y., Luo, Y., Lei, Y., Jaquess, K. J., Zhou, C., & Li, H. (2016). Decomposing valence intensity effects in disgusting and fearful stimuli: an event-related potential study.
%%% Social neuroscience, 11(6), 618-626. doi:https://doi.org/10.1080/17470919.2015.1120238


clear
clc
close all
%%
tic
%Location of the main study directory
%This method of specifying the study directory only works if you run the script;
%for running individual lines of code, replace the study directory with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment
Subject_file_Path = fileparts(fileparts(mfilename('fullpath')));


%Location of the folder that contains this script and any associated processing files
%This method of specifying the current file path only works if you run the script;
%For running individual lines of code, replace the current file path with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment\Codes_for_EEG_ERP_Processing
Current_File_Path = fileparts(mfilename('fullpath'));

%List of subjects to process, based on the name of the folder that contains that subject's data
Subject_Name = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20'};

% List of stimulus for each subject to process separately, based on the name of the sub-folder that contains that subject's data
Stimulus_Name = {'MD','MF','ED','EF','ND','NF'};

%% add function into path
Currentpath1 = char(strcat(Current_File_Path,filesep,'functions',filesep));
addpath(genpath(Currentpath1));


%%
R_source = [30 31 32 29 30 29 32 30 31 30 30 28 29 28 31 29 32 33 30 31];%% The number of retained components for each subject when the first R components explained 99% of variance;
%% In order to N2 to be separated with others, we select more components which explained more than 99% for subjects 7th and 18th
Selectedcomponents_K = {'6,8','6,11,12','7,8,10','1,10,16','3,9,11','11,12','10,12,14,32','4,7,9',...
    '10,12,31','12,27','1,12,14','3,9,11','9,12','12,14,15','5,14,17','2,13,18','6,15','7,19',...
    '2,8,11','1,22,25,31'};%% the orders of the selected components for each subject

Flag_plot_component = 2;%% Whether plot temporal and spatial components or not(1.Yes; 2.No).


ERPStart  =190;%% The lower interval of time-window for N2
ERPEnd = 290; %% The upper interval of time-window for N2
ChansOfInterestNames = {'FC3','FCz','FC4','C3','Cz','C4'};%% Names of electrodes of interest
Numsti  = 6; % Number of stimuli

load chanlocs;
timeStart = -200;
timeEnd = 900;
fs = 1000;

TOPO_original = importdata('Topo_190_290_mean_wavelet.mat');%% template i.e., topographies of different conditions within 190-290ms when using convenational time domain analysis


ERPSampointStart = round((ERPStart - timeStart)/(1000/fs)) + 1 ;
ERPSampointEnd = round((ERPEnd - timeStart)/(1000/fs)) + 1 ;
%%load data


for Numofsub = 1:length(Subject_Name)
    
    X = [];
    count = 0;
    count1 = 0;
    sti_trial_label =[];
    
    
    for Numofsti = 1:length(Stimulus_Name)
        %%load data of each subject under each condition
        EEG = [];
        fileName = strcat('Sub_',Subject_Name{Numofsub},'_Emotional_Lu_2017',filesep,Subject_Name{Numofsub},'_',Stimulus_Name{Numofsti},'_WF.set');
        EEG = pop_loadset([Subject_file_Path,filesep,fileName]);
        EEG = eeg_checkset( EEG );
        EEG = pop_select( EEG,'nochannel',{'TP9' 'VEOG' 'TP10' 'HEOG'});
        EEG = eeg_checkset( EEG );
        
        count1= count1+1;
        %%%
        data = [];
        data = double(EEG.data);
        [chanNum,samPoints,trialNum] = size(data);
        sti_trial_label = [sti_trial_label;count1*ones(trialNum,1)];
        
        for Numoftrial = 1:trialNum
            count = count +1;
            X(:,:,count)  = squeeze(data(:,:,Numoftrial));
        end
        
    end
    
    [NumChans,NumSamps,Numtrials] = size(X);
    X = permute(X,[2 1 3]);
    %% grouping data into a matrixgroup_Index = ones(NumSubs,1);
    X= reshape(X,NumSamps,NumChans*Numtrials);
    timeIndex = linspace(timeStart,timeEnd,NumSamps);
    
    %%PCA
    [coef,score,lambda] = pca(X');
    ratio = f_explainedVariance(lambda);
    
    %% defined the number of source based on cumulative explained variance
    %     threshold = L;
    %     [~,R] = min(abs(ratio(:)-threshold));
    %     remained_r(Numofsub) = R;
    R = R_source(Numofsub);
    
    for is = 1:length(lambda)
        ratio_sigle(is) = 100*lambda(is)./sum(lambda);
    end
    ratio_sigle_keep = ratio_sigle(1:R);
    
    %% rotation
    V = coef(:,1:R);
    Z = score(:,1:R);
    %% rotation for blind source separation
    [translated_V,W] = rotatefactors(V, 'Method','promax','power',3,'Maxit',500);
    B = inv(W');
    Y = Z*W; %%% spatial components
    T = V*B;  %%% temporal components
    
    [peakValue,peakTime] = max(abs(T));
    timePstart = ceil((0-timeStart)/(1000/fs))+1;
    for r = 1 :R
        temp = T(:,r);
        T (:,r) =  temp - mean(temp(1:timePstart));
        peak_T(r) = round((peakTime(r)-1)*(1000/fs)) + timeStart;
    end
    
    %% whether plot temporal and spatial components or not. Flag_plot_component == 1: yes; Flag_plot_component == 2: No.
    if Flag_plot_component == 1
        %%
        topo = [];
        topo = reshape(Y',R,NumChans,Numtrials);
        %%%
        RHO = [];
        %     topo_similarity = [];
        topo_av = [];
        for Numofsti =1:Numsti
            idx1 = find(sti_trial_label == Numofsti);
            topo_av(:,:,Numofsti) =  squeeze(mean(topo(:,:,idx1),3));
            for k = 1:R
                temp1 = corr(squeeze(topo(k,:,idx1)));
                topo_similarity{:,:,k,Numofsti} = temp1;
                RHO(k,Numofsti) = mean(temp1(:));
            end
        end
        
        rho = mean(RHO,2);
        [rho_ranked, idx] = sort(rho,'descend');
        %% Explained variance of each component of keep componets and Correlation Coefficient between spatial components
        Sti_names = {'MD','MF','ED','EF','DN','DF'};
        %%  plot results of temporal components and spatial components
        
        rowNum = 3;
        columnNum = 6;
        
        for kk = 1:R
            k = idx(kk);
            topo_k = squeeze(topo_av(k,:,:));
            %         topo_k = reshape(topo_k,[],1);
            topo_corr = corrcoef(TOPO_original,topo_k);
            mV = max(abs(topo_k(:)));
            figure(k)
            set(gcf,'outerposition',get(0,'screensize'));
            %%plot temporal components
            subplot(rowNum,columnNum,[1:columnNum],'align')
            set(gca,'fontsize',14)
            plot(timeIndex,T(:,k),'k','linewidth',3)
            xlim([timeStart timeEnd])
            grid on
            xlabel('Time/ms')
            ylabel('Magnitude')
            title(['Comp #',int2str(k),'(Explained variance =',num2str(roundn(ratio_sigle_keep(k),-2)),'%, Peak Time = ',num2str(peak_T(k)),'ms)']);
            set(gca,'ydir','reverse');
            count = 0;
            for Numofsti = 1:Numsti
                count = count +1;
                %%plot spatial components
                subplot(rowNum,columnNum,columnNum + count,'align')
                set(gca,'fontsize',14)
                topoplot(squeeze(topo_av(k,:,Numofsti)),chanlocs,'maplimits',[-mV,mV]);
                if Numofsti ==1
                    tN = strcat('CC#',num2str(roundn(abs(topo_corr(1,2)),-2)),32,Sti_names{Numofsti});
                else
                    tN = Sti_names{Numofsti};
                end
                title(tN,'fontsize',14);
                if columnNum + count  == 2*columnNum %%position of colorbar
                    last_subplot = subplot(rowNum,columnNum,count+columnNum,'align');
                    last_subplot_position = get(last_subplot,'position');
                    colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
                    set(last_subplot,'pos',last_subplot_position);
                end
                
                %%plot similarities of topographies acroos all trials
                subplot(rowNum,columnNum,ceil(rowNum/2)*columnNum+count,'align')
                set(gca,'fontsize',14)
                imagesc(squeeze(topo_similarity{:,:,k,Numofsti}))
                set(gca,'clim',[-1 1])
                if Numofsti ==1
                    tN = strcat('Similarity#',num2str(roundn(rho_ranked(kk),-2)),32,Sti_names{Numofsti});
                else
                    tN = Sti_names{Numofsti};
                end
                title(tN,'fontsize',14);
                
                if Numofsti == 1
                    xlabel('Trial #')
                    ylabel('Trial #')
                end
                
                if ceil(rowNum/2)*columnNum+count  == 3*columnNum
                    last_subplot = subplot(rowNum,columnNum,ceil(rowNum/2)*columnNum+count,'align');
                    last_subplot_position = get(last_subplot,'position');
                    colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
                    set(last_subplot,'pos',last_subplot_position);
                end
                
            end
        end
        %%
        
    end
    if Flag_plot_component == 1
        msgbox('If you want to reset orders of selected components,Please press any key!!!')
        pause;
        prompt = {'Reset the orders of the components of interest:'};
        dlg_title = 'Input';
        num_lines = 1;
        def = {Selectedcomponents_K{Numofsub}};
        answer = inputdlg(prompt,dlg_title,num_lines,def);
        selectedComponentNumbers = str2num(answer{1});
    else
        selectedComponentNumbers = str2num(Selectedcomponents_K{Numofsub});%% the orders of  selected components associated with N2
    end
    close all;
    
    temp= [];
    E = T(:,selectedComponentNumbers)*Y(:,selectedComponentNumbers)'; %% back-projection
    temp = reshape(E,NumSamps,NumChans,Numtrials);
    
    %%%%%%% trials' data are averaged under each condition
    D= [];
    count1=0;
    for Numofsti =1:Numsti
        idx1 = find(sti_trial_label == Numofsti);
        D(:,:,Numofsti) =  squeeze(mean(temp(:,:,idx1),3));
    end
    
    
    %%% store data of each subject
    D = permute(D,[2 1 3]);
    D_p(:,:,:,Numofsub) = D;
    
    clear topo_similarity;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Analysing the back-projection for aPCA%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

prompt = {'Reset the orders of the selected subjects for next analysis:'};
dlg_title = 'Input';
num_lines = 1;
def = {'1:20'};
answer = inputdlg(prompt,dlg_title,num_lines,def);
selectedsubjects = str2num(answer{1});
D = [];
D = D_p(:,:,:,selectedsubjects);

save('X_individual_wavelet_PCA_single_trial','D','-v7.3');

[NumChans,NumSamps,NumSti,NumSubs] = size(D);
tIndex = linspace(timeStart,timeEnd,NumSamps);

Group_Idx= ones(NumSubs,1);
NumGroups = max(Group_Idx);

%%Find the orders of the desired electrodes
ChansOfInterestNumbers = [];
count = 0;
for chanSelected = 1:length(ChansOfInterestNames)
    for chan = 1:NumChans
        code = strcmp(chanlocs(chan).labels,ChansOfInterestNames{chanSelected});
        if code == 1
            count =  count +1;
            ChansOfInterestNumbers(count) = chan;
        end
    end
end

if  length(ChansOfInterestNames) > 1
    filechanName = char(ChansOfInterestNames{1});
    for Numofchannel = 1:length(ChansOfInterestNames) - 1
        filechanName = char(strcat(filechanName,',',32,ChansOfInterestNames{Numofchannel+1}));
    end
else
    filechanName = char(ChansOfInterestNames);
end
%% measurement meathods:mean value/peak value
TOPO = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:,:),2));%% mean measurement
%% peak measurement
for subNum = 1:NumSubs
    for stimulusNumFactorOne = 1:NumSti
        for chanNum = 1:NumChans
            temp = squeeze(D(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum))';
            [mV  Idx] = max(abs(temp(:)));
            TOPO_peak(chanNum,stimulusNumFactorOne,subNum)  = squeeze(D(chanNum,ERPSampointStart+Idx,stimulusNumFactorOne,subNum));
        end
    end
end
%% calculating the topography of the data
topo_similarity = [];
for groupNum = 1:NumGroups
    idx1 = find(Group_Idx == groupNum);
    D_av(:,:,:,groupNum) = squeeze(mean(D(:,:,:,idx1),4));
    topo_GA(:,:,groupNum) = squeeze(mean(TOPO(:,:,idx1),3));
    for sti = 1:NumSti
        temp = corrcoef(squeeze(TOPO(:,sti,idx1)));
        topo_similarity(:,:,sti,groupNum) = temp;
    end
end
%% the Grand waveform(s) at interest electrode(s)
Stimulus_Name = {'MD','MF','ED','EF','ND','NF'};
mv_max = max(topo_GA(:));
mv_min = min(topo_GA(:));


D_av_w = squeeze(mean(D_av(ChansOfInterestNumbers,:,:,:),1));
y_MIN = 1.1*min(D_av_w(:));
y_MAX = 1.1*max(D_av_w(:));
y_max = 1.5*max(abs(D_av_w(:)));
%%


figure(1);
set(gcf,'outerposition',get(0,'screensize'))
count = 0;
count_s = 0;
for groupNum = 1:NumGroups
    count = count  + 1;
    %     subplot(rowNum,columnNum,count);
    set(gca,'fontsize',16,'FontWeight','bold');
    for sti = 1:NumSti
        count_s= count_s+1;
        switch count_s
            case 1
                plot(tIndex, D_av_w(:,sti,groupNum),'k','linewidth',2)
                hold on;
            case 2
                plot(tIndex, D_av_w(:,sti,groupNum),'k--','linewidth',2)
                hold on;
            case 3
                plot(tIndex, D_av_w(:,sti,groupNum),'r','linewidth',4)
                hold on;
            case 4
                plot(tIndex, D_av_w(:,sti,groupNum),'r--','linewidth',4)
                hold on;
            case 5
                plot(tIndex, D_av_w(:,sti,groupNum),'b','linewidth',2)
                hold on;
            case 6
                plot(tIndex, D_av_w(:,sti,groupNum),'b-.','linewidth',2)
                hold on;
        end
        set(gca,'ydir','reverse','FontWeight','bold');
        xlim([timeStart,timeEnd]);
        ylim([y_MIN,y_MAX]);
        
        hold on;
    end
    
    xlabel(['Time/ms'],'fontsize',16);
    ylabel(['Amplitude/\muV'],'fontsize',16);
    legend(Stimulus_Name,'location','best')
    tN = strcat('iPCA-grand Averaged Waveform at',32,filechanName);
    title(tN,'fontsize',16);
end

% figureName = char(strcat('iPCA_GA_Waveform_',num2str(ERPStart),'_',num2str(ERPEnd)),Measurment_Name{measureFlag},'.png');
% saveas(figure(1),figureName,'png');
% saveas(figure(1),figureName,'fig');

%%  Plot grand averaged topographies for different experimental conditions
rowNum =2;
columnNum = 3;
figure(2)
set(gcf,'outerposition',get(0,'screensize'));
count = 0;
for groupNum = 1:NumGroups
    for sti = 1:NumSti/2
        count = count +1;
        subplot(rowNum,columnNum,count,'align')
        set(gca,'fontsize',16,'FontWeight','bold')
        topoplot(squeeze(topo_GA(:,2*(sti-1)+1,groupNum)),chanlocs,'maplimits',[mv_min,mv_max]);
        if count == 1
            tN = strcat('iPCA-Grand averaged topography-',Stimulus_Name{2*(sti-1)+1});
        else
            tN = [Stimulus_Name{2*(sti-1)+1}];
        end
        
        title(tN,'fontsize',16);
        hold on;
        
        
        subplot(rowNum,columnNum,count+columnNum,'align')
        set(gca,'fontsize',16,'FontWeight','bold')
        topoplot(squeeze(topo_GA(:,2*sti,groupNum)),chanlocs,'maplimits',[mv_min,mv_max]);
        
        tN = strcat(Stimulus_Name{2*sti});
        title(tN,'fontsize',16);
        hold on;
        
        if count == 1
            xlabel('Subject #')
            ylabel('Subject #')
        elseif count*rowNum == NumSti*NumGroups
            last_subplot = subplot(rowNum,columnNum,count+columnNum,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
            set(last_subplot,'pos',last_subplot_position);
        end
        
        colormap('jet');
    end
end

% figureName = char(strcat('iPCA_GA_topo_',num2str(ERPStart),'_',num2str(ERPEnd),32,Measurment_Name{measureFlag}));
% saveas(figure(2),figureName,'png');
% saveas(figure(2),figureName,'fig');
%%  the correlation coefficient of topography between subjects
figure(3)
set(gcf,'outerposition',get(0,'screensize'));
count = 0;
for groupNum = 1:NumGroups
    for sti = 1:NumSti/2
        count = count +1;
        subplot(rowNum,columnNum,count,'align')
        set(gca,'fontsize',16,'FontWeight','bold')
        imagesc(squeeze(topo_similarity(:,:,2*(sti-1)+1,groupNum)))
        set(gca,'clim',[-1 1]);
        if count == 1
            tN = strcat('iPCA-Similarities of topograpgies over all subjects-',Stimulus_Name{2*(sti-1)+1});
        else
            tN = [Stimulus_Name{2*(sti-1)+1}];
        end
        
        title(tN,'fontsize',16);
        hold on;
        subplot(rowNum,columnNum,count+columnNum,'align')
        set(gca,'fontsize',16,'FontWeight','bold')
        imagesc(squeeze(topo_similarity(:,:,2*sti,groupNum)))
        set(gca,'clim',[-1 1]);
        tN = strcat(Stimulus_Name{2*sti});
        title(tN,'fontsize',16);
        hold on;
        
        if count == 1
            xlabel('Subject #')
            ylabel('Subject #')
        elseif count*rowNum == NumSti*NumGroups
            last_subplot = subplot(rowNum,columnNum,count+columnNum,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
            set(last_subplot,'pos',last_subplot_position);
        end
        
        colormap('jet');
    end
end
% figureName = char(strcat('iPCA_GA_smilarities_',num2str(ERPStart),'_',num2str(ERPEnd),32,Measurment_Name{measureFlag}));
% saveas(figure(3),figureName,'png');
% saveas(figure(3),figureName,'fig');

%%%%%%%%%%%%%%%%%%%%%mean measurement%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
measureFlag = 1;%% Choose method for measuring ampltideus of N2 under different experimental conditions (1.Mean measurement; 2.Peak measurement)
Measurment_Name = {'Mean','Peak'};
topo_box = squeeze(mean(TOPO(ChansOfInterestNumbers,:,:),1))';
%%box plot
figure;
set(gcf,'outerposition',get(0,'screensize'));
hold on;
set(gca,'fontsize',14);
hold on;

temp1  =topo_box(:);
shiftxs= temp1 -min(temp1(:));
shiftxs=shiftxs/max(shiftxs)*2-1;

xs=.4/2; %the best half width for a 'group or catagory' is .4 and there are 2 subgroups (male/female)
width=xs*.4;% width of each box with a small gap between subgroups
XTickLabels= {'Extreme', 'Moderate','Neutral'};

for Numofsti  =1:NumSti/2
    Sti1 = whisker_boxplot(Numofsti-0.6*xs,squeeze(topo_box(:,2*(Numofsti-1)+1)),[1 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti2 = whisker_boxplot(Numofsti+0.6*xs,squeeze(topo_box(:,2*Numofsti)),[0 0 1],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
end
hold on;
set(gca,'XTick',1:length(XTickLabels),'XTickLabels',XTickLabels)
legend([Sti1(1) Sti2(1)],{'Disgusting','Fearful'});
ylim([-6 0]);
tN = strcat('iPCA-',Measurment_Name{measureFlag},32,'measurement: Amplitudes for different conditions');
title(tN,'fontsize',14);
ylabel(['Amplitude/\muV'],'fontsize',16);

clc
%%  Two-Way anova within-subjects analysis
disp('Statistical results for mean measurement');
[subNum,stiNum]= size(topo_box);
Y = reshape(topo_box,[],1);
stiOne =3;
stiTwo = 2;
stiNum = stiOne*stiTwo;
BTFacs =[];
WInFacs = [];
count = 0;
for is = 1:stiOne
    IdexStart = subNum*(is-1)*stiTwo+1;
    IdexEnd =  is*subNum*stiTwo;
    WInFacs(IdexStart:IdexEnd,1) = is;
    for iss  = 1:stiTwo
        count  = count +1;
        IdexStart = subNum*(count-1)+1;
        IdexEnd =  subNum*count;
        WInFacs(IdexStart:IdexEnd,2) = iss;
    end
end

S = [];
for iss = 1:stiNum
    IdexStart = subNum*(iss-1)+1;
    IdexEnd =  iss*subNum;
    S(IdexStart:IdexEnd,1) =1:subNum ;
end
factorNames = {'Valence','Negative-category '};
D = reshape(Y,1 ,[]);
sta = f_rm_anova2(D,WInFacs,S,factorNames);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Peak Measurement %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% %%%%%%%%%%%%%%%%%%%%%%%%%%%
measureFlag = 2;%% Choose method for measuring ampltideus of N2 under different experimental conditions (1.Mean measurement; 2.Peak measurement)
Measurment_Name = {'Mean','Peak'};
topo_box = squeeze(mean(TOPO_peak(ChansOfInterestNumbers,:,:),1))';
%%box plot
figure;
set(gcf,'outerposition',get(0,'screensize'));
hold on;
set(gca,'fontsize',14);
hold on;

temp1  =topo_box(:);
shiftxs= temp1 -min(temp1(:));
shiftxs=shiftxs/max(shiftxs)*2-1;

xs=.4/2; %the best half width for a 'group or catagory' is .4 and there are 2 subgroups (male/female)
width=xs*.4;% width of each box with a small gap between subgroups
XTickLabels= {'Extreme', 'Moderate','Neutral'};

for Numofsti  =1:NumSti/2
    Sti1 = whisker_boxplot(Numofsti-0.6*xs,squeeze(topo_box(:,2*(Numofsti-1)+1)),[1 0 0],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
    Sti2 = whisker_boxplot(Numofsti+0.6*xs,squeeze(topo_box(:,2*Numofsti)),[0 0 1],'shiftxs',shiftxs*width,'width',width,'bub',1,'sat',0);
end
hold on;
set(gca,'XTick',1:length(XTickLabels),'XTickLabels',XTickLabels)
legend([Sti1(1) Sti2(1)],{'Disgusting','Fearful'});
ylim([-8 0]);
tN = strcat('iPCA-',Measurment_Name{measureFlag},32,'measurement: Amplitudes for different conditions');
title(tN,'fontsize',14);
ylabel(['Amplitude/\muV'],'fontsize',16);

%%  Two-Way anova
% within-subjects analysis
disp('Statistical results for peak measurement');
[subNum,stiNum]= size(topo_box);
Y = reshape(topo_box,[],1);
stiOne =3;
stiTwo = 2;
stiNum = stiOne*stiTwo;
BTFacs =[];
WInFacs = [];
count = 0;
for is = 1:stiOne
    IdexStart = subNum*(is-1)*stiTwo+1;
    IdexEnd =  is*subNum*stiTwo;
    WInFacs(IdexStart:IdexEnd,1) = is;
    for iss  = 1:stiTwo
        count  = count +1;
        IdexStart = subNum*(count-1)+1;
        IdexEnd =  subNum*count;
        WInFacs(IdexStart:IdexEnd,2) = iss;
    end
end

S = [];
for iss = 1:stiNum
    IdexStart = subNum*(iss-1)+1;
    IdexEnd =  iss*subNum;
    S(IdexStart:IdexEnd,1) =1:subNum ;
end
factorNames = {'Valence','Negative-category '};
D = reshape(Y,1 ,[]);
sta = f_rm_anova2(D,WInFacs,S,factorNames);

uiwait(msgbox('The program ends'));
%% program end
toc
