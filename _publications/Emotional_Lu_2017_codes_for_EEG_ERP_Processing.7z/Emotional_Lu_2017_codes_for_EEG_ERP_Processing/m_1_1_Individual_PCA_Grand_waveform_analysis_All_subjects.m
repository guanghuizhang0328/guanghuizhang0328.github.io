%%% Group analysis:
%%%     1.Plot grand averaged waveforms at specific eletrodes
%%%     2.Plot grand topographies within predifined time-window for ERPs of interest
%%%     3.Plot similarities of topographies across all subjects for ERPs of interest
%%%     4.Calculate statistical analysis results (Winth-subject design[one, two, three factors] and Between-subject design [two, three factors] ANOVA)

%%% Please uses the output from: m_1_0_Individual_PCA_Rotation_extract_component.m
%%% In order to run this code, please install EEGLAB toolboxes. It can be downloaded from http://sccn.ucsd.edu/eeglab/
%%% This code was written by GuangHui Zhang in July 2021, JYU
%%% Faculty of Information Technology, University of Jyv�skyl�
%%% Address: Seminaarinkatu 15,PO Box 35, FI-40014 University of Jyv�skyl�,Jyv�skyl�, FINLAND
%%% E-mails: zhang.guanghui@foxmail.com


%%% When using this code, please cite the following articles:
%%% 1. Guanghui Zhang, Xueyan Li, Yingzhi Lu, Timo Tiihonen, Zheng Chang, and Fengyu Cong. (2021). 
%%%    Single-trial-based Temporal Principal Component Analysis on Extracting Event-related Potentials of Interest for an Individual Subject.
%%%    bioRxiv. DOI:10.1101/2021.03.10.434892
%%% 2. Fengyu Cong, Yixiang Huang, Igor Kalyakin, Hong Li, Tiina Huttunen-Scott, Heikki Lyytinen, Tapani Ristaniemi,
%%%    Frequency Response based Wavelet Decomposition to Extract Children's Mismatch Negativity Elicited by Uninterrupted Sound,
%%%    Journal of Medical and Biological Engineering, 2012, 32(3): 205-214, DOI: 10.5405/jmbe.908
%%% 3. Guanghui Zhang, Xueyan Li, and Fengyu Cong. Objective Extraction of Evoked Event-related Oscillation from Time-frequency Representation of Event-related Potentials.
%%%    Neural Plasticity. DOI:10.1155/2020/8841354
%%% 4. Lu, Y., Luo, Y., Lei, Y., Jaquess, K. J., Zhou, C., & Li, H. (2016). Decomposing valence intensity effects in disgusting and fearful stimuli: an event-related potential study.
%%%    Social neuroscience, 11(6), 618-626. doi:https://doi.org/10.1080/17470919.2015.1120238


clear
clc
close all
%%
tic
%Location of the main study directory
%This method of specifying the study directory only works if you run the script;
%for running individual lines of code, replace the study directory with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment
Subject_file_Path = fileparts(fileparts(mfilename('fullpath')));


%Location of the folder that contains this script and any associated processing files
%This method of specifying the current file path only works if you run the script;
%For running individual lines of code, replace the current file path with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment\Codes_for_EEG_ERP_Processing
Current_File_Path = fileparts(mfilename('fullpath'));

%List of subjects to process, based on the name of the folder that contains that subject's data
% Subject_Name = {'1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20'};

% List of stimulus for each subject to process separately, based on the name of the sub-folder that contains that subject's data

%% add function into path
Currentpath1 = char(strcat(Current_File_Path,filesep,'functions',filesep));
addpath(genpath(Currentpath1));




geometry    = { [1.4 2.3 0.5] [1] [2 1 2 1] [2 1 2 1] [2 1 2 1] [2 1 2 1]};
editcomments = [ 'tmp = pop_comments(get(gcbf, ''userdata''), ''Edit comments of current dataset'');' ...
    'if ~isempty(tmp), set(gcf, ''userdata'', tmp); end; clear tmp;' ];
commandload = [ '[filename, filepath] = uigetfile(''*'', ''Select a text file'');' ...
    'if filename(1) ~=0,' ...
    '   set(findobj(''parent'', gcbf, ''tag'', tagtest), ''string'', [ filepath filename ]);' ...
    'end;' ...
    'clear filename filepath tagtest;' ];


uilist = { ...
    { 'Style', 'text', 'string', 'Channel location file (.mat)', 'horizontalalignment', 'right' , 'fontweight', 'bold' },  ...
    { 'Style', 'edit', 'string', '', 'horizontalalignment', 'left', 'tag',  'sphfile' }, ...
    { 'Style', 'pushbutton', 'string', 'Browse', 'callback', [ 'tagtest = ''sphfile'';' commandload ] },{}...
    ...
    { 'Style', 'text', 'string', 'Data sampling rate (Hz)', 'horizontalalignment', 'right', ...
    }, { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Levels of first-factor (within-subject)', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '0' }, ...
    ...
    { 'Style', 'text', 'string', 'Epoch Start (ms)', 'horizontalalignment', 'right', ...
    },  { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Levels of second-factor (within-subject)', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Epoch End (ms)', 'horizontalalignment', 'right', ...
    }, { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Levels of third-factor (within-subject)', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '0' }, ...
    { 'Style', 'text', 'string', 'Number of groups', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '1' },{},{}};


[ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_importdata'');', 'Import dataset info -- f_importdata()');

chanlocs  = importdata(results{1});
fs = str2num(results{2});
timeStart = str2num(results{4});
timeEnd = str2num(results{6});
factor1= str2num(results{3});
factor2= str2num(results{5});
factor3= str2num(results{7});
NumGroup =str2num(results{8});
if NumGroup==1
    Stimulus_Name = f_form_stiname_withsub(factor1,factor2,factor3);
else
    [Group_Idx,Stimulus_Name, Sti_Name_within] = f_form_stiname_betwsub(NumGroup,factor1,factor2,factor3) ;
end


%%
[inputname, inputpath] = uigetfile2('.mat', ['Load datase of projected for individual PCA:'], 'multiselect', 'on');
drawnow;
D= [];
for Numofsub = 1:length(inputname)
    D(:,:,:,Numofsub)=  importdata([inputpath,inputname{Numofsub}]);
end
if NumGroup ==1
    Group_Idx= ones(size(D,4),1);
end
%%
%% select electrodes of interest
promptstr    = { strvcat('Select interested electrode(s) ([]=all)')};
cbchanlocs = ['if isempty(chanlocs) ' ...
    '   errordlg2(''No chanlocs field'');' ...
    'else' ...
    '   tmpevent = chanlocs;' ...
    '   if isnumeric(chanlocs(1).labels),' ...
    '        [tmps,tmpstr] = pop_chansel(unique([ tmpevent.labels ]));' ...
    '   else,' ...
    '        [tmps,tmpstr] = pop_chansel(unique({ tmpevent.labels }));' ...
    '   end;' ...
    '   if ~isempty(tmps)' ...
    '       set(findobj(''parent'', gcbf, ''tag'', ''events''), ''string'', tmpstr);' ...
    '   end;' ...
    'end;' ...
    'clear tmps tmpevent tmpv tmpstr tmpfieldnames;' ];

geometry = { [2 1 0.5] [5 0.85]};
uilist = { { 'style' 'text'       'string' 'Select Interest Electrode(s) ([]=all))' } ...
    { 'style' 'edit'       'string' '' 'tag' 'events' } ...
    { 'style' 'pushbutton' 'string' '...' 'callback' cbchanlocs },...
    { 'Style', 'text', 'string', 'Averaged waveforms of selected channels (1.Yes;2.No)?', 'horizontalalignment', 'right', ...
    },   { 'Style', 'edit', 'string', '1' }};
result1 = inputgui( geometry, uilist, 'pophelp(''pop_chansel'')', 'Select interested electrode(s)');

Waveform_Flag= str2num(result1{2});

interestchanName  =[];

if strcmp(result1{1}, '')
    ChansOfInterestNumbers  = [1:length(chanlocs)];
else
    interestchanName =  regexp(result1{1},'\s+','split');
    
    %% 
    count = 0;
    ChansOfInterestNumbers = [];
    for chanSelected = 1:length(interestchanName)
        for chan = 1:length(chanlocs)
            code = strcmp(chanlocs(chan).labels,interestchanName{chanSelected});
            if code == 1
                count =  count +1;
                ChansOfInterestNumbers(count) = chan;
            end
        end
    end
    
end


if  length(interestchanName) > 1
    filechanName = char(interestchanName{1});
    for Numofchannel = 1:length(interestchanName) - 1
        filechanName = char(strcat(filechanName,'-',interestchanName{Numofchannel+1}));
    end
else
    filechanName = char(interestchanName);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[NumChans,NumSamps,NumSti,NumSubs] = size(D);
tIndex = linspace(timeStart,timeEnd,NumSamps);
NumGroups = max(Group_Idx);

%%%%%%%%%%%%%%%calculating the grand waveraged waveforms over subjects %%%%%%%%%%%%%%%
D_av  =[];
for groupNum = 1:NumGroups
    idx1 = find(Group_Idx == groupNum);
    D_av(:,:,:,groupNum) = squeeze(mean(D(:,:,:,idx1),4));
end
%%%%%%%%%%%%%%%%%plot the grand averaged waveforms at the typical electrodes
if Waveform_Flag==1
    
    D_av_w = squeeze(mean(D_av(ChansOfInterestNumbers,:,:,:),1));
    y_MIN = 1.1*min(D_av_w(:));
    y_MAX = 1.1*max(D_av_w(:));
    y_max = 1.5*max(abs(D_av_w(:)));
    D_av_w  =reshape(D_av_w,NumSamps,NumSti*NumGroups);
    %%
    
    figure;
    set(gcf,'outerposition',get(0,'screensize'))
    set(gca,'fontsize',16,'FontWeight','bold');
    
    plot(tIndex, D_av_w,'linewidth',2)
    hold on;
    set(gca,'ydir','reverse','FontWeight','bold');
    xlim([timeStart,timeEnd]);
    ylim([y_MIN,y_MAX]);
    hold on;
    xlabel(['Time/ms'],'fontsize',16);
    ylabel(['Amplitude/\muV'],'fontsize',16);
    legend(Stimulus_Name,'location','best')
    tN = strcat('Grand Averaged Waveform at',32,filechanName);
    title(tN,'fontsize',16);
    
    
    
else
    
    temp = squeeze(D_av(ChansOfInterestNumbers,:,:,:));
    y_MIN = 1.1*min(temp(:));
    y_MAX = 1.1*max(temp(:));
    
    
    for Numofchan = 1:length(ChansOfInterestNumbers)
        
        D_av_w  =reshape(squeeze(D_av(ChansOfInterestNumbers(Numofchan),:,:,:)),NumSamps,NumSti*NumGroups);
        %%
        
        figure;
        set(gcf,'outerposition',get(0,'screensize'))
        set(gca,'fontsize',16,'FontWeight','bold');
        
        plot(tIndex, D_av_w,'linewidth',2)
        hold on;
        set(gca,'ydir','reverse','FontWeight','bold');
        xlim([timeStart,timeEnd]);
        ylim([y_MIN,y_MAX]);
        hold on;
        xlabel(['Time/ms'],'fontsize',16);
        ylabel(['Amplitude/\muV'],'fontsize',16);
        legend(Stimulus_Name,'location','best')
        tN = strcat('Grand Averaged Waveform at',32,interestchanName{Numofchan});
        title(tN,'fontsize',16);
    end
    
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Topography and similarities of topographies among all subejcts%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%% determine the time window of interest

geometry    = { [2 1 2 1],[5 1],[2 1 2 1]};
uilist = { ...
    { 'Style', 'text', 'string', 'Edege of ERP start', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '190' }, ...
    ...
    { 'Style', 'text', 'string', 'Edge of ERP end', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'edit', 'string', '290' },...
    { 'Style', 'text', 'string', 'Meansurement method (1.Mean; 2.Peak)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '1' }, ...
    { 'Style', 'text', 'string', 'Row Number (Plot figure)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '' }, ...
    ...
    { 'Style', 'text', 'string', 'Column Number (Plot figure)', 'horizontalalignment', 'right','fontweight', 'bold', ...
    },   { 'Style', 'edit', 'string', '' }};

[ results_TW newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_form_stiname'');', 'Time-window');

ERPStart = str2num(results_TW{1});
ERPEnd = str2num(results_TW{2});
MeanFlag = str2num(results_TW{3});
rowNum = str2num(results_TW{4});
columnNum = str2num(results_TW{5});

ERPSampointStart = round((ERPStart - timeStart)/(1000/fs)) + 1 ;
ERPSampointEnd = round((ERPEnd - timeStart)/(1000/fs)) + 1 ;


%%%%%%%%%
TOPO =[];
if MeanFlag ==1
    %%%%%%%%%%Mean measurement
    TOPO = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:,:),2));
else
    %%%%%%%peak measurement%%%%%%%%%%%%%%%
    
    for subNum = 1:NumSubs
        for stimulusNumFactorOne = 1:NumSti
            for chanNum = 1:NumChans
                temp = squeeze(D(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum))';
                [mV  Idx] = max(abs(temp(:)));
                TOPO(chanNum,stimulusNumFactorOne,subNum)  = squeeze(D(chanNum,ERPSampointStart+Idx,stimulusNumFactorOne,subNum));
            end
        end
    end
end
%% calculating the topography of the data
% topo_similarity = [];
for groupNum = 1:NumGroups
    idx1 = find(Group_Idx == groupNum);
    D_av(:,:,:,groupNum) = squeeze(mean(D(:,:,:,idx1),4));
    topo_GA(:,:,groupNum) = squeeze(mean(TOPO(:,:,idx1),3));
    for sti = 1:NumSti
        temp = corrcoef(squeeze(TOPO(:,sti,idx1)));
        topo_similarity{sti,groupNum} = temp;
    end
end
%%%%%%%%%%%%%%%  Plot grand averaged topographies for different experimental conditions%%%%%%%%%%%%%%%
mv_min = min(topo_GA(:));
mv_max = max(topo_GA(:));

figure;
set(gcf,'outerposition',get(0,'screensize'));
count = 0;
for groupNum = 1:NumGroups
    for sti = 1:NumSti
        count = count +1;
        subplot(rowNum,columnNum,count,'align')
        set(gca,'fontsize',16,'FontWeight','bold')
        topoplot(squeeze(topo_GA(:,sti,groupNum)),chanlocs,'maplimits',[mv_min,mv_max]);
        if count == 1
            tN = strcat('Grand averaged topography-',Stimulus_Name{count});
        else
            tN = [Stimulus_Name{count}];
        end
        title(tN,'fontsize',16);
        hold on;
        
        
        if count == NumSti*NumGroups
            last_subplot = subplot(rowNum,columnNum,count,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
            set(last_subplot,'pos',last_subplot_position);
        end
        colormap('jet');
    end
end
%%%%%%%%%%%%%%%  the correlation coefficient of topographies among all subjects
figure;
set(gcf,'outerposition',get(0,'screensize'));
count = 0;
for groupNum = 1:NumGroups
    for sti = 1:NumSti
        count = count +1;
        subplot(rowNum,columnNum,count,'align')
        set(gca,'fontsize',16,'FontWeight','bold');
        hold on;
        imagesc(squeeze(topo_similarity{sti,groupNum}))
        set(gca,'clim',[-1 1]);
        
        idx1 = find(Group_Idx == groupNum);
        xlim([0.5,length(idx1)+0.5]);
        ylim([0.5,length(idx1)+0.5]);
        
        if count == 1
            tN = strcat('Similarities of topographies over all subjects-',Stimulus_Name{count});
        else
            tN = [Stimulus_Name{count}];
        end
        title(tN,'fontsize',16);
        hold on;
        
        if count == 1
            xlabel('Subject #')
            ylabel('Subject #')
        elseif count == NumSti*NumGroups
            last_subplot = subplot(rowNum,columnNum,count,'align');
            last_subplot_position = get(last_subplot,'position');
            colorbar_h = colorbar('peer',gca,'eastoutside','fontsize',14);
            set(last_subplot,'pos',last_subplot_position);
        end
        
        colormap('jet');
    end
end


%%%%%%%%%%%%% Reapted-measurement ANOVA
topo_box = squeeze(mean(TOPO(ChansOfInterestNumbers,:,:),1))';

f_rmanova(topo_box,NumGroups,factor1,factor2,factor3,Group_Idx);


if NumGroups >1
    
 Stimulus_Name  = Sti_Name_within;   
end
%%%%%%%%%%%save the analyzed the data to excel file%%%%%%%%%%%%%%%%%%%%%

geometry    = { [5 1] [5 1]};
uilist = { ...
    { 'Style', 'text', 'string', 'Export the current data to excel file  (1.Yes; 2.No)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '2' },...
    { 'Style', 'text', 'string', 'The data are averaged over channels  (1.Yes; 2.No)', 'horizontalalignment', 'right','fontweight', 'bold'},   { 'Style', 'edit', 'string', '2' }};
[ results newcomments ] = inputgui( geometry, uilist, 'functionhelp(''f_output_excel'');', 'Export the current data to excel file');
codeFlag  = str2num(results{1});
Measure_channel_Flag  = str2num(results{2});
if codeFlag ==1
f_output_excel(TOPO,interestchanName,ChansOfInterestNumbers,Stimulus_Name,Measure_channel_Flag,Group_Idx)
end
%%%%%%%%%%%%
uiwait(msgbox('The program ends'));
%% program ends
toc