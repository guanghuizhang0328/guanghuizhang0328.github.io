%%% Plot mean/standard values of similarities of topographies between
%%% different subject for different techniques

%%% Please uses the output from:
%%% m_Filter_data_by_wavelet_filter.m;m_Conventional_time_domain_analysis_for_filtered_data;m_single_trials_Group_PCA_Rotation_Projection_filtered_data
%%% m_Averaged_Group_PCA_Rotation__Projection_filtered_data;m_individual_analysis_PCA_Rotation_single_trial_filtered_data;


%%% In order to run this code, please install EEGLAB toolboxes. It can be downloaded from http://sccn.ucsd.edu/eeglab/
%%% This code was written by GuangHui Zhang in Match 2021, JYU
%%% Faculty of Information Technology, University of Jyv�skyl�
%%% Address: Seminaarinkatu 15,PO Box 35, FI-40014 University of Jyv�skyl�,Jyv�skyl�, FINLAND
%%% E-mails: zhang.guanghui@foxmail.com


%%% When using this code, please cite the following articles:
%%% 1. Fengyu Cong, Yixiang Huang, Igor Kalyakin, Hong Li, Tiina Huttunen-Scott, Heikki Lyytinen, Tapani Ristaniemi,
%%% Frequency Response based Wavelet Decomposition to Extract Children's Mismatch Negativity Elicited by Uninterrupted Sound,
%%% Journal of Medical and Biological Engineering, 2012, 32(3): 205-214, DOI: 10.5405/jmbe.908
%%% 2. Guanghui Zhang, Xueyan Li, and Fengyu Cong. Objective Extraction of Evoked Event-related Oscillation from Time-frequency Representation of Event-related Potentials.
%%% Neural Plasticity. DOI:10.1155/2020/8841354
%%% 3. Lu, Y., Luo, Y., Lei, Y., Jaquess, K. J., Zhou, C., & Li, H. (2016). Decomposing valence intensity effects in disgusting and fearful stimuli: an event-related potential study.
%%% Social neuroscience, 11(6), 618-626. doi:https://doi.org/10.1080/17470919.2015.1120238






clear
clc
close all

tic
%%
%Location of the main study directory
%This method of specifying the study directory only works if you run the script;
%for running individual lines of code, replace the study directory with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment
Subject_file_Path = fileparts(fileparts(mfilename('fullpath')));


%Location of the folder that contains this script and any associated processing files
%This method of specifying the current file path only works if you run the script;
%For running individual lines of code, replace the current file path with the path on your computer, e.g.: DIR = \Users\Lu_Emotional_ERP_Experiment\Codes_for_EEG_ERP_Processing
Current_File_Path = fileparts(mfilename('fullpath'));

%% add function into path
Currentpath1 = char(strcat(Current_File_Path,filesep,'functions',filesep));
addpath(genpath(Currentpath1));






TOPO_original = importdata('Topo_190_290_mean_wavelet.mat');
% TOPO_original = reshape(TOPO_original,[],1);

fs = 1000;
timeStart = -200;
timeEnd = 900;

ERPStart = 190;
ERPEnd = 290;
ERPSampointStart = round((ERPStart - timeStart)/(1000/fs)) + 1 ;
ERPSampointEnd = round((ERPEnd - timeStart)/(1000/fs)) + 1 ;
chanInterestNum = [3 4 5 10 11 15];%%FC3,FC4,FCZ,CZ,C3,C4
X_all = [];
TOPO_amp = [];


%% wavelet
X_all1 = importdata('X_WF_all_trials.mat');


[NumChans,NumSamps,stiNum,NumSubs] = size(X_all1);


Group_Idx = ones(NumSubs,1);

NumGroups = max(Group_Idx);
tIndex = linspace(timeStart,timeEnd,NumSamps);
%% MEAN measurement
topo_box = [];
TOPO1= [];
TOPO1 = squeeze(mean(X_all1(:,ERPSampointStart:ERPSampointEnd,:,:),2));


TOPO_mean = squeeze(mean(TOPO1(chanInterestNum,:,:),1));

TOPO_mean_Final(:,1,1) = mean(TOPO_mean,2);
TOPO_mean_Final(:,1,2) = std(TOPO_mean,0,2);


%% The mean and sta. of the similarty of topographies across subjects
RHO = [];
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO1(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data2 = [];
            data2 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data2);
            
        end
    end
end

TOPO_Similar__mean_Final(:,1,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar__mean_Final(Numofsti,1,2) = std(RHO(Numofsti,:));
end


%%peak measurement%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for subNum = 1:NumSubs
    for stimulusNumFactorOne = 1:stiNum
        for chanNum = 1:NumChans
            temp = squeeze(X_all1(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum))';
            [mV  Idx3] = max(abs(temp(:)));
            TOPO_peak1(chanNum,stimulusNumFactorOne,subNum)  = squeeze(X_all1(chanNum,ERPSampointStart+Idx3,stimulusNumFactorOne,subNum));
            Topo_latency1(chanNum,stimulusNumFactorOne,subNum)= ERPSampointStart+Idx3-1+timeStart;
        end
    end
end

TOPO_peak_av1 = squeeze(mean(TOPO_peak1(chanInterestNum,:,:),1));
Topo_latency_av1 = squeeze(mean(Topo_latency1(chanInterestNum,:,:),1))';


TOPO_peak_Final(:,1,1) = mean(TOPO_peak_av1,2);
TOPO_peak_Final(:,1,2) = std(TOPO_peak_av1,0,2);



%% The mean and sta. of the similarty of topographies across subjects
RHO = [];
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO_peak1(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        
        
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data2 = [];
            data2 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data2);
            
        end
    end
end



TOPO_Similar_peak_Final(:,1,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar_peak_Final(Numofsti,1,2) = std(RHO(Numofsti,:));
end




%%%individual
X_all = importdata('X_individual_wavelet_PCA_single_trial.mat');
[NumChans,NumSamps,stiNum,NumSubs] = size(X_all);


Group_Idx = ones(NumSubs,1);

NumGroups = max(Group_Idx);
tIndex = linspace(timeStart,timeEnd,NumSamps);
%% MEAN measurement
topo_box = [];
TOPO= [];
TOPO = squeeze(mean(X_all(:,ERPSampointStart:ERPSampointEnd,:,:),2));
TOPO_mean = squeeze(mean(TOPO(chanInterestNum,:,:),1));


TOPO_mean_Final(:,2,1) = mean(TOPO_mean,2);
TOPO_mean_Final(:,2,2) = std(TOPO_mean,0,2);


%% The mean and sta. of the similarty of topographies across subjects
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data2 = [];
            data2 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data2);
            
        end
    end
end

TOPO_Similar__mean_Final(:,2,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar__mean_Final(Numofsti,2,2) = std(RHO(Numofsti,:));
end

%%peak measurement%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for subNum = 1:NumSubs
    for stimulusNumFactorOne = 1:stiNum
        for chanNum = 1:NumChans
            temp = squeeze(X_all(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum))';
            [mV  Idx3] = max(abs(temp(:)));
            TOPO_peak(chanNum,stimulusNumFactorOne,subNum)  = squeeze(X_all(chanNum,ERPSampointStart+Idx3,stimulusNumFactorOne,subNum));
            Topo_latency(chanNum,stimulusNumFactorOne,subNum)= ERPSampointStart+Idx3-1+timeStart;
        end
    end
end

TOPO_peak_av = squeeze(mean(TOPO_peak(chanInterestNum,:,:),1));
Topo_latency_av = squeeze(mean(Topo_latency(chanInterestNum,:,:),1))';

TOPO_peak_Final(:,2,1) = mean(TOPO_peak_av,2);
TOPO_peak_Final(:,2,2) = std(TOPO_peak_av,0,2);


%% The mean and sta. of the similarty of topographies across subjects
RHO = [];
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO_peak(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        
        
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data2 = [];
            data2 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data2);
            
        end
    end
end

TOPO_Similar_peak_Final(:,2,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar_peak_Final(Numofsti,2,2) = std(RHO(Numofsti,:));
end


%%
load ('PCA_average_group_level_rotation_R_15_K_2  4  9.mat');
[NumChans,NumSamps,stiNum,NumSubs] = size(D);


Group_Idx = ones(NumSubs,1);

NumGroups = max(Group_Idx);
tIndex = linspace(timeStart,timeEnd,NumSamps);
%% MEAN measurement
topo_box = [];
TOPO2= [];
TOPO2 = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:,:),2));
TOPO_mean = squeeze(mean(TOPO2(chanInterestNum,:,:),1));

TOPO_mean_Final(:,3,1) = mean(TOPO_mean,2);
TOPO_mean_Final(:,3,2) = std(TOPO_mean,0,2);


%% The mean and sta. of the similarty of topographies across subjects
RHO = [];
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO2(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        
        
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data2 = [];
            data2 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data2);
            
        end
    end
end

TOPO_Similar__mean_Final(:,3,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar__mean_Final(Numofsti,3,2) = std(RHO(Numofsti,:));
end
%%peak measurement%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for subNum = 1:NumSubs
    for stimulusNumFactorOne = 1:stiNum
        for chanNum = 1:NumChans
            temp = squeeze(D(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum))';
            [mV  Idx3] = max(abs(temp(:)));
            TOPO_peak2(chanNum,stimulusNumFactorOne,subNum)  = squeeze(D(chanNum,ERPSampointStart+Idx3,stimulusNumFactorOne,subNum));
            Topo_latency2(chanNum,stimulusNumFactorOne,subNum)= ERPSampointStart+Idx3-1+timeStart;
        end
    end
end

TOPO_peak_av2 = squeeze(mean(TOPO_peak2(chanInterestNum,:,:),1));
Topo_latency_av2 = squeeze(mean(Topo_latency2(chanInterestNum,:,:),1))';


TOPO_peak_Final(:,3,1) = mean(TOPO_peak_av2,2);
TOPO_peak_Final(:,3,2) = std(TOPO_peak_av2,0,2);

%% The mean and sta. of the similarty of topographies across subjects
RHO = [];
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO_peak2(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        
        
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data2 = [];
            data2 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data2);
            
        end
    end
end

TOPO_Similar_peak_Final(:,3,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar_peak_Final(Numofsti,3,2) = std(RHO(Numofsti,:));
end
%%single trial PCA group analysis
D = [];
load ('PCA_single_trial_group_level_rotation_R_31_K_3  10  12.mat');
[NumChans,NumSamps,stiNum,NumSubs] = size(D);


Group_Idx = ones(NumSubs,1);

NumGroups = max(Group_Idx);
tIndex = linspace(timeStart,timeEnd,NumSamps);
%% MEAN measurement
topo_box = [];
TOPO3= [];
TOPO3 = squeeze(mean(D(:,ERPSampointStart:ERPSampointEnd,:,:),2));
TOPO_mean = squeeze(mean(TOPO3(chanInterestNum,:,:),1));

TOPO_mean_Final(:,4,1) = mean(TOPO_mean,2);
TOPO_mean_Final(:,4,2) = std(TOPO_mean,0,2);

%% The mean and sta. of the similarty of topographies across subjects
RHO = [];
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO3(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        
        
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data2 = [];
            data2 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data2);
            
        end
    end
end

TOPO_Similar__mean_Final(:,4,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar__mean_Final(Numofsti,4,2) = std(RHO(Numofsti,:));
end
%%peak measurement%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for subNum = 1:NumSubs
    for stimulusNumFactorOne = 1:stiNum
        for chanNum = 1:NumChans
            temp = squeeze(D(chanNum,ERPSampointStart:ERPSampointEnd,stimulusNumFactorOne,subNum))';
            [mV  Idx3] = max(abs(temp(:)));
            TOPO_peak3(chanNum,stimulusNumFactorOne,subNum)  = squeeze(D(chanNum,ERPSampointStart+Idx3,stimulusNumFactorOne,subNum));
            Topo_latency3(chanNum,stimulusNumFactorOne,subNum)= ERPSampointStart+Idx3-1+timeStart;
        end
    end
end

TOPO_peak_av3 = squeeze(mean(TOPO_peak3(chanInterestNum,:,:),1));
Topo_latency_av3 = squeeze(mean(Topo_latency3(chanInterestNum,:,:),1))';


TOPO_peak_Final(:,4,1) = mean(TOPO_peak_av3,2);
TOPO_peak_Final(:,4,2) = std(TOPO_peak_av3,0,2);

%% The mean and sta. of the similarty of topographies across subjects
RHO = [];
for Numofsti =  1:stiNum
    
    temp =squeeze(TOPO_peak3(:,Numofsti,:));
    count  = 0;
    for Numofsub = 1:NumSubs-1
        data1= [];
        data1 =  temp(:,Numofsub);
        
        
        for jj  = (Numofsub+1):NumSubs
            count = count +1;
            data3 = [];
            data3 = temp(:,jj);
            RHO(Numofsti,count) = corr(data1,data3);
            
        end
    end
end

TOPO_Similar_peak_Final(:,4,1) = mean(RHO,2);
for Numofsti = 1:stiNum
    TOPO_Similar_peak_Final(Numofsti,4,2) = std(RHO(Numofsti,:));
end


Sti_names = {'MD','MF','ED','EF','DN','DF'};

x_range = [0.4:3:15.4;0.8:3:15.8;1.2:3:16.2;1.6:3:16.6;];
Plot_type = {'-ok','-or','-ob','-og'};
color_type = {'black','red','blue','green'};


RowNum =2;
cloumnNum =1;

figure(1)

subplot(RowNum,cloumnNum,1,'align');
set(gca,'fontsize',14,'FontWeight','bold');
hold on;
set(gca,'fontsize',14,'FontWeight','bold');
hold on;
for Numofmethod  =1:4
    x = x_range(Numofmethod,:);
    y = TOPO_Similar__mean_Final(:,Numofmethod,1);
    err = TOPO_Similar__mean_Final(:,Numofmethod,2);
    errorbar(x,y,err,Plot_type{Numofmethod},'LineWidth' ,2,'MarkerSize',10,...
        'MarkerEdgeColor',color_type{Numofmethod},'MarkerFaceColor',color_type{Numofmethod});
    hold on;
%      xlim([0 17]);
    xticks([0:1:17]);
   xticklabels({'','MD','','','MF','','','ED','','','EF','','','ND','','','NF'});
end

tN= strcat('Mean measurement: The similarity of topographies over subjects');
title(tN);
ylim([0.6 1]);

legend({'WF','iPCA','aPCA','sPCA'});



subplot(RowNum,cloumnNum,2,'align');
set(gca,'fontsize',14,'FontWeight','bold');
hold on;
for Numofmethod  =1:4
    x = x_range(Numofmethod,:);
    y = TOPO_Similar_peak_Final(:,Numofmethod,1);
    err = TOPO_Similar_peak_Final(:,Numofmethod,2);
    errorbar(x,y,err,Plot_type{Numofmethod},'LineWidth' ,2,'MarkerSize',10,...
        'MarkerEdgeColor',color_type{Numofmethod},'MarkerFaceColor',color_type{Numofmethod});
    hold on;
%      xlim([0 17]);
    xticks([0:1:17]);
   xticklabels({'','MD','','','MF','','','ED','','','EF','','','ND','','','NF'});
end

tN= strcat('Peak measurement: The similarity of topographies over subjects');
title(tN);
ylim([0.45 1]);

uiwait(msgbox('The program ends'));
%% program end
toc